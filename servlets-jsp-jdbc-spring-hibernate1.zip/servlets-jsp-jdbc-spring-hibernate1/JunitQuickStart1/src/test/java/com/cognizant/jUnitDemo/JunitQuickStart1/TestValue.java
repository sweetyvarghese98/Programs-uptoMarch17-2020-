package com.cognizant.jUnitDemo.JunitQuickStart1;

import static org.junit.Assert.*;

//import org.junit.After;
import org.junit.AfterClass;
//import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestValue {
	@BeforeClass
	public static void doSomeActivity() {
		System.out.println("Before");
	}

	@Test
	public void testCheck() {
		Calculator c=new Calculator();
		assertEquals(-1,c.check(5));//success
		//assertEquals(-1,c.check(50));//failure
	}
	@Test
	public void testFindMinimumOfTwoNumbers() {
		Calculator c=new Calculator();
		assertEquals(5,c.findMinimumOfTwoNumbers(45, 5));//success
	//	assertEquals(3,c.findMinimumOfTwoNumbers(2, 3));//failure
		
	}
	@AfterClass
	public static void  doAfterActivity() {
		System.out.println("After");
	}

}
