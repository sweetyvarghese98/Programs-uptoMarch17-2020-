package com.cognizant.jUnitDemo.JunitQuickStart1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDiscount {

	@Test
	public void testCalculateDiscountedPrice() {
		Discount d=new Discount();
		assertEquals(750,d.calculateDiscountedPrice(1000, 25));//success
		//assertEquals(75,d.calculateDiscountedPrice(1000, 25));//failure
	}

}
