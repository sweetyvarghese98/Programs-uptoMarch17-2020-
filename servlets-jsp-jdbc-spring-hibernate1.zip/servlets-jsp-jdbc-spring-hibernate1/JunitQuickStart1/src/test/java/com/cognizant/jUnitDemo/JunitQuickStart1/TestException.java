package com.cognizant.jUnitDemo.JunitQuickStart1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestException {

	@Test(expected=NullPointerException.class)
	public void test() {
		String value=null;
		String actualOutput=value.toUpperCase();
		//System.out.println("null? "+actualOutput);,this code is not executed because exception
		assertEquals("ABCD",actualOutput);
		//without (expected=NullPointerException.class) in @Test,result is failure
		//ie, nullpointerexception occurs
		//when it was used,nullpointerexception is excpected so result success
	}

}
