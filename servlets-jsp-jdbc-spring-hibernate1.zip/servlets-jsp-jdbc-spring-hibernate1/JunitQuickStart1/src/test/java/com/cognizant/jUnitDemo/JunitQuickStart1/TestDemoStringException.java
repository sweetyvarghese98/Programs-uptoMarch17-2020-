package com.cognizant.jUnitDemo.JunitQuickStart1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDemoStringException {

	@Test(expected=NullPointerException.class)
	public void testGetString() {
		
		DemoString ds=new DemoString();
		assertEquals("abcd",ds.getString());
	}

}
