package com.cognizant.jUnitDemo.JunitQuickStart1;

public class DemoString {
public String getString() {
	//assuming some string operation is done
	//and a string result is returned
	//String s="abcd";
	String s=null;
	return s;
}
}
