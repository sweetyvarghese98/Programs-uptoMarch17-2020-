package Entity;

import java.util.List;



public interface ProductDao {
	boolean insertProduct(Product p);
	 boolean  updateProduct(Product p);
	    boolean deleteProduct(int id);
	    List<Product> ListAllProduct();
}
