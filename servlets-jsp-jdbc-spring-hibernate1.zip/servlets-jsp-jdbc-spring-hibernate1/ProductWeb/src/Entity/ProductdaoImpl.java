package Entity;


import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;


import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import p1.ConnectorP;

public class ProductdaoImpl implements ProductDao{

	@Override
	public boolean insertProduct(Product p) {
		Connection connection=(Connection) ConnectorP.getConnection();
		PreparedStatement ps=null;
		//java.sql.Date sqldate=new java.sql.Date(p.getdateOfManufacture().getTime());
		Calendar calendar = Calendar.getInstance();
	    java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
	    
	    // (3) create our date insert statement
	    // String query = "INSERT INTO datetests (date1) VALUES (?)";
	    //PreparedStatement st = connection.prepareStatement(query);
	    //st.setDate(1, ourJavaDateObject);
		boolean res=false;
		try {
			ps=(PreparedStatement) connection.prepareStatement("insert into product values(?,?,?,?)");
			ps.setInt(1, p.getproductId());
			ps.setString(2, p.getproductName());
			ps.setDouble(3, p.getprice());
			ps.setDate(4, ourJavaDateObject);
			
			int r=ps.executeUpdate();
			if(r==1) {
				res=true;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}

	@Override
	public boolean updateProduct( Product p) {
		Connection connection=(Connection) ConnectorP.getConnection();
		PreparedStatement ps=null;
		boolean res=false;
		/*java.util.Date d=null;
		java.sql.Date sqldate = new java.sql.Date(d.getTime());*/
		Calendar calendar = Calendar.getInstance();
	    java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
	    
		String sql="update customer set product_name=?,price=? , where product_id=?";
		
		try {
			ps= (PreparedStatement) connection.prepareStatement(sql);
			ps.setString(1, p.getproductName());
			ps.setDouble(2, p.getprice());
			ps.setDate(3, ourJavaDateObject);
			ps.setInt(4, p.getproductId());
			
			int r=ps.executeUpdate();
			if(r==1)
			{
				res=true;
			}
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return res;
		
	}

		
	

	
	@Override
	public List<Product> ListAllProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean deleteProduct(int id) {
		Connection connection=(Connection) ConnectorP.getConnection();
		PreparedStatement ps=null;
		boolean result=false;
		String sql="delete from product where product_id=?";
		try {
			ps=(PreparedStatement) connection.prepareStatement(sql);
			ps.setInt(1,id);
			int r=ps.executeUpdate();
			if(r==1)
			{
				result=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result ;
	}

}
