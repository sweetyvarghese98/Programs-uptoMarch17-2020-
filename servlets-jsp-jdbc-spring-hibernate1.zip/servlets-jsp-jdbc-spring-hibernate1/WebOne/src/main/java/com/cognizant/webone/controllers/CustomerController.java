package com.cognizant.webone.controllers;

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.webone.entity.Customer;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	@InitBinder
	public void doPreProcessing(WebDataBinder dataBinder)
	{	//true inside the constructor means->reduce all white spaces to null
		//removes leading and trailing white spaces
		StringTrimmerEditor stringTrimmerEditor=
				new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class,stringTrimmerEditor);
		//meaning of above line->just apply stringTrimmerEditor to all strings
		//that comes in the request.
	}
	@RequestMapping("/showForm")
	public String showForm(Model theModel)
{
	Customer theCustomer=new Customer();
	theModel.addAttribute("customer",theCustomer);
	return "customer-page";
	
}
	
	
@RequestMapping("/processForm")
		public String processForm(@Valid @ModelAttribute("customer") Customer theCustomer,BindingResult theBindingResult)
	{
	//System.out.println(theCustomer.toString());	
	//System.out.println("|"+theCustomer.getFirstName()+"|");
	//	System.out.println("|"+theCustomer.getLastName()+"|");//to see the blank spaces entered in the console,when blank spaces entered it is considered as characters.
		/*
		 * System.out.println(theCustomer.getFirstName());
		 * System.out.println(theCustomer.getLastName());
		 * System.out.println(theCustomer.getFreePasses());
		 * System.out.println(theCustomer.getPostalcode());
		 * System.out.println(theCustomer.getEmail());
		 */
		System.out.println(theCustomer);
		System.out.println("***************");
		System.out.println(theBindingResult); //to see the error reason in console
		System.out.println("***************");
		if(theBindingResult.hasErrors()) {
			return "customer-page";
		}
		return "customer-confirmation-page";
		
	}
	
}
