package com.cognizant.webone.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloWorldController {

	@RequestMapping("/")//  / is mapped to main-page.jsp
	public String sayHello() {
	return "main-page";//main-page is the name of the view that has to be displayed.spring will convert this into web-inf/main-page.jsp
}
//display form will render a jsp page where user
//can enter his name
	
	@RequestMapping("/displayForm")
	public String displayForm() {
		return "user-page";//user-page is the name of the view that has to be displayed.spring will convert this into web-inf/user-page.jsp
	}
	
	@RequestMapping("/processForm")
	public String processForm() {
		return "hello-page";
		
	}
	
	@RequestMapping("/processForm2")
	public String processFormVersiontwo(HttpServletRequest request,Model model) {
		String theUserName=request.getParameter("userName");
		String upperCaseName=theUserName.toUpperCase();
		//model is a holder for objects ->any object can be set as attribute
		model.addAttribute("user",upperCaseName);//Model is like a java object in spring framework,so we can use attribute.this is MVC M=>Model
		return "hello-page";
	}
		
		//different way for getting parameter
		@RequestMapping("/processForm3")
		public String processFormVersionthree(@RequestParam("userName") String theUserName,Model model) {//Requestparam annotation is to get parameter frm view
			//String theUserName=request.getParameter("userName");
			String upperCaseName=theUserName.toUpperCase();
			//model is a holder for objects ->any object can be set as attribute
			model.addAttribute("user",upperCaseName);//Model is like a java object in spring framework,so we can use attribute.this is MVC M=>Model
			return "hello-page";
		
		
	}
}
