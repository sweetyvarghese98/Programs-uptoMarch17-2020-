package com.cognizant.webone.entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

public class Customer {
	//@NotEmpty
	@NotEmpty(message="enter firstname")
	@NotBlank(message="firstname can be blank")//@InitBinder is used usually
String firstName;
	//@NotEmpty
	@NotEmpty(message="enter lastname")
	@Size(min=4,max=8,message="enter lastname min 4 and max 8")
String lastName;
	@NotNull
	@Min(value=1,message="The customer must have atleast one free pass")
	@Max(value=6,message="The customer can have maximum six free passes")
	private int freePasses;
	
	@Pattern(regexp="^[a-zA-Z0-9]{6}",message="you can enter only 6 characters")
	private String postalcode;
	
	@Email(message="Email should be valid")
	private String email;
	
public Customer()
{
	
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public int getFreePasses() {
	return freePasses;
}
public void setFreePasses(int freePasses) {
	this.freePasses = freePasses;
}
public String getPostalcode() {
	return postalcode;
}
public void setPostalcode(String postalcode) {
	this.postalcode = postalcode;
}

public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Override
public String toString() {
	return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", freePasses=" + freePasses
			+ ", postalcode=" + postalcode + ", email=" + email + "]";
}

}
