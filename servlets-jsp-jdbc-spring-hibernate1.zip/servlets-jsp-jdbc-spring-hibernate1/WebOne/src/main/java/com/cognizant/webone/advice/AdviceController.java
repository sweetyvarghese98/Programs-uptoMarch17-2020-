package com.cognizant.webone.advice;

import java.io.IOException;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class AdviceController {
	
	  @ExceptionHandler(value=RuntimeException.class) public String
	  exceptionHandler() { return "myException-handler-page";//for that error donot shown to others when runtimeexception occurs 
	  }
	  
	 
	@ExceptionHandler(value=IOException.class) 
	public String ioexceptionHandler()
	 { return "myioException";//for that error donot shown to others when runtimeexception occurs
	 }
}
