package com.cognizant.webone.entity;

import java.util.Arrays;
import java.util.LinkedHashMap;

public class Student {
	//variables,non arg constructors,getters and setters
String firstname;
String lastname;
String country;
private LinkedHashMap<String,String> countryOptions;
private String favouriteLanguage;
public String[] operatingSystems;


public Student() {
countryOptions=new LinkedHashMap<>();
getCountryOptions().put("DE","Germany");
getCountryOptions().put("FR","France");
getCountryOptions().put("BR","Brazil");
getCountryOptions().put("IN","India");

}
//setter is not needed here.because we have alredy given(set) the values using linked hashmap
public LinkedHashMap<String,String> getCountryOptions() {
	return countryOptions;
}


public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getFavouriteLanguage() {
	return favouriteLanguage;
}
public void setFavouriteLanguage(String favouriteLanguage) {
	this.favouriteLanguage = favouriteLanguage;
}
public String[] getOperatingSystems() {
	return operatingSystems;
}
public void setOperatingSystems(String[] operatingSystems) {
	this.operatingSystems = operatingSystems;
}
@Override
public String toString() {
	return "Student [firstname=" + firstname + ", lastname=" + lastname + ", country=" + country + ", countryOptions="
			+ countryOptions + ", favouriteLanguage=" + favouriteLanguage + ", operatingSystems="
			+ Arrays.toString(operatingSystems) + "]";
}



}
