package com.cognizant.webone.controllers;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.webone.entity.Student;

@Controller
@RequestMapping("/student")
public class StudentController {

	@RequestMapping("/displayForm")
	public String displayForm(Model theModel) {
		Student theStudent=new Student();//constructor and linked hashmap works
		theModel.addAttribute("student",theStudent);
		return "student-page";//name of the view to be displayed
	}
	
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("student")Student theStudent) throws IOException {
		//Student theStudent=request.getAttribute("student");
		if(theStudent.getFirstname().isEmpty()) 
		{
			//throw new RuntimeException("student name cannot be empty");
			//just to demonstrate a checked exception,ioexception is thrown here
			throw new IOException("my exception message");
		}
		//to see in console
		System.out.println(theStudent.getFirstname());
		System.out.println(theStudent.getLastname());
		System.out.println(theStudent.getCountry());
		System.out.println(theStudent.getCountryOptions());
		System.out.println(theStudent.getFavouriteLanguage());
		for(int i=0;i<theStudent.operatingSystems.length;i++)
		{
			System.out.println(theStudent.operatingSystems[i]);
		}
		
		System.out.println(theStudent.toString());
		return "student-confirmation-page";
		
	}
	
	/*
	 * @ExceptionHandler(value=RuntimeException.class) public String
	 * exceptionHandler() { return "myException-handler-page";//for that error donot
	 * shown to others when runtimeexception occurs }
	 * 
	 * @ExceptionHandler(value=IOException.class) public String ioexceptionHandler()
	 * { return "myioException";//for that error donot shown to others when
	 * runtimeexception occurs }
	 */
	}

