package com.cognizant.SpringMVCIntercepter.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class MyInitController {

	@RequestMapping(value="/init",method=RequestMethod.GET)
	public ModelAndView initView()
	{	//ModelAndView is like Model attribute only ie here string + jsp(view),there it was separate
		System.out.println("Handler method is called.");
		ModelAndView modelview=new ModelAndView();
		modelview.addObject("message", "This is an example of mvc-interceptors in Spring framework ..!");
		modelview.setViewName("output");//resolved into output.jsp
		return modelview;
		
	}
	
	@RequestMapping(value="/dual",method=RequestMethod.GET)
	public ModelAndView dualView() {
		System.out.println("Handler method is called");
		ModelAndView modelview=new ModelAndView();
		modelview.addObject("welcome_message","Spring mvc Internationalization Example");
		modelview.setViewName("welcome");
		return modelview;
	}
}
