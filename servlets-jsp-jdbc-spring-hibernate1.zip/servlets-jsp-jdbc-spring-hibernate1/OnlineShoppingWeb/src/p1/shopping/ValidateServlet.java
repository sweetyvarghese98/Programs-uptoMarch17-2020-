package p1.shopping;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ValidateServlet
 */
public class ValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=null;
		session=request.getSession(false);
		RequestDispatcher rd=null;
		
		
		PrintWriter out=response.getWriter();
		
		String item[]=request.getParameterValues("c");
		ArrayList<String> alist=Cart.addToArray(item);
		
		
		
		session.setAttribute("item", alist);
		rd=request.getRequestDispatcher("ArrayServlet");
		rd.forward(request,response);
		
		
		
		
		
		
		
		/*for(int i=0;i<item.length;i++)
			{
				
				alist.add(item[i]);
				//System.out.println();
			}
		
		Iterator<String> iter=alist.iterator();
		
		
		
		while(iter.hasNext())
		{	
			String n=iter.next();
			out.println(n);
			
		}*/
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
