package com.cognizant.sports;

public class TennisCoach implements Coach {

	@Override
	public String getDailyWorkOut() {
		return "net practice for 2 hours daily";
	}

}
