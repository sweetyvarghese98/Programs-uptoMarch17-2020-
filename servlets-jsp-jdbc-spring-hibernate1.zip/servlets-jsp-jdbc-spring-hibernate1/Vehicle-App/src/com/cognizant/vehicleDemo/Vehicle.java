package com.cognizant.vehicleDemo;

public interface Vehicle {
String display();
}
