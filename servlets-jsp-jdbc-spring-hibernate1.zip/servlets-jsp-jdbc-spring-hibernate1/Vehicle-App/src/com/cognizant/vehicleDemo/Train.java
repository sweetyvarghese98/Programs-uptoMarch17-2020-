package com.cognizant.vehicleDemo;

public class Train implements Vehicle {

	@Override
	public String display() {
		// TODO Auto-generated method stub
		return "Train";
	}

}
