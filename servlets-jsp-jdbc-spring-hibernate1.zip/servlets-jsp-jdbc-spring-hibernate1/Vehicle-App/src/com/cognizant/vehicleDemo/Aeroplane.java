package com.cognizant.vehicleDemo;

public class Aeroplane implements Vehicle {

	@Override
	public String display() {
		// TODO Auto-generated method stub
		return "Aeroplane";
	}

}
