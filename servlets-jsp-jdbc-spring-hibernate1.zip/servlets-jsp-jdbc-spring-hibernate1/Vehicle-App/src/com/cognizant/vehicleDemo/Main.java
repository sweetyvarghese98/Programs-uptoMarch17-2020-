package com.cognizant.vehicleDemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		//for creating classes easily.
		//Vehicle v=new Car();
		//Vehicle v=new Aeroplane();
		//Vehicle v=new Train();
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationVehicleContext.xml");
		Vehicle v=context.getBean("myCar",Vehicle.class);
		System.out.println(v.display());
		
		v=context.getBean("myAeroplane",Vehicle.class);
		System.out.println(v.display());
		
		v=context.getBean("myTrain",Vehicle.class);
		System.out.println(v.display());

	}

}
