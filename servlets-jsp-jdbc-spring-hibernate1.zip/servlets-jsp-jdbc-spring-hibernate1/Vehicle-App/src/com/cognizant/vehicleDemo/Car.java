package com.cognizant.vehicleDemo;

public class Car implements Vehicle {

	@Override
	public String display() {
		// TODO Auto-generated method stub
		return "car";
	}

}
