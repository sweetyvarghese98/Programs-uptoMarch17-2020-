package com.cognizant.webproduct.controllers;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.CustomDateEditor;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.webproduct.entity.Product;

@Controller
public class ProductController {

	/*
	 * @InitBinder public void doPreProcessing(WebDataBinder binder) { DateFormat
	 * dateFormat = new SimpleDateFormat("dd/mm/yyyy"); CustomDateEditor
	 * orderDateEditor = new CustomDateEditor(dateFormat, true);
	 * binder.registerCustomEditor(Date.class, orderDateEditor); }
	 */
	 
	
	
@RequestMapping("/")
public String sayHello() {
return "main-page";
}

@RequestMapping("/showForm")
public String showForm(Model theModel)
{
Product theProduct=new Product();
theModel.addAttribute("product",theProduct);
return "product-page";

}
@RequestMapping("/processForm")
public String processForm(@Valid @ModelAttribute("product") Product theProduct,BindingResult theBindingResult)
{

System.out.println(theProduct);
System.out.println("***************");
System.out.println(theBindingResult); //to see the error reason in console
System.out.println("***************");

if(theBindingResult.hasErrors()) {
	return "product-page";
}
return "product-confirmation-page";

}

}


