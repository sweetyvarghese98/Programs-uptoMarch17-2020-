package com.cognizant.webproduct.entity;

import java.util.Date;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Product {
@NotEmpty(message="Enter ProductName")
String productName;
@NotEmpty(message="Give a Description")
@Size(min=5,max=50 ,message="Give a description of maximum 50")
String description;
@Min(value=1,message="Enter Price")
int price;
@NotNull
@DateTimeFormat(pattern="dd-MM-yyyy")//give required pattern for date here
Date dateOfManufacture;
@NotEmpty(message="Enter Email")
@Email(message="Email should be valid")
String manufactureEmail;

public Product()
{
	
}

public String getProductName() {
	return productName;
}

public void setProductName(String productName) {
	this.productName = productName;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

	
	  public Date getDateOfManufacture() { return dateOfManufacture; }
	  
	  public void setDateOfManufacture(Date dateOfManufacture) {
	  this.dateOfManufacture = dateOfManufacture; }
	 
	 
public String getManufactureEmail() {
	return manufactureEmail;
}

public void setManufactureEmail(String manufactureEmail) {
	this.manufactureEmail = manufactureEmail;
}



	
	  @Override public String toString() { return "Product [productName=" +
	  productName + ", description=" + description + ", price=" + price +
	  ", dateOfManufacture=" +dateOfManufacture+ ", manufactureEmail=" +
	  manufactureEmail + "]"; }
	 

}
