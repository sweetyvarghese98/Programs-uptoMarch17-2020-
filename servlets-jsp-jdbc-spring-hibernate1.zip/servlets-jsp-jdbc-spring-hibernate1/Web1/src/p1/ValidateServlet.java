package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ValidateServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("username");
		String password=request.getParameter("password");
		
		String information=new String("HappyDay");
		request.setAttribute("hd", information);
		RequestDispatcher rd=null;
		if(userName.equalsIgnoreCase("U123Abc")&&password.equals("12345"))
{	
	rd=request.getRequestDispatcher("home");
	//it send request to homeservlet .
	rd.forward(request, response);
}
		else if(userName.equalsIgnoreCase("abc")&&password.equals("123"))
		{
			//fresh request from client browser
			//response.sendRedirect("display");//it goes to display servlet from client,ie fresh request.output is hii null
			response.sendRedirect("display?username=abc");//this abc goes to user parameter.
			//response.sendRedirect("http://edition.cnn.com");
		}
		else
		{
			String user=request.getParameter("username");
			PrintWriter out=response.getWriter();
			out.println("<html><body>");
			//it works in validate servlet only
			//out.println(user); here we will get the username.
			//out.println(information); will get happyday as output
			out.println("Sorry you are not Authorized");
			out.println("</body></html>");
		}
		
	}

}
