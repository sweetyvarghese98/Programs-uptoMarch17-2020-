package p1;

import java.util.ArrayList;

public class Card {
	
		  private Symbol symbol;
		  private CardValue cardValue;
		 
		  public Card (CardValue cardValue, Symbol symbol)
		  {
		    this.cardValue = cardValue;
		    this.symbol = symbol;
		  }

	/*
	 * @Override public String toString() { return "Card [symbol=" + symbol +
	 * ", cardValue=" + cardValue + "]"; }
	 */
	
	  public Symbol getSymbol() { return symbol; }
	  
	  public void setSymbol(Symbol symbol) { this.symbol = symbol; }
	  
	  public CardValue getCardValue() { return cardValue; }
	  
	  public void setCardValue(CardValue cardValue) { this.cardValue = cardValue; }
	 
		  
}	 
		 