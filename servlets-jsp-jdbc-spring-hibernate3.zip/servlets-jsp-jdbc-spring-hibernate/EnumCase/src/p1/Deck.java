package p1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;



public class Deck {
	//ArrayList<Card>a1=new ArrayList<>();
	
	 private ArrayList deck;
	 int i;
	 
	  public Deck ()
	  {
	    this.deck = new ArrayList();
	    for (int i=0; i<13; i++)
	    {
	      CardValue value = CardValue.values()[i];//cardValues
	    
	 
	      for (int j=0; j<4; j++)
	      {
	       // Symbol symbol=Symbol.values()[j];//symbolvalues
	    	 Card card = new Card(value, Symbol.values()[j]);
	        //a1.add(value);
	      // Card card=new Card(value,symbol);
	      // a1.add(card);
	       this.deck.add(card);
	        
	      }
	    }
	 
	    Collections.shuffle(deck);
	    //Collections.shuffle(a1);
	 
	    //Iterator cardIterator = (Iterator)a1.iterator(); while
		  Iterator cardIterator = (Iterator)deck.iterator(); while
		  (cardIterator.hasNext()) { Card aCard = (Card) cardIterator.next(); //
		  System.out.println(i+1+ " "+aCard.getCardValue() + " of " +
		  aCard.getSymbol());
		  
		  i++; }
		 
	   // System.out.println(a1);
	  }
	}