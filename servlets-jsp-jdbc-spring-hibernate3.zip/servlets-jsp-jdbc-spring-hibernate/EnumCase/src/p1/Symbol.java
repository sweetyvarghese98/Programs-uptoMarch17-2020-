package p1;

public enum Symbol {
SPADE,
HEART,
CLAVER,
DIAMOND;
}
