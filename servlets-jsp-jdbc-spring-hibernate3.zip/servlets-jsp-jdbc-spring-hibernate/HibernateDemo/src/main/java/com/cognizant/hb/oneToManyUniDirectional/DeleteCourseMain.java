package com.cognizant.hb.oneToManyUniDirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DeleteCourseMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg3.xml")
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(Course.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();

Session session=factory.getCurrentSession();
session.beginTransaction();

		
		  Course c1=session.get(Course.class,14); 
		  System.out.println(c1);
		  session.delete(c1);
		 
		/*
		 * Review r1=session.get(Review.class,5); System.out.println(r1);
		 * session.delete(r1);
		 */
session.getTransaction().commit();
factory.close();

	}

}
