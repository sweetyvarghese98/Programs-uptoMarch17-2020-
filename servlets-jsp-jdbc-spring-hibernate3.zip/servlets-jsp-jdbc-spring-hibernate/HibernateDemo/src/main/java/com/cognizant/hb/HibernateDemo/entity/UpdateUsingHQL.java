package com.cognizant.hb.HibernateDemo.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UpdateUsingHQL {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class)
				.buildSessionFactory();
Session session=factory.getCurrentSession();
session.beginTransaction();
session.createQuery("update Student set email='sspdl@hotmail.com'").executeUpdate();//it will update whole column,ie for all students have common email

session.getTransaction().commit();
factory.close();
	}

}
