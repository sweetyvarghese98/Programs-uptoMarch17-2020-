package com.cognizant.hb.HibernateDemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity// a java class (plain old java bean) with variables getters and setters
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)//how id is generated,here by database
	@Column(name="id")
private int id;
	@Column(name="first_name")//@Column is used to push this into database
private String firstName;
	@Column(name="last_name")//name=column name given  in database
private String lastName;
	@Column(name="email")
private String email;

public Student()
{
	
}
public Student(String firstName, String lastName, String email) {
	//id is supplied by mysql database server,beacause there we gave auto increment for id
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Override
public String toString() {
	return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
}


}
