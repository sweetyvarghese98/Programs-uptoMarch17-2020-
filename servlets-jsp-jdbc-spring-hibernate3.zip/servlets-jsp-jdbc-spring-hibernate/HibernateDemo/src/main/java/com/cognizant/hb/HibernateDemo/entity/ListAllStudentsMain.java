package com.cognizant.hb.HibernateDemo.entity;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ListAllStudentsMain {
//to list all students from database
	public static void main(String[] args) {
		//obtain sessionfactory
		
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class)
				.buildSessionFactory();
		
		//begin transaction
		Session session=factory.getCurrentSession();
		
		session.beginTransaction();
		
		//list all students
		List<Student>studentList=
		//session.createQuery("from Student").list();//HQL=>Hibernate Query Language
		//session.createQuery("from Student where lastName='varghese'").list();//HQL=>Hibernate Query Language
		session.createQuery("from Student where email like '%gmail%'").list();//HQL=>Hibernate Query Language
		//display the list
		studentList.forEach(student->System.out.println(student));
		studentList.forEach(student->System.out.println(student.getFirstName()+student.getLastName()));//using the object we can get values
		//commit
		session.getTransaction().commit();
		
	}

}
