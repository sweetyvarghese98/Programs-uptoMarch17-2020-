package com.cognizant.hb.oneToManyBidirectionalBookReview;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DeleteReviewNotBook {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfgbook.xml")
				.addAnnotatedClass(Book.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();
				
				Session session=factory.getCurrentSession();
				session.beginTransaction();
				
				//Review review1=session.get(Review.class, 1);
				//session.delete(review1);
				
				//Book book1=session.get(Book.class, 1);
				//session.delete(book1);
				
				

				session.getTransaction().commit();
				factory.close();


	}

}
