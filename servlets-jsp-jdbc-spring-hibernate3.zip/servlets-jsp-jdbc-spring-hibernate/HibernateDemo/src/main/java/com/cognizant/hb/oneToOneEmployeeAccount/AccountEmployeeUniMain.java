package com.cognizant.hb.oneToOneEmployeeAccount;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cognizant.hb.oneToOneUni.Instructor;
import com.cognizant.hb.oneToOneUni.InstructorDetail;

public class AccountEmployeeUniMain {

	public static void main(String[] args) {
		
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Employee.class)
				.addAnnotatedClass(Account.class)
				.buildSessionFactory();

Session session=factory.getCurrentSession();

//Employee e1=new Employee("s@gmail.com","sweety","varghese");
//Account a1=new Account("a101");
Employee e2=new Employee("sv@gmail.com","simi","varghese");
Account a2=new Account("a102");
Employee e3=new Employee("dp@gmail.com","dhanya","prabhu");
Account a3=new Account("a103");




//use setter to set the instructor detail object to instructor object
//e1.setAccount(a1);
e2.setAccount(a2);
e3.setAccount(a3);

//begin transaction
session.beginTransaction();
System.out.println("About to save.......");
session.save(e2);
session.save(e3);


//commit
session.getTransaction().commit();
System.out.println("Its done!");
factory.close();
}

}
