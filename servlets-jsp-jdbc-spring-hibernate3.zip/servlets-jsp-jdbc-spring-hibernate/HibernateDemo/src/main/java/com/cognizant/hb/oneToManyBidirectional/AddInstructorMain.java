package com.cognizant.hb.oneToManyBidirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class AddInstructorMain {
//here adding Instructor and InstructorDetail
	public static void main(String[] args) {

		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg2.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class)
				.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		Instructor instructor1=new Instructor("sweety","varghese","s@gmail.com");
		InstructorDetail idetail1=new InstructorDetail("youtube/cooking","cooking");
		
		Instructor instructor2=new Instructor("Dhanya","D","d@gmail.com");
		InstructorDetail idetail2=new InstructorDetail("youtube/BookReviews","Reading");
		
		instructor1.setInstructorDetail(idetail1);
		session.save(instructor1);
		
		instructor2.setInstructorDetail(idetail2);
		session.save(instructor2);
		
		
		/*
		 * //to add courses Course course1=new Course("ContinentalCooking"); Course
		 * course2=new Course("how to effectively play pubG");
		 * 
		 * Instructor tempInstructor=session.get(Instructor.class,instructor1.getId());
		 * tempInstructor.add(course1); tempInstructor.add(course2);
		 * 
		 * session.save(course1); session.save(course2);
		 */
		
		session.getTransaction().commit();
		factory.close();
	}

}
