package com.cognizant.hb.oneToManyBidirectionalBookReview;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cognizant.hb.oneToManyBidirectional.Course;

@Entity
@Table(name="book")
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="book_id")
private int bid;
	@Column(name="title")
private String title;
	@Column(name="price")
private int price;
	
	@OneToMany(mappedBy="book",cascade= {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
	private List<Review>reviews;

	public Book() {
		
	}

	public Book(String title, int price) {
		
		this.title = title;
		this.price = price;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public List<Review> getReviews() {
		return reviews;
	}

	public void setReviews(List<Review> reviews) {
		this.reviews = reviews;
	}

	@Override
	public String toString() {
		return "Book [bid=" + bid + ", title=" + title + ", price=" + price + "]";
	}
	//utility method to initialize arraylist and add a review
		public void add(Review tempReview) {
			if(getReviews()==null) {
				setReviews(new ArrayList<>());
		}
		getReviews().add(tempReview);
		//set up birectional link
		tempReview.setBook(this);
	}

}
