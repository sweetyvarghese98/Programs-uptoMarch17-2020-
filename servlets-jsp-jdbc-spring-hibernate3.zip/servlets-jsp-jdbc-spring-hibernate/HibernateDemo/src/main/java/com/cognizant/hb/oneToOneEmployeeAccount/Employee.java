package com.cognizant.hb.oneToOneEmployeeAccount;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
private int empId;
	@Column(name="email")
private String email;
	@Column(name="first_name")
private String firstName;
	@Column(name="last_name")
private String lastName;

@OneToOne(cascade=CascadeType.ALL)
@JoinColumn(name="Account_id")
private Account account;

public Employee() {
	
}

public Employee(String email, String firstName, String lastName) {
	
	this.email = email;
	this.firstName = firstName;
	this.lastName = lastName;

}

public int getEmpId() {
	return empId;
}

public void setEmpId(int empId) {
	this.empId = empId;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public Account getAccount() {
	return account;
}

public   void setAccount(Account account) {
	this.account = account;
}

@Override
public String toString() {
	return "Employee [empId=" + empId + ", email=" + email + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", account=" + account + "]";
}


}
