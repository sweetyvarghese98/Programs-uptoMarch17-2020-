package com.cognizant.hb.oneToOneUni1;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="cust_id")
private int customerId;
@Column(name="cust_name")
private String customerName;
@Column(name="cust_email")
private String customerEmail;
@Column(name="cust_address")
private String customerAddress;

@OneToOne(cascade=CascadeType.ALL)
@JoinColumn(name="txn_id")       //txn_id is foreign key
private Transaction transaction;
public Customer() {
	
}
public Customer( String customerName, String customerEmail, String customerAddress)//customerid is not given since it is autoincrement
{
	
	this.customerName = customerName;
	this.customerEmail = customerEmail;
	this.customerAddress = customerAddress;
}

public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getCustomerEmail() {
	return customerEmail;
}
public void setCustomerEmail(String customerEmail) {
	this.customerEmail = customerEmail;
}
public String getCustomerAddress() {
	return customerAddress;
}
public void setCustomerAddress(String customerAddress) {
	this.customerAddress = customerAddress;
}
public Transaction getTransaction() {
	return transaction;
}
public void setTransaction(Transaction transaction) {
	this.transaction = transaction;
}



}
