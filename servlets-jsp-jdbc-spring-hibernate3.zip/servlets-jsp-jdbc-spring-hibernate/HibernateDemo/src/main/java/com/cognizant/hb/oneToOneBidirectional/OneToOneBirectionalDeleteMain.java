package com.cognizant.hb.oneToOneBidirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToOneBirectionalDeleteMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail.class)
				.buildSessionFactory();
		int id=6;
		//create session
		Session session=factory.getCurrentSession();
		//try {
			session.beginTransaction();
			//If it is bidirectional mapping only,can delete using instructordetail object
			/*
			 * InstructorDetail idetail=session.get(InstructorDetail.class,id);
			 * session.delete(idetail);//both instructordetail and instructor of
			 * corresponding id(if it have instructor detailid) will be deleted Instructor
			 * i=session.get(Instructor.class,id); session.delete(i);//both instructor data
			 * and instructordetail of corresponding id(if it have instructor detailid) will
			 * be deleted
			 */			Instructor i2=session.get(Instructor.class,id);
			session.delete(i2);//delete only instructor data if cascadetype is not all in instructor,and it shouldnot have instructordetailid
			session.getTransaction().commit();
			System.out.println("Its done!");
		//}
		/*catch(Exception e)
		{
			System.out.println("record not found");
			e.printStackTrace();
		}
		finally {
			factory.close();
		}*/
	}

}
