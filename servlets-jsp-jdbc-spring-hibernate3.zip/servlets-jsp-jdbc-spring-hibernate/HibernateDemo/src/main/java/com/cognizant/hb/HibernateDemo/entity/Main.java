package com.cognizant.hb.HibernateDemo.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		//create session factory object
		//session factory is essential for pushing data to database
		SessionFactory sessionFactory=
				new Configuration()
			    .configure("hibernate.cfg.xml")//hibernate.cfg.xml is default
				.addAnnotatedClass(Student.class)
				.buildSessionFactory();
		
		//create the session 
		Session session=sessionFactory.getCurrentSession();
		
		//create entity
		Student theStudent1=new Student("Arun","Kumar","arun@gmail.com");
		Student theStudent2=new Student("Paul","Raj","paul@gmail.com");
		Student theStudent3=new Student("Sweety","Varghese","sweety@gmail.com");
		Student theStudent4=new Student("Simi","Varghese","simi@gmail.com");
		
		
		//begin transaction
		session.beginTransaction();
		session.save(theStudent1);
		session.save(theStudent2);
		session.save(theStudent3);
		session.save(theStudent4);
		
		session.getTransaction().commit();
		sessionFactory.close();

	}

}
