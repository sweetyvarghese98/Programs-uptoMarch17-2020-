package com.cognizant.hb.oneToOneUni1;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="txn_id")
int txnId;
	@Column(name="txn_date")
Date txnDate;
	@Column(name="txn_total")
int txnTotal;
	Transaction()
	{
		
	}
	public Transaction(Date txnDate, int txnTotal) {
		this.txnDate = txnDate;
		this.txnTotal = txnTotal;
	}
	public int getTxnId() {
		return txnId;
	}
	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}
	public Date getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}
	public int getTxnTotal() {
		return txnTotal;
	}
	public void setTxnTotal(int txnTotal) {
		this.txnTotal = txnTotal;
	}
	
}
