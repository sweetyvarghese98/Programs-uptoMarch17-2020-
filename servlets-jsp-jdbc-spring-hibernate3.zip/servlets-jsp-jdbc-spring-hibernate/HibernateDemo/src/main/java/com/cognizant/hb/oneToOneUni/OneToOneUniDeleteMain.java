package com.cognizant.hb.oneToOneUni;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToOneUniDeleteMain {

	public static void main(String[] args) {
		int id=2;//this id is id of instructor table,only that will be deleted
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Instructor.class)
				.buildSessionFactory();

Session session=factory.getCurrentSession();
//begin transaction
session.beginTransaction();
Instructor theInstructor=session.get(Instructor.class, id);

//we cant delete instructordetail alone...because without instructordetail no instructor,and also it is unidirection
System.out.println("About to delete.......");

if(theInstructor!=null) {
session.delete(theInstructor);//automatically delete the corresponding data from instructor_details table also,because cascadetype all in instructor
}else
{
	System.out.println("Instructor object not available");
}
//commit
session.getTransaction().commit();
System.out.println("Its done!");
factory.close();
}

}
