package com.cognizant.hb.HibernateDemo.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UpdateStudentMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class)
				.buildSessionFactory();
		
		//begin transaction
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		Student s=session.get(Student.class, 1);//primary key
		s.setFirstName("Ravi");
		s.setEmail("ravi@gmail.com");
		System.out.println(s);
		session.getTransaction().commit();
		

	}

}
