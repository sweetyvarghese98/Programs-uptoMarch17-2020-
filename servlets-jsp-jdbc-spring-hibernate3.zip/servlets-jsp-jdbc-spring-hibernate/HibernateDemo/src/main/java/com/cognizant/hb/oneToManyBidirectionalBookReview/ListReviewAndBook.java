package com.cognizant.hb.oneToManyBidirectionalBookReview;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ListReviewAndBook {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfgbook.xml")
				.addAnnotatedClass(Book.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();
				
				Session session=factory.getCurrentSession();
				session.beginTransaction();
				
				Book b1=session.get(Book.class,1);
				List<Review> r=b1.getReviews();
				
				r.forEach(reviews->System.out.println(reviews));
				
				
				
				session.getTransaction().commit();
				factory.close();
	}

}
