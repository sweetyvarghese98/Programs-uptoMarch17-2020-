package com.cognizant.hb.oneToManyBidirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class DeleteCourseMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg2.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class)
				.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		Course c1=session.get(Course.class,10);
		
		//kill the bidirectional link else exception
		//set the Instructor reference to null
		//c1.getInstructor().setCourses(null);
		session.delete(c1);
		session.getTransaction().commit();
		factory.close();
	}

}
