package com.cognizant.hb.oneToOneEmployeeAccount;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="account")
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
private int accId;
	@Column(name="account_number")
private String accNumber;
public Account() {
	
}
public Account(String accNumber) {
	
	this.accNumber = accNumber;
}
public int getAccId() {
	return accId;
}
public void setAccId(int accId) {
	this.accId = accId;
}
public String getAccNumber() {
	return accNumber;
}
public void setAccNumber(String accNumber) {
	this.accNumber = accNumber;
}
@Override
public String toString() {
	return "Account [accId=" + accId + ", accNumber=" + accNumber + "]";
}

}
