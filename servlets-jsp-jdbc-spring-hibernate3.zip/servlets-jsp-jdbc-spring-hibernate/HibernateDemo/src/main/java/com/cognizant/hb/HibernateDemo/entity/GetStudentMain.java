package com.cognizant.hb.HibernateDemo.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class GetStudentMain {
public static void main(String args[])
{
	SessionFactory factory=new Configuration()
			.configure("hibernate.cfg.xml")
			.addAnnotatedClass(Student.class)
			.buildSessionFactory();
	
	//get connection
	Session session=factory.getCurrentSession();
	
	//begin transaction
	session.beginTransaction();
	
	//get the object
	Student theStudent1=session.get(Student.class, 2);
	Student theStudent2=session.get(Student.class, 3);
	Student theStudent3=session.get(Student.class, 4);
	//commit
	System.out.println(theStudent1);
	System.out.println(theStudent2);
	System.out.println(theStudent3);
	session.getTransaction().commit();
	//close the factory
	factory.close();
}
}
