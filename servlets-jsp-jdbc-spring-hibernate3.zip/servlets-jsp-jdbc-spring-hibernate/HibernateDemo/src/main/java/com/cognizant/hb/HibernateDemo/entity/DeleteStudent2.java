package com.cognizant.hb.HibernateDemo.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DeleteStudent2 {

	public static void main(String[] args) {
	

		
			SessionFactory factory=new Configuration()
					.configure("hibernate.cfg.xml")
					.addAnnotatedClass(Student.class)
					.buildSessionFactory();
	Session session=factory.getCurrentSession();
	try {
	session.beginTransaction();
	session.createQuery("delete from Student where id=5").executeUpdate();//delete row of data with id=5;
	//session.createQuery("delete from Student").executeUpdate();//to delete all datas
	//commit
   // Student s=session.get(Student.class, 4);
    //session.delete(s);//This also possible
	session.getTransaction().commit();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	finally {
	factory.close();
		}
	}

	}
