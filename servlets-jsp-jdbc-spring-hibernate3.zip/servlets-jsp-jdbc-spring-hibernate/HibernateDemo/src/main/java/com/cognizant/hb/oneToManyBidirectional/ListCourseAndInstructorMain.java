package com.cognizant.hb.oneToManyBidirectional;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ListCourseAndInstructorMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg2.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class)
				.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		//list all courses handled by the instructor #id=1;
		
		//get the Instructor
		Instructor tempInstructor=session.get(Instructor.class, 1);
		
		//get the courses
		List<Course> courses=tempInstructor.getCourses();
		//list the courses-iterator or foreach or consumer lambda
		courses.forEach(course->System.out.println(course));
		session.getTransaction().commit();
		factory.close();
	}

}
