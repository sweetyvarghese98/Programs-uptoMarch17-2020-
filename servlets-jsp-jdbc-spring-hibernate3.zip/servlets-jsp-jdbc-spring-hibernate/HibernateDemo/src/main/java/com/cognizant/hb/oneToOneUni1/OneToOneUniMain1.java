package com.cognizant.hb.oneToOneUni1;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class OneToOneUniMain1 {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Transaction.class)
				.buildSessionFactory();

Session session=factory.getCurrentSession();

String s1="2012-12-12";
String s2="2012-10-10";
Customer c1=new Customer("sweety","s@gmail.com","pmna");
Customer c2=new Customer("simi","simi@gmail.com","kottayam");
Transaction t1=new Transaction(Date.valueOf(s1),2000);
Transaction t2=new Transaction(Date.valueOf(s2),3000);


c1.setTransaction(t1);
c2.setTransaction(t2);


//begin transaction
session.beginTransaction();
System.out.println("About to save.......");
session.save(c1);
session.save(c2);

//commit
session.getTransaction().commit();
System.out.println("Its done!");
factory.close();
}

}
