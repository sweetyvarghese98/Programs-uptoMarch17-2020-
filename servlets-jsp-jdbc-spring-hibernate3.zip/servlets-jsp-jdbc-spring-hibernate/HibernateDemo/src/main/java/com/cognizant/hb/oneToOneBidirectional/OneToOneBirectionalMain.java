package com.cognizant.hb.oneToOneBidirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToOneBirectionalMain {

	public static void main(String[] args) {
		int id=5;//id should be instructordetail id if we use instructor detail object also if we fetch instructor detail using instructor object
		int id1=3;//id is instructor id if we need instructor data only using instructor object
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail.class)
				.buildSessionFactory();
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		
		  // to insert into individually 
		
		  Instructor theInstructor1=new Instructor("kiran","kumar","kk@gmail.com");
		  Instructor theInstructor2=new Instructor("sweety","simi","ss@gmail.com");
		  InstructorDetail instructorDetail1=new
		  InstructorDetail("youtube/LearnToCode","music"); InstructorDetail
		  instructorDetail2=new InstructorDetail("youtube/Dance","dance");
		  session.save(theInstructor1); session.save(theInstructor2);
		  session.save(instructorDetail1); session.save(instructorDetail2);
		 
		  
		  //to insert into both at sametime 
		 
		
		/*
		 * Instructor theInstructor3=new Instructor("Dhanya","Prabhu","dp@gmail.com");
		 * InstructorDetail instructorDetail3=new
		 * InstructorDetail("youtube/Books","reading");
		 * theInstructor3.setInstructorDetail(instructorDetail3);
		 * session.save(theInstructor3);
		 */
		 
		 
		//from InstructorDetail ,Instructor is obtained,using bidirectional mapping.
		
		  InstructorDetail idetail=session.get(InstructorDetail.class, id); 
		  Instructor instructor=idetail.getInstructor();//only one which have instructordetailid is obtained 
		  System.out.println(instructor);
		  
		  Instructor i1=session.get(Instructor.class, id); 
		 System.out.println(i1);
		 
		 Instructor i2=session.get(Instructor.class, id); 
		  InstructorDetail instructordet=i2.getInstructorDetail();
		  System.out.println(instructordet);
		
		  session.getTransaction().commit();
		factory.close();
	}

}
