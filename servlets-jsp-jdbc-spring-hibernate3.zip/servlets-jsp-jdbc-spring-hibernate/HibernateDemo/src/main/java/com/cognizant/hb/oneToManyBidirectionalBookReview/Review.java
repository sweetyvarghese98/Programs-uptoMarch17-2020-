package com.cognizant.hb.oneToManyBidirectionalBookReview;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="review")
public class Review {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="review_id")
private int rid;
	@Column(name="comments")
private String comment;

@ManyToOne(cascade= {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
@JoinColumn(name="book_id")
private Book book;

public Review() {
	
}

public Review(String comment) {
	
	this.comment = comment;
	
}


public String getComment() {
	return comment;
}

public void setComment(String comment) {
	this.comment = comment;
}

public Book getBook() {
	return book;
}

public void setBook(Book book) {
	this.book = book;
}

@Override
public String toString() {
	return "Review [rid=" + rid + ", comment=" + comment + ", book=" + book + "]";
}

public int getRid() {
	return rid;
}

public void setRid(int rid) {
	this.rid = rid;
}

}
