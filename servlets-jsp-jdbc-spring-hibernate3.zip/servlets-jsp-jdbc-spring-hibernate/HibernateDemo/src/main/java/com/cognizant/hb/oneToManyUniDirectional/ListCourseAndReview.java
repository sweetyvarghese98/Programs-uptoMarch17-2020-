package com.cognizant.hb.oneToManyUniDirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ListCourseAndReview {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg3.xml")
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(Course.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();

Session session=factory.getCurrentSession();
session.beginTransaction();

Course c1=session.get(Course.class,14);
Course c2=session.get(Course.class, 15);
System.out.println(c1);
System.out.println(c1.getReviews());
System.out.println(c2);
System.out.println(c2.getReviews());

session.getTransaction().commit();
factory.close();

	}

}
