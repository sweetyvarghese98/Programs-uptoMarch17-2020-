package com.cognizant.hb.oneToManyBidirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class AddCourseMain {
//adding courses
	public static void main(String[] args) {
		
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg2.xml")
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class)
				.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		  Instructor tempInstructor=session.get(Instructor.class, 1);
		  //Course course1=new Course("ContinentalCooking"); 
		  //Course course2=new Course("how to effectively play pubG");
		  Course course3=new Course("Programming"); 
		//  Course course3=new Course("how to become a MEME creator"); 
		//  Course course4=new Course("how to write poems");
		 
		  //tempInstructor.add(course1);
		  //tempInstructor.add(course2);
		  tempInstructor.add(course3);
		  
		  //session.save(course1); 
		  //session.save(course2);
		  session.save(course3);
		 
		
		session.getTransaction().commit();
		factory.close();

	}

}
