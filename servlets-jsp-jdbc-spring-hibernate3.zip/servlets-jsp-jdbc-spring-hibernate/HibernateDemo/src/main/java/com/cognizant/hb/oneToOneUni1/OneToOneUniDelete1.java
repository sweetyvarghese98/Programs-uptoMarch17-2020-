package com.cognizant.hb.oneToOneUni1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class OneToOneUniDelete1 {

	public static void main(String[] args) {
		int id=2;
		
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Transaction.class)
				.addAnnotatedClass(Customer.class)
				.buildSessionFactory();

Session session=factory.getCurrentSession();
//begin transaction
session.beginTransaction();
Customer c1=session.get(Customer.class,2);
System.out.println("About to delete.......");
if(c1!=null) {
session.delete(c1);//automatically delete the corresponding data from transaction table also
}else
{
	System.out.println("Customer object not available");
}
//commit
session.getTransaction().commit();
System.out.println("Its done!");
factory.close();
}

}
