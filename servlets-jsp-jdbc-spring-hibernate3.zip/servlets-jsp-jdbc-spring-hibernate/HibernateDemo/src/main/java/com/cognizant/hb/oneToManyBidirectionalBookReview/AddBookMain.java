package com.cognizant.hb.oneToManyBidirectionalBookReview;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class AddBookMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
		.configure("hibernate.cfgbook.xml")
		.addAnnotatedClass(Book.class)
		.addAnnotatedClass(Review.class)
		.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		Book b1=new Book("Wings of Fire",850);
		Book b2=new Book("Pride and Prejudice",750);
		
		session.save(b1);
		session.save(b2);
		
		Book breview=session.get(Book.class,1);
		//Review review1=new Review("Inspirational");
		//breview.add(review1);
		//session.save(review1);
		Review review2=new Review("Powerful");
		breview.add(review2);
		session.save(review2);
		
		session.getTransaction().commit();
		factory.close();
		

	}

}
