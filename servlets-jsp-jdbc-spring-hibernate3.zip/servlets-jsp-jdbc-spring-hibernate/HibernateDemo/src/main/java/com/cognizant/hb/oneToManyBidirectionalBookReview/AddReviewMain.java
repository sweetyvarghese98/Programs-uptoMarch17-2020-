package com.cognizant.hb.oneToManyBidirectionalBookReview;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class AddReviewMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfgbook.xml")
				.addAnnotatedClass(Book.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();
				
				Session session=factory.getCurrentSession();
				session.beginTransaction();
				
		//Book tempBook1=session.get(Book.class,1);
		//Review review1=new Review("Inspirational");
		//tempBook1.add(review1);
		//session.save(review1);
		
		Book tempBook2=session.get(Book.class, 2);
		Review review2=new Review("Good");
		tempBook2.add(review2);
		session.save(review2);
		
		session.getTransaction().commit();
		factory.close();

	}

}
