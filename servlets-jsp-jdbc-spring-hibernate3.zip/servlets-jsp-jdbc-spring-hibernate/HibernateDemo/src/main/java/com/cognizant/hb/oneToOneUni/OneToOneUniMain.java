package com.cognizant.hb.oneToOneUni;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToOneUniMain {

	public static void main(String[] args) {
	
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Instructor.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		
		Instructor theInstructor=new Instructor("kiran","kumar","kk@gmail.com");
		Instructor theInstructor1=new Instructor("sweety","simi","ss@gmail.com");
		InstructorDetail instructorDetail=new InstructorDetail("youtube/LearnToCode","music");
		InstructorDetail instructorDetail1=new InstructorDetail("youtube/Dance","dance");
		InstructorDetail instructorDetail2=new InstructorDetail("youtube","dance");
		
		//use setter to set the instructor detail object to instructor object
		theInstructor.setInstructorDetail(instructorDetail);
		theInstructor1.setInstructorDetail(instructorDetail1);//from instructor,instructordetails data is fetched
		
		//begin transaction
		session.beginTransaction();
		System.out.println("About to save.......");
		session.save(theInstructor);
		session.save(theInstructor1);
		session.save(instructorDetail2);
		//commit
		session.getTransaction().commit();
		System.out.println("Its done!");
		factory.close();
	}

}
