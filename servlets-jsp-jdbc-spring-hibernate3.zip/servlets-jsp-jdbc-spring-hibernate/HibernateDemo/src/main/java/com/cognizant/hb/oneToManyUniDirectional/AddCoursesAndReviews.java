package com.cognizant.hb.oneToManyUniDirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class AddCoursesAndReviews {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg3.xml")
				.addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Instructor.class)
				.addAnnotatedClass(Course.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();

Session session=factory.getCurrentSession();
session.beginTransaction();


		/*
		 * Course course1=new Course("Develop application using hibernate"); Review
		 * review1=new Review("Good course!"); Review review2=new Review("Bad Course!");
		 * Review review3=new Review("Do not choose this course");
		 * course1.addReview(review1); course1.addReview(review2);
		 * course1.addReview(review3); session.save(course1);
		 */
Course course2=new Course("Develop application using spring");
Review review4=new Review("Good !");
Review review5=new Review("Bad !");
Review review6=new Review("Do not choose this");
course2.addReview(review4);
course2.addReview(review5);
course2.addReview(review6);
session.save(course2);
System.out.println("done");
session.getTransaction().commit();
factory.close();
	}

}
