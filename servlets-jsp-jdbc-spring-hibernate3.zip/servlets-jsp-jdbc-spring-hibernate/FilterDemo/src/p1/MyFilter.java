package p1;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class MyFilter
 */
public class MyFilter implements Filter {
//filter config created by container
	FilterConfig config;//creating a reference to config object
	public void init(FilterConfig fConfig) throws ServletException {
		this.config=fConfig;//FCONFIG created by tomcat
	}
    public MyFilter() {
        // TODO Auto-generated constructor stub
    }
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		String userName=request.getParameter("username");
		ServletContext ctx=config.getServletContext();
		Date d=new Date();
		//here filter is used to give a log msg.
		ctx.log("The user"+userName+" Logged in on "+d);//display in servlet log of tomcat
		// pass the request along the filter chain
		chain.doFilter(request, response);//request to next filter or next servlet
		//only chain.doFilter know which is next whether there is another filter or no  further filter,so go to servlet.
	}

	
	
	}


