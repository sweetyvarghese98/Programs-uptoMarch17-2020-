package com.cognizant.p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SecondServlet extends HttpServlet {

//to display request headers
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		
PrintWriter out=response.getWriter();
response.setContentType("text/html");
out.println("<html><body>");
Enumeration<String> headerNames=request.getHeaderNames();
while(headerNames.hasMoreElements()) {
	String element=headerNames.nextElement();
	String header=request.getHeader(element);
	
	out.println(element+" : "+header+"<br>");
	out.println("</html></body>");
}

	}
}
