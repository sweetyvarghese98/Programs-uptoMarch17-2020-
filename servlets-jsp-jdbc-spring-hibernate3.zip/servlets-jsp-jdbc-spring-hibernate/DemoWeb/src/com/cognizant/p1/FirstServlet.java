package com.cognizant.p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FirstServlet extends HttpServlet{
	//will handle a HTTP Get request
public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException
{
	String FirstName=request.getParameter("fn");
	String LastName=request.getParameter("ln");
	System.out.println("get");
	PrintWriter out=response.getWriter();
	out.println("<html><body>");
	out.println("<h1> Hi </h1>"+FirstName+" "+LastName);
	out.println("</html></body>");
}


public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException
{
	String FirstName=request.getParameter("fn");
	String LastName=request.getParameter("ln");
	System.out.println("post");
	PrintWriter out=response.getWriter();
	out.println("<html><body>");
	out.println("<h1> Hi </h1>"+FirstName+" "+LastName);
	out.println("</html></body>");
}
}
