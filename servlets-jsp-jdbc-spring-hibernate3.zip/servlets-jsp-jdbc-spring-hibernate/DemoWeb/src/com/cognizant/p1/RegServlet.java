package com.cognizant.p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegServlet extends HttpServlet{
public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
	{	PrintWriter out=response.getWriter();
		out.println("<html><body>");
		out.println("<h3> Customer Details </h3>");
		
		/*String Name=request.getParameter("n");
		String DateOfBirth=request.getParameter("da");
		String Gender=request.getParameter("gen");
		String[] Language =request.getParameterValues("lan");
		String MobileNumber=request.getParameter("mobile");
		String email=request.getParameter("em");
		String address=request.getParameter("ad");
		String hobbies=request.getParameter("dropdown");*/
		
		
		String Name=request.getParameter("Name");
		String DateOfBirth=request.getParameter("Date Of Birth");
		String Gender=request.getParameter("Gender");
		String[] Language =request.getParameterValues("Language");
		String MobileNumber=request.getParameter("MobileNumber");
		String email=request.getParameter("Email");
		String address=request.getParameter("Address");
		String hobbies=request.getParameter("Hobbies");
		
		out.println(" Name:  "+Name);
		out.print("<br/>");
		out.print("<br/>");
		out.println("DOB:  "+DateOfBirth);
		out.print("<br/>");
		out.print("<br/>");
		out.println("Gender:  "+Gender);
		out.print("<br/>");
		out.print("<br/>");
		out.println("Language: ");
		for(int i=0;i<Language.length;i++)
	       {
	           out.println(" * "+" "+Language[i]);
	       }
		out.print("<br/>");
		out.print("<br/>");
		out.println(   "  Mobile Number:  "+MobileNumber);
		out.print("<br/>");
		out.print("<br/>");
		out.println("Email id:  "+email);
		out.print("<br/>");
		out.print("<br/>");
		out.println("Address:  "+address);
		out.print("<br/>");
		out.print("<br/>");
		out.println("Hobbies:  "+hobbies);
		out.print("<br/>");
		out.print("<br/>");
		
		
		// using enumeration
		out.println("<h3>Using Enumeration</h3>");
		
		out.print("<br/>");
		Enumeration<String> parameterNames=request.getParameterNames();
		while(parameterNames.hasMoreElements()) {
			String element=parameterNames.nextElement();
			String parameterValues[]=request.getParameterValues(element);
			String parameter=request.getParameter(element);
			if(parameterValues.length==1)
			{
				out.println(element+" : "+parameter+"<br>");
				out.print("<br/>");
			}
			else {
				out.println("Language: ");
				for(int i=0;i<parameterValues.length;i++)
				{
					out.println(" * "+parameterValues[i]);
				//	out.print("<br/>");
				//	out.print("<br/>");
				}
				
				out.print("<br/>");
				out.print("<br/>");
				
			}
		out.println("</body></html>");
		
	}
}
}
}
