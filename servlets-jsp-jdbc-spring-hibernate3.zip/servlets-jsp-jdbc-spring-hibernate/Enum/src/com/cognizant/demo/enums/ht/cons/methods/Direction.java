package com.cognizant.demo.enums.ht.cons.methods;

public enum Direction {

	// We can add abstract method in enums.
	// In this case,we must implement the abstract method at each enum field
	// individually
	// enum fields

	EAST {

		public String printDirection() {
			String message = "you are moving in east." + "you will face sun in moving time.";
			return message;
		}

	},
	WEST {
		public String printDirection() {
			String message = "you are moving in west." + "you will face sun in evening.";
			return message;
		}

	},
	NORTH {
		public String printDirection() {
			String message = "you are moving in north." + "you will face heat in daytime.";
			return message;
		}

	},
	SOUTH {
		public String printDirection() {
			String message = "you are moving in south." + "you will face sun in moving time.";
			return message;
		}

	};
	public abstract String printDirection();
}

