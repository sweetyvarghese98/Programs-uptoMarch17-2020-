package com.cognizant.demo.enums.ht.cons.methods;

public class MainAbstractDirection {
public static void main(String args[])
{
	System.out.println(Direction.NORTH.printDirection());
	System.out.println(Direction.SOUTH.printDirection());
	
	//comparison
	
	Direction east=Direction.EAST;
	Direction eastNew=Direction.valueOf("EAST");//compare string EAST with enum EAST
	
	System.out.println(east==eastNew);	//true
	System.out.println(east.equals(eastNew));//true
	System.out.println(east.compareTo(eastNew));//0
	
}
}
