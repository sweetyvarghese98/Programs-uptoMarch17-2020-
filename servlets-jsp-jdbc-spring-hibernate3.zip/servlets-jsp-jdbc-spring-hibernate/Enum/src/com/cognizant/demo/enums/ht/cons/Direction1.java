package com.cognizant.demo.enums.ht.cons;


//By default enums dont require constructor definitions and their default values
//are always the string used in the declaration.though,you can give define your own 
//constuctors to initialise the state of enum types.

public enum Direction1 {
//enum field
	EAST(0),WEST(180),NORTH(90),SOUTH(270);
	
	//CONSTRUCTOR//private and default constructors are only possible
	//blank final variable
	private Direction1(int angle)//to give some attributes to enum values ie, 0 is given to east
	//No need to give parameter as final int angle.it s by default static and final
	{
		//this.setAngle(angle);
		this.angle=angle;
	}
	
	//Internal state
	private int angle;
	
	public int getAngle() {
		return angle;
	}
	public void setAngle(int angle)
	{
		this.angle=angle;
	}
	public static Direction1 getValue(String s)
	{
		return Direction1.valueOf(s);
	}
}
