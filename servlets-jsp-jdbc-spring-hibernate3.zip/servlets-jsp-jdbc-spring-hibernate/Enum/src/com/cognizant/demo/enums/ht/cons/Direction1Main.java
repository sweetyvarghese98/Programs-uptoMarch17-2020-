package com.cognizant.demo.enums.ht.cons;

public class Direction1Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Direction1 north=Direction1.NORTH;
System.out.println(north);//NORTH
System.out.println(north.getAngle());//90
north.setAngle(45);
System.out.println(Direction1.NORTH.getAngle());//45
System.out.println(Direction1.SOUTH.getClass());//class com.cognizant.....//object class' method
System.out.println(Direction1.EAST.toString());//EAST//object class' method
System.out.println(Direction1.getValue("WEST"));//WEST

	}

}
