package enumSet;

import java.util.EnumSet;
import java.util.Set;

import com.cognizant.demo.enums.ht.cons.methods.Direction;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Set<Direction> enumSet=EnumSet.of(Direction.EAST,
			Direction.WEST,
			Direction.NORTH,
			Direction.SOUTH
			);
enumSet.forEach(str->System.out.println(str));
	}

}
//enums can implements any no. of interfaces
//java.util.EnumSet

//EnumSet class is defined as follows;
/* public abstract class EnumSet<E extends Enum<E>>
                         extends AbstractSet<E>
                         implements Cloneable,serializable,Iterable{
                         }*/
