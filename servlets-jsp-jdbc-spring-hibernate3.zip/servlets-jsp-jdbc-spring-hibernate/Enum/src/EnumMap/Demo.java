package EnumMap;

import java.util.EnumMap;
import java.util.Map;

import com.cognizant.demo.enums.ht.cons.Direction1;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Map<Direction1,Integer> enumMap=new EnumMap<Direction1,Integer>(Direction1.class);

//populate the Map

enumMap.put(Direction1.EAST,Direction1.EAST.getAngle());
enumMap.put(Direction1.WEST,Direction1.WEST.getAngle());
enumMap.put(Direction1.NORTH,Direction1.NORTH.getAngle());
enumMap.put(Direction1.SOUTH,Direction1.SOUTH.getAngle());
System.out.println(enumMap);
	}
//ENUMS CAN IMPLEMENT ANY INTERFACE.BUT CANT EXTEND CLASS
}


