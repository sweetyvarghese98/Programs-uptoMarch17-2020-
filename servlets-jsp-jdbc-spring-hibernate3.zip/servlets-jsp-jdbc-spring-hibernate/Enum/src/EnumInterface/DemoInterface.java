package EnumInterface;
interface Flyer{
	public void fly();
}
public class DemoInterface {
public static void main(String args[])
{
	enum patrol implements Flyer{"CHASE","RUBBLE","APPOLLO";

	
	}
}
