package Enums;


//enum is a set of strings which are static and final.once declared it is constant.
public enum Direction {
EAST,WEST,NORTH,SOUTH//constants//index=0,1,2,3.....
	}

