DROP SCHEMA IF EXISTS `hb-02-one-to-one-uni`;

CREATE SCHEMA `hb-02-one-to-one-uni`;

use `hb-02-one-to-one-uni`;
SET FOREIGN_KEY_CHECKS = 0;

create table account(id int(11) NOT NULL AUTO_INCREMENT,
					account_number varchar(100) DEFAULT NULL,
                    PRIMARY KEY(id))Engine innoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
                    


create table employee(id int(11) NOT NULL AUTO_INCREMENT,
						email varchar(100) DEFAULT NULL,
                        first_name varchar(100) DEFAULT NULL,
                          last_name varchar(100) DEFAULT NULL,
                        Account_id int(11),
                        PRIMARY KEY(id),FOREIGN KEY(Account_id) REFERENCES account(id))
                        Engine innoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
                        
                        
select * from account;
select * from employee;
drop table employee;