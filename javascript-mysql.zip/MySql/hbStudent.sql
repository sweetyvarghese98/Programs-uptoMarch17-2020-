CREATE USER 'hbstudent'@'localhost' IDENTIFIED BY 'hbstudent';-- user and password,ie user with password is created

GRANT ALL PRIVILEGES ON * . * TO 'hbstudent'@'localhost';-- given all privileges to hbstudent