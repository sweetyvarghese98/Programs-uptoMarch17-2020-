create database student_db;
use student_db;
create table student(
s_No int(3),
s_Name varchar(20),
s_dob date);
insert into student values(100,'Sweety','1998/01/09');
insert into student values(101,'Dhanya','1997/02/10');
insert into student values(102,'Parvathy','1998/03/10');
select * from student;


