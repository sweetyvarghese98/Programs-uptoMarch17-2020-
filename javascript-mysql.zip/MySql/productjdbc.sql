 create database new_product_db;
 use new_product_db;

create table product(product_id int(3),
product_name varchar(20),
price double(7,2),
dateOfManufacture date);
/*
insert into product values(100,'TV',36000,'20-01-1998');
insert into product values(101,'FRIDGE',56000,'26-02-1999');
insert into product values(102,'AC',36000,'24-01-2008');
insert into product values(103,'MIXIE',10000,'21-01-2004');
insert into product values(104,'OVEN',16000,'22-01-2009');
insert into product values(105,'WASHING MACHINE',26000,'10-01-2000');
drop table product;*/

