create database customer_db;
use customer_db;
create table customer(customer_id int(4),
						customer_name varchar(20),
                        customer_phone varchar(20),
                        customer_email varchar(20));
insert into customer values(100,'sweety',1234567897,'asgfdh@gmail.com');
select * from customer;
-- drop table customer;
create table user(user_name varchar(10),
					user_password varchar(10));
                    
insert into user values('cts100','100');
insert into user values('cts101','101');
insert into user values('cts102','102');
insert into user values('cts103','103');
insert into user values('cts104','104');