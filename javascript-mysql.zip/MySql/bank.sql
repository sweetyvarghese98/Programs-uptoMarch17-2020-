drop DATABASE BMS_DB;
create DATABASE BMS_DB;
use BMS_DB;

-- CUSTOMER_PERSONAL_INFO

CREATE TABLE CUSTOMER_PERSONAL_INFO
(
 CUSTOMER_ID VARCHAR(5),
 CUSTOMER_NAME VARCHAR(30),
 DATE_OF_BIRTH  DATE,
 GUARDIAN_NAME VARCHAR(30),
 ADDRESS VARCHAR(50),
 CONTACT_NO BIGINT(10),
 MAIL_ID  VARCHAR(30),
 GENDER CHAR(1),
 MARITAL_STATUS VARCHAR(10),
 IDENTIFICATION_DOC_TYPE VARCHAR(20),
 ID_DOC_NO VARCHAR(20),
 CITIZENSHIP VARCHAR(10),
 CONSTRAINT CUST_PERS_INFO_PK PRIMARY KEY(CUSTOMER_ID)
);

-- CUSTOMER_REFERENCE_INFO

CREATE TABLE CUSTOMER_REFERENCE_INFO
(
  CUSTOMER_ID VARCHAR(5),
  REFERENCE_ACC_NAME  VARCHAR(20),
  REFERENCE_ACC_NO BIGINT(16),
  REFERENCE_ACC_ADDRESS VARCHAR(50),
  RELATION VARCHAR(25),
  CONSTRAINT CUST_REF_INFO_PK PRIMARY KEY(CUSTOMER_ID),
  CONSTRAINT CUST_REF_INFO_FK FOREIGN KEY(CUSTOMER_ID) REFERENCES   CUSTOMER_PERSONAL_INFO(CUSTOMER_ID)
);

-- BANK_INFO

CREATE TABLE BANK_INFO
(
  IFSC_CODE   VARCHAR(15),
  BANK_NAME   VARCHAR(25),
  BRANCH_NAME VARCHAR(25),
  CONSTRAINT BANK_INFO_PK PRIMARY KEY(IFSC_CODE)
);



-- ACCOUNT_INFO

CREATE TABLE ACCOUNT_INFO
(
 ACCOUNT_NO BIGINT(16),
 CUSTOMER_ID VARCHAR(5),
 ACCOUNT_TYPE VARCHAR(10),
 REGISTRATION_DATE DATE,
 ACTIVATION_DATE DATE,
 IFSC_CODE VARCHAR(10),
 INTEREST DECIMAL(7,2),
 INITIAL_DEPOSIT BIGINT(10),   
 CONSTRAINT ACC_INFO_PK PRIMARY KEY(ACCOUNT_NO),
 CONSTRAINT ACC_INFO_PERS_FK FOREIGN KEY(CUSTOMER_ID) REFERENCES CUSTOMER_PERSONAL_INFO(CUSTOMER_ID),
 CONSTRAINT ACC_INFO_BANK_FK FOREIGN KEY(IFSC_CODE) REFERENCES BANK_INFO(IFSC_CODE)
);


-- BANK_INFO


INSERT INTO BANK_INFO(IFSC_CODE,BANK_NAME,BRANCH_NAME)VALUES('HDVL0012','HDFC','VALASARAVAKKAM');
INSERT INTO BANK_INFO(IFSC_CODE,BANK_NAME,BRANCH_NAME) VALUES('SBITN0123','SBI','TNAGAR');
INSERT INTO BANK_INFO(IFSC_CODE,BANK_NAME,BRANCH_NAME) VALUES('ICITN0232','ICICI','TNAGAR');
INSERT INTO BANK_INFO(IFSC_CODE,BANK_NAME,BRANCH_NAME) VALUES('ICIPG0242','ICICI','PERUNGUDI');
INSERT INTO BANK_INFO(IFSC_CODE,BANK_NAME,BRANCH_NAME) VALUES('SBISD0113','SBI','SAIDAPET');

-- CUSTOMER_PERSONAL_INFO

INSERT INTO CUSTOMER_PERSONAL_INFO(CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_BIRTH,GUARDIAN_NAME,ADDRESS,CONTACT_NO,MAIL_ID,GENDER,MARITAL_STATUS,IDENTIFICATION_DOC_TYPE,ID_DOC_NO,CITIZENSHIP) VALUES('C-001','JOHN','1984-05-03','PETER','NO.14, ST.MARKS ROAD,BANGALORE',9734526719,'JOHN_123@gmail.com','M','SINGLE','PASSPORT','PASS123','INDIAN');
INSERT INTO CUSTOMER_PERSONAL_INFO(CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_BIRTH,GUARDIAN_NAME,ADDRESS,CONTACT_NO,MAIL_ID,GENDER,MARITAL_STATUS,IDENTIFICATION_DOC_TYPE,ID_DOC_NO,CITIZENSHIP) VALUES('C-002','JAMES','1984-08-06','GEORGE','NO.18, MG ROAD,BANGALORE',9237893481,'JAMES_123@gmail.com','M','MARRIED','PASSPORT','PASS124','INDIAN');
INSERT INTO CUSTOMER_PERSONAL_INFO(CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_BIRTH,GUARDIAN_NAME,ADDRESS,CONTACT_NO,MAIL_ID,GENDER,MARITAL_STATUS,IDENTIFICATION_DOC_TYPE,ID_DOC_NO,CITIZENSHIP) VALUES('C-003','SUNITHA','1984-11-06','VINOD','NO.21, GM ROAD,CHENNAI',9438978389,'SUNITHA_123@gmail.com','F','SINGLE','VOTER-ID','GMV1234','INDIAN');
INSERT INTO CUSTOMER_PERSONAL_INFO(CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_BIRTH,GUARDIAN_NAME,ADDRESS,CONTACT_NO,MAIL_ID,GENDER,MARITAL_STATUS,IDENTIFICATION_DOC_TYPE,ID_DOC_NO,CITIZENSHIP) VALUES('C-004','RAMESH','1985-12-11','KRISHNAN','NO.14,LB ROAD,CHENNAI',9235234534,'RAMESH_123@gmail.com','M','MARRIED','PASSPORT','PASS125','INDIAN');
INSERT INTO CUSTOMER_PERSONAL_INFO(CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_BIRTH,GUARDIAN_NAME,ADDRESS,CONTACT_NO,MAIL_ID,GENDER,MARITAL_STATUS,IDENTIFICATION_DOC_TYPE,ID_DOC_NO,CITIZENSHIP) VALUES('C-005','KUMAR','1983-04-26','KIRAN','NO.18,MM ROAD,BANGALORE',9242342312,'KUMAR_123@gmail.com','M','SINGLE','PASSPORT','PASS126','INDIAN');



-- CUSTOMER_REFERENCE_INFO

INSERT INTO CUSTOMER_REFERENCE_INFO(CUSTOMER_ID,REFERENCE_ACC_NAME,REFERENCE_ACC_NO,REFERENCE_ACC_ADDRESS,RELATION) VALUES('C-001','RAM',0987654321122345,'NO.11,BRIGRADE ROAD,BANGALORE','FRIEND');
INSERT INTO CUSTOMER_REFERENCE_INFO(CUSTOMER_ID,REFERENCE_ACC_NAME,REFERENCE_ACC_NO,REFERENCE_ACC_ADDRESS,RELATION) VALUES('C-002','RAGHUL',0987654321122346,'NO.21,CUNNGHAM ROAD,BANGALORE','FRIEND');
INSERT INTO CUSTOMER_REFERENCE_INFO(CUSTOMER_ID,REFERENCE_ACC_NAME,REFERENCE_ACC_NO,REFERENCE_ACC_ADDRESS,RELATION) VALUES('C-003','GOKUL',0987654321122357,'NO.12,OMR,CHENNAI','NEIGHBOUR');
INSERT INTO CUSTOMER_REFERENCE_INFO(CUSTOMER_ID,REFERENCE_ACC_NAME,REFERENCE_ACC_NO,REFERENCE_ACC_ADDRESS,RELATION) VALUES('C-004','RAHMAN',0987654321122348,'NO.35,ECR,CHENNAI','FRIEND');
INSERT INTO CUSTOMER_REFERENCE_INFO(CUSTOMER_ID,REFERENCE_ACC_NAME,REFERENCE_ACC_NO,REFERENCE_ACC_ADDRESS,RELATION) VALUES('C-005','VIVEK',0987654321122359,'NO.78,JAYA NAGAR,BANGALORE','NEIGHBOUR');


-- ACCOUNT_INFO


INSERT INTO ACCOUNT_INFO(ACCOUNT_NO,CUSTOMER_ID,ACCOUNT_TYPE,REGISTRATION_DATE,ACTIVATION_DATE,IFSC_CODE,INTEREST, INITIAL_DEPOSIT) VALUES(1234567898765432,'C-001','SAVINGS','2012-02-23','2012-02-28','HDVL0012',5,10000); 
INSERT INTO ACCOUNT_INFO(ACCOUNT_NO,CUSTOMER_ID,ACCOUNT_TYPE,REGISTRATION_DATE,ACTIVATION_DATE,IFSC_CODE,INTEREST, INITIAL_DEPOSIT) VALUES(1234567898765433,'C-002','SALARY','2012-03-12','2012-03-17','SBITN0123',6,0 ); 
INSERT INTO ACCOUNT_INFO(ACCOUNT_NO,CUSTOMER_ID,ACCOUNT_TYPE,REGISTRATION_DATE,ACTIVATION_DATE,IFSC_CODE,INTEREST, INITIAL_DEPOSIT) VALUES(1234567898765434,'C-003','SAVINGS','2012-03-15','2012-03-20','ICITN0232',4,16000 ); 
INSERT INTO ACCOUNT_INFO(ACCOUNT_NO,CUSTOMER_ID,ACCOUNT_TYPE,REGISTRATION_DATE,ACTIVATION_DATE,IFSC_CODE,INTEREST, INITIAL_DEPOSIT) VALUES(1234567898765435,'C-004','SALARY','2012-04-05','2012-04-10','HDVL0012',7,0);
INSERT INTO ACCOUNT_INFO(ACCOUNT_NO,CUSTOMER_ID,ACCOUNT_TYPE,REGISTRATION_DATE,ACTIVATION_DATE,IFSC_CODE,INTEREST, INITIAL_DEPOSIT) VALUES(1234567898765436,'C-005','SAVINGS','2012-04-12','2012-04-17','SBISD0113',8,20000); 
                                        
-- 1                                        
select customer_id,account_type,account_no,bank_name from account_info a join bank_info b on(a.ifsc_code=b.ifsc_code);

-- 2
select customer_id,account_type,account_no from account_info a join bank_info b on(a.ifsc_code=b.ifsc_code) where b.bank_name='HDFC' AND a.registration_date between '2012-01-12' and '2012-04-04';
select customer_id,account_type,account_no from account_info a join bank_info b on(a.ifsc_code=b.ifsc_code) where bank_name='HDFC' AND registration_date between '2012-01-12' and '2012-04-04';


-- 3
select a.customer_id,customer_name,account_type,bank_name from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id)join bank_info b on(a.ifsc_code=b.ifsc_code);

-- 4
select customer_id,customer_name,gender,marital_status,concat(customer_name,"_",marital_status) UNIQUE_REF_STRING from customer_personal_info order by customer_id desc;

-- 5
select account_no,customer_id,registration_date,initial_deposit from account_info where initial_deposit between 15000 and 25000;


-- 6(a)
select customer_id,customer_name,date_of_birth,guardian_name from customer_personal_info where customer_name like 'J%';

-- 6(b)
select customer_id,account_no,concat(substr(customer_id,3),substr(account_no,13))PASSCODE from account_info;


-- 7
select customer_id,customer_name,date_of_birth,marital_status,gender,guardian_name,contact_no,mail_id from customer_personal_info where gender='M' and marital_status='Married';

-- 8
select cpi.customer_id,customer_name,guardian_name,reference_acc_name from customer_personal_info cpi join customer_reference_info cri on(cpi.customer_id=cri.customer_id) where relation='FRIEND'; 

-- 9
select a.customer_id,account_no,concat('$',round(interest)) INTEREST from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id) order by INTEREST;


-- 10
select cpi.customer_id,customer_name,account_no,account_type,activation_date,bank_name from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id) join bank_info b on(a.ifsc_code=b.ifsc_code) where activation_date='2012-04-10';

-- 11
select a.customer_id,customer_name,bank_name,branch_name,a.ifsc_code,citizenship,interest,initial_deposit from customer_personal_info cpi join account_info a on (cpi.customer_id=a.customer_id) join bank_info bi on (a.ifsc_code=bi.ifsc_code);

-- 12
select cpi.customer_id,customer_name,date_of_birth,guardian_name,contact_no,mail_id,reference_acc_name from customer_personal_info cpi join customer_reference_info cri on (cpi.customer_id=cri.customer_id) where identification_doc_type='PASSPORT';

-- 13
select cpi.customer_id,customer_name,account_no,account_type,initial_deposit,interest from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id) where initial_deposit=(select max(initial_deposit) from account_info);

-- 14
select cpi.customer_id,customer_name,account_no,account_type,interest,bank_name,initial_deposit from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id) join bank_info b on(a.ifsc_code=b.ifsc_code)  where interest=(select max(interest) from account_info);

-- 15
select cpi.customer_id,customer_name,account_no,bank_name,contact_no,mail_id from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id) join bank_info b on(a.ifsc_code=b.ifsc_code)  where address like '%BANGALORE';

-- 16
select cpi.customer_id,customer_name,branch_name,a.ifsc_code,registration_date,activation_date from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id) join bank_info b on(a.ifsc_code=b.ifsc_code)  where activation_date like '%-03%';

-- 17
select cpi.customer_id,customer_name,account_no,account_type,((interest/100)*initial_deposit)interest_amt from customer_personal_info cpi join account_info a on(cpi.customer_id=a.customer_id);

-- 18
select cpi.customer_id,customer_name,date_of_birth,contact_no,mail_id from customer_personal_info cpi join customer_reference_info cri on (cpi.customer_id=cri.customer_id) where reference_acc_name like '%RAGHUL%' ;


-- 19
select customer_id,customer_name,concat('91','-',substr(contact_no,1,3),'-',substr(contact_no,4,3),'-',substr(contact_no,7,10)) CONTACT_ISD from customer_personal_info ;

-- 20
select cpi.customer_id,customer_name,date_of_birth,guardian_name,contact_no,mail_id,gender,reference_acc_name,reference_acc_no,registration_date,activation_date,(registration_date-activation_date) NoOfDaysForActivation ,bank_name,branch_name,initial_deposit from customer_reference_info cri join customer_personal_info cpi on (cri.customer_id=cpi.customer_id) join account_info ai on (cpi.customer_id=ai.customer_id) join bank_info bi on(ai.ifsc_code= bi.ifsc_code)  ;
 
-- 21
select cpi.customer_id,customer_name,guardian_name,identification_doc_type,reference_acc_name,account_type,ai.ifsc_code,bank_name,(round(initial_deposit+interest))current_balance from customer_reference_info cri join customer_personal_info cpi on (cri.customer_id=cpi.customer_id) join account_info ai on (cpi.customer_id=ai.customer_id) join bank_info bi on(ai.ifsc_code= bi.ifsc_code) where account_type='SAVINGS' ;


-- 22
select cpi.customer_id,customer_name,account_no,account_type,interest, case 
when initial_deposit=20000 then 'HIGH'
when initial_deposit=16000 then 'MODERATE'
when initial_deposit=10000 then 'AVERAGE'
when initial_deposit=5000 then 'LOW'
when initial_deposit=0 then 'VERYLOW'
else 'INVALID' end 'DepositStatus' from customer_personal_info cpi join  account_info ai on (cpi.customer_id=ai.customer_id) order by interest desc;

-- 23
select cpi.customer_id,customer_name,account_no,account_type,bank_name,ai.ifsc_code,initial_deposit,interest,
case  when account_type='SAVINGS' then (interest+0.1*interest)
else interest  end 'NewInterest'
from customer_personal_info cpi join account_info ai on (cpi.customer_id=ai.customer_id) join bank_info bi on (ai.ifsc_code=bi.ifsc_code) where customer_name like 'J%';

-- 24
select cpi.customer_id,customer_name,account_no,initial_deposit, 
case when initial_deposit=0 then 'o%'
when initial_deposit<=10000 then '3%'
when initial_deposit>10000 and initial_deposit<20000 then '5%'
when initial_deposit>=20000 and initial_deposit<=30000 then '7%'
when initial_deposit>30000 then '10%' 
end 'taxPercentage'
from customer_personal_info cpi join account_info ai on(cpi.customer_id=ai.customer_id);