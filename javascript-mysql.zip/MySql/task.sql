create database distributor_db;
use distributor_db;


-- Distributor Info table
create table Distributor
(
Distributor_ID varchar(10) ,
Distributor_Name varchar(20),
Address varchar(100),
Mobile BIGINT(10),
Email varchar(30), constraint pk_distributor primary key(Distributor_ID) );

-- Mobile master table
create table Mobile_Master
(
IME_No varchar(10), Model_Name varchar(20), Manufacturer varchar(20), Date_Of_Manufac date,
Warranty_in_Years INT, Price DECIMAL(7,2), Distributor_ID varchar(10),
constraint pk_ime primary key(IME_No),foreign key(Distributor_ID) references Distributor(Distributor_ID)
);

-- Mobile specification table
create table Mobile_Specification
(
IME_No varchar(10), Dimension varchar(20), Weight varchar(20),Display_Type varchar(20), Display_Size varchar(20),
Internal_mem_in_MB INT, Memory_Card_Capacity_GB INT, Network_3G varchar(5),GPRS varchar(5), EDGE varchar(5), Bluetooth varchar(5),
Camera varchar(5), Camera_Quality varchar(5) , OS varchar(20), Battery_Life_Hrs INT ,
constraint fk_ime foreign key(IME_No) references Mobile_Master(IME_No)
);

-- Customer Information table
create table Customer_Info
(
Customer_ID varchar(10) ,
Customer_Name varchar(20),
Address varchar(100),
Mobile BIGINT(10),
Email varchar(30),constraint pk_customer primary key(Customer_ID));

-- Sales information table
create table Sales_Info
(
SalesId INT,
Sales_Date date,IME_No varchar(10),Price INT,Discount INT,Net_Amount INT,Customer_ID varchar(10),Model_Name varchar(20),
constraint fk_sales primary key(SalesId),foreign key(Customer_ID) references Customer_Info(Customer_ID), foreign key(IME_No) references Mobile_Master(IME_No));




-- Data for Distributor table
insert into Distributor values('D001','AXA Ltd','4th Floor CDG Avenue',9897874563,'axaltd@gmail.com');
insert into Distributor values('D002','KK Ditributors','Rajiv Gandhi Salai,Chennai',9112225632,'kandk@rocketmail.com');
insert into Distributor values('D003','Vasanth Traders','NDR Building,Chennai',9844555883,'vasanth@gmail.com');

-- Data for Mobile_Master table
insert into Mobile_master values('MC1000100','Nokia C5-03','Nokia','2005-05-11',1,9500,'D001');
insert into Mobile_master values('MC1000102','Nokia Lumia','Nokia','2011-08-16',2,35350,'D001');
insert into Mobile_master values('MC1000103','Samsung GalaxyTAB','Samsung','2010-05-06',2,32338,'D001');
insert into Mobile_master values('MC1000104','Samsung Galaxy Y','Samsung','2010-05-19',1,24569,'D001');
insert into Mobile_master values('MC1000105','Nokia 5230','Nokia','2003-03-09',1,6123,'D002');
insert into Mobile_master values('MC1000106','Samsung C3010','Samsung','2005-04-19',1,4000,'D002');
insert into Mobile_master values('MC1000107','Sony Experia','Sony Erricson','2011-05-30',1,16500,'D003');
insert into Mobile_master values('MC1000108','Nokia 1100','Nokia','2001-03-01',1,2100,'D003');
insert into Mobile_master values('MC1000109','Nokia C5-03','Nokia','05-03-09',1,9500,'D001');
insert into Mobile_master values('MC1000110','Samsung GalaxyTAB','Samsung','2010-06-05',2,32338,'D002');
insert into Mobile_master values('MC1000111','Nokia C5-03','Nokia','2005-03-09',1,9500,'D001');

-- Data for Mobile_Specification
insert into Mobile_Specification values('MC1000100','105.8 x 51 x 13.8 mm','93g','TFT  touchscreen','360 x 640 pixels',128,16,'Yes','Yes','Yes','Yes','Yes','5MP','Symbian OS v9.4',600);
insert into Mobile_Specification values('MC1000102','116.5 x 61.2 mm','142g','AMOLED touchscreen','480 x 800 pixels',512,16,'Yes','Yes','Yes','Yes','Yes','8MP','Windows 7.5 Mango',210);
insert into Mobile_Specification values('MC1000103','256.6x175.3 x 9.7 mm','581g','PLS TFT touchscreen','800 x 1280 pixels',1024,32,'Yes','Yes','Yes','Yes','Yes','3.5MP','Android OS, v4.0.3',320);
insert into Mobile_Specification values('MC1000104','109.8 x 60 x 12 mm','109g','TFT touchscreen','240 x 320  pixels',160,32,'Yes','Yes','Yes','Yes','Yes','3.5MP','Android OS, v2.3',360);
insert into Mobile_Specification values('MC1000105','108 x 43.5 x 10.5 mm','78g','TFT, 256K colors','240 x 320 pixels',30,8,'No','Yes','Yes','Yes','Yes','2MP','Nokia OS',406);
insert into Mobile_Specification values('MC1000106','76 x 43.5 x 7.5 mm','82g','TFT,65K colors','120 x 120 pixels',10,2,'No','Yes','Yes','Yes','Yes','VGA','SOS',1200);
insert into Mobile_Specification values('MC1000107','256.6x175.3 x 9.7 mm','95g','TFT touchscreen','240 x 320  pixels',160,16,'Yes','Yes','Yes','Yes','Yes','5MP','Android OS, v2.3',390);
insert into Mobile_Specification values('MC1000108','76 x 43.5 x 7.5 mm','82g','TFT,65K colors','120 x 120 pixels',10,2,'No','No','No','No','No','VGA','Nokia OS',1200);

-- Data for Customer_Info table
insert into Customer_Info values('C001','Shyam',' No.3/5,serene flats Chennai-96',9962100341,'shyam23@gmail.com');
insert into Customer_Info values('C002','Asha',' No.6/2, Gandhi Nagar, Adyar Chennai-20',8952100123,'Asha46@rediffmail.com');
insert into Customer_Info values('C003','Mano',' No.12, Camp Road,Tambaram Chennai-80',9841400341,'mano_sundar@gmail.com');
insert into Customer_Info values('C004','Naresh',' No.46,Lotus Garden,Kilpauk Chennai-32',8962122346,'Naresh12@yahoo.co.in');

-- Data for Sales_Info table
insert into Sales_Info values(1001,'2012-04-20','MC1000100',9500,2000,7500,'C001','Nokia C5-03');
insert into Sales_Info values(1002,'2012-04-21','MC1000102',35350,350,35000,'C001','Nokia Lumia');
insert into Sales_Info values(1003,'2012-04-21','MC1000103',32338,338,32000,'C002','Samsung GalaxyTAB');
insert into Sales_Info values(1004,'2012-04-22','MC1000104',32338,338,32000,'C003','Samsung Galaxy Y');
insert into Sales_Info values(1005,'2012-04-23','MC1000105',6123,123,6000,'C004','Nokia 5230');
insert into Sales_Info values(1006,'2012-04-23','MC1000108',2100,100,2000,'C003','Nokia 1100');
insert into Sales_Info values(1007,'2012-04-23','MC1000109',2100,100,2000,'C003','Nokia C5-03');
insert into Sales_Info values(1008,'2012-04-23','MC1000111',2100,100,2000,'C003','Nokia C5-03');

select * from Mobile_master;
-- 1
select IME_No,Model_Name from Mobile_master where Manufacturer='Nokia';
-- 2
select ms.IME_No,Model_Name,Manufacturer,Camera_Quality from Mobile_master mm join Mobile_Specification ms on(mm.IME_No=ms.IME_No) where Camera_Quality='5MP';
-- 3
select Model_Name,count(*) noOfMobilesSold from Sales_Info where  Sales_Date='2012-04-23'  group by Model_Name;                          
 Drop table distributor;
 Drop table Mobile_master;
 Drop table Mobile_Specification;
 Drop table Customer_Info;
 Drop table Sales_Info;
-- 4
select  Distributor_ID ,Model_Name,count(*) NoOfMobilesSupplied from Mobile_master group by Model_Name,Distributor_ID order by Distributor_ID;

-- 5
select mm.IME_No,mm.Model_Name,mm.Manufacturer,mm.price,si.discount from Mobile_Master mm left outer join Sales_Info si on(mm.IME_No=si.IME_No);
-- 6
select d.Distributor_Name,d.Mobile,d.Email from distributor d ,Mobile_master  where Model_Name='Nokia 1100';

-- 7
select m.IME_No,m.Model_Name from Mobile_master m left outer join Sales_Info s on(m.IME_No=s.IME_No) where Customer_ID is Null;


select IME_No,Model_Name from Sales_Info where Net_Amount=(select max(Net_Amount) from Sales_Info) ;

-- 8
select IME_No,Model_Name,Manufacturer,Price,Price+(Price*10/100) NewPrice from  Mobile_master;

select Model_Name,Manufacturer,Price from  Mobile_master where Price between 8500 and 25300;

-- wrong->select m.IME_No, m.Model_Name,m.Manufacturer,m.Price,m.Warranty_in_Years ,ms.Internal_mem_in_MB,ms.Memory_Card_Capacity_GB,ms.GPRS,ms.Bluetooth,ms.Camera_Quality,ms.OS from Mobile_master m,Mobile_Specification ms where m.IME_No='MC1000104';
select  m.Model_Name,m.Manufacturer,m.Price,m.Warranty_in_Years ,ms.Internal_mem_in_MB,ms.Memory_Card_Capacity_GB,ms.GPRS,ms.Bluetooth,ms.Camera_Quality,ms.OS from Mobile_master m join Mobile_Specification ms on(m.IME_No=ms.IME_No) where m.IME_No='MC1000104';

-- 9
select m.IME_No,m.Model_Name,m.Manufacturer,m.Price,ms.GPRS,ms.Memory_Card_Capacity_GB from Mobile_master m join Mobile_Specification ms on (m.IME_No=ms.IME_No) where GPRS='YES' AND ms.Memory_Card_Capacity_GB >='16GB';
-- wrong ->select m.IME_No,m.Model_Name,m.Manufacturer,m.Price,ms.GPRS,ms.Memory_Card_Capacity_GB from Mobile_master m join Mobile_Specification ms  where GPRS='YES' AND ms.Memory_Card_Capacity_GB >='16GB';

-- 10
-- wrong ->select Customer_Name,IME_No,Model_Name,Sales_Date,Net_Amount from Customer_Info ,Sales_Info order by Customer_Name;
select Customer_Name,IME_No,Model_Name,Sales_Date,Net_Amount from Customer_Info c join Sales_Info s on (c.Customer_ID=s.Customer_ID)  order by Customer_Name;


-- 11
Select m.IME_No,m.Model_Name, m.Manufacturer, m.Price,ifnull(s.Discount,'Not Sold')Discount from Mobile_master m left outer join Sales_info s on (m.IME_No=s.IME_No);

-- 12
select Sales_Date,Net_Amount TotalNetAmount from Sales_Info where Sales_Date between '2012-04-20' and '2012-04-25'; 

-- 13
select mm.IME_No,Model_Name,Manufacturer,Price,Battery_Life_Hrs from Mobile_master mm join Mobile_Specification ms on(mm.IME_No=ms.IME_No) where Battery_Life_Hrs=(select max(Battery_Life_Hrs) from Mobile_Specification);

-- 14
select IME_No,Model_Name,Manufacturer,Price from Mobile_master m where Price=(select max(Price) from Mobile_master);


-- 15
select si.Customer_ID,ci.Customer_Name,ci.Address,sum(Net_Amount) TotalNetAmount from Customer_Info ci join Sales_Info si on(si.Customer_ID=ci.Customer_ID)  group by si.Customer_ID;

-- 16
select Model_Name,Price from Mobile_master where Manufacturer like 'samsung%' AND Price=(select max(p) from (select Price p from Mobile_master where Manufacturer like 'samsung%' group by Model_Name having count(*)=1)t) group by Model_Name having count(*)=1;
select distinct Model_Name ,Manufacturer,max(Price) from Mobile_master where  Manufacturer='samsung';
select distinct Model_Name,Manufacturer,Price from Mobile_master where Price=(select max(Price) from Mobile_master where Manufacturer='samsung');

-- 17
select IME_No,Model_Name,Manufacturer,d.Distributor_ID,Distributor_Name,m.Price from distributor d join Mobile_master m on(d.Distributor_ID=m.Distributor_ID) where Distributor_Name='AXA Ltd';

-- 18
select d.Distributor_ID,Distributor_Name,Address,Mobile,Email from distributor d join Mobile_Master m on (d.Distributor_ID=m.Distributor_ID) having count(*)=(select max(cnt) from (select count(*) cnt from Mobile_master)t1 group by d.Distributor_ID);
select d.Distributor_ID,Distributor_Name,Address,Mobile,Email from distributor d join Mobile_Master m on (d.Distributor_ID=m.Distributor_ID) having count(*)=(select max(cnt) from (select count(Distributor_ID) cnt from Mobile_master)t1 );

-- 19
select ci.Customer_ID,Customer_Name,Address from Customer_Info ci join Sales_Info si on(ci.Customer_ID=si.Customer_ID) having max(Net_Amount)=(select max(Net_Amount) from Sales_Info  group by ci.Customer_ID) ;

-- 20
select m.IME_No,m.Model_Name,if(SalesId is null,'-','Sold Out') SalesStatus from Mobile_master m left outer join Sales_Info s on (m.IME_No=s.IME_No) having Model_Name like 'Samsung GalaxyTAB' ;
select m.IME_No,m.Model_Name,if(SalesId is null,'-','Sold Out') SalesStatus from Mobile_master m left outer join Sales_Info s on (m.IME_No=s.IME_No) ;

-- 21
select d.Distributor_ID,d.Distributor_Name,d.Address,d.Mobile  from distributor d join Mobile_master m on (d.Distributor_ID=m.Distributor_ID) join Mobile_Specification ms on(m.IME_No=ms.IME_No) where Network_3G ='yes' AND (OS='Android OS, v4.0.3' OR OS='Android OS, v2.3') AND Camera_Quality='3.5MP' group by Distributor_ID;
select d.Distributor_ID,d.Distributor_Name,d.Address,d.Mobile  from distributor d join Mobile_master m on (d.Distributor_ID=m.Distributor_ID) join Mobile_Specification ms on(m.IME_No=ms.IME_No) where Network_3G ='yes' AND OS like 'Android%' AND Camera_Quality='3.5MP' group by Distributor_ID;
select distinct d.Distributor_ID,d.Distributor_Name,d.Address,d.Mobile  from distributor d join Mobile_master m on (d.Distributor_ID=m.Distributor_ID) join Mobile_Specification ms on(m.IME_No=ms.IME_No) where Network_3G ='yes' AND OS like 'Android%' AND Camera_Quality='3.5MP';

-- 22
select distinct m.Model_Name,m.Manufacturer from Mobile_master m join Sales_Info s on(m.IME_No=s.IME_No) having count(*)=(select max(cnt) from (select count(Model_Name) cnt from Sales_Info )t1 );