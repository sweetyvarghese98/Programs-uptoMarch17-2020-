/*create table Employee(
employee_id int(3),
first_name varchar(20) not null,
last_name varchar(20),
Date_of_joining date not null,
salary float(7,2),
Department_id int(2),
email varchar(20),
primary key(employee_id),
unique(email)
);*/

 -- drop table Employee;

/*insert into Employee values(100,'sweety','varghese','2015-01-15',10000,10,'svarghese');
insert into Employee values(101,'simi','varghese','2010-01-16',20000,11,'mvarghese');
insert into Employee values(102,'anitta','thomas','2010-01-17',30000,12,'athomas');
insert into Employee values(103,'simi','varghese','2010-01-16',20000,11,'bvarghese');
insert into Employee values(104,'anitta','thomas','2010-01-17',30000,12,'cthomas');
insert into Employee values(105,'simi','varghese','2010-01-16',20000,11,'dvarghese');
insert into Employee values(106,'anitta','thomas','2010-01-17',30000,12,'ethomas');
insert into Employee values(107,'simi','varghese','2010-01-16',20000,11,'fvarghese');
insert into Employee values(108,'anitta','thomas','2010-01-17',30000,12,'gthomas');
insert into Employee values(109,'sachin','thomas','2010-01-17',50000,null,'gthomas');*/


-- select * from Employee;
-- select * from Employee where salary=20000;
-- select * from Employee where last_name='thomas';
-- select * from Employee where salary between 20000  and 40000;
-- select first_name,salary*5 from Employee where last_name='thomas';
-- select first_name,salary*5 from Employee where date_of_joining>'2011-10-28';
-- select first_name,last_name,date_of_joining from Employee order by date_of_joining desc;
-- select first_name,last_name,salary from Employee order by salary desc;
-- select first_name,last_name from Employee order by first_name desc;
-- select first_name,last_name,salary from Employee where salary=10000;
-- select first_name,last_name,salary from Employee where salary!=10000;
-- Select concat(first_name,last_name) from Employee;
-- Select concat(first_name,'-',last_name) from Employee;
-- select concat(last_name,first_name) from Employee;
-- Select concat(first_name,last_name) from Employee where email='cthomas';
--  select concat('my','s','ql') from dual;
-- select upper(first_name) from Employee;
-- select lower(last_name) from Employee;
-- select substr(first_name,3) from Employee;
-- select substr('quadractically',5);
-- select substr('quadractically',5,3);
-- select strcmp(first_name,last_name) from Employee;
-- select strcmp('s','s');
-- select strcmp('T','S');
-- select round(-1.23) from dual;
-- select curdate();
-- select curdate()-1 ;
-- select current_timestamp() from dual;
-- select datediff('2007-12-31 23:59:59','2007-12-30');
-- select extract(year from '2019-07-02');
select extract(month from '2019-07-02');
-- select extract(day from '2019-07-02');
