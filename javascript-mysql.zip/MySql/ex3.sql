-- create database new_empdata_db;
-- use new_empdata_db;
create table Locations(Location_id int(2),
location_name varchar(20),
primary key(location_id)
);

create table departments
(
department_id int(3),
department_name varchar(20),
location_id int(2),
primary key(department_id),
foreign key(location_id) references locations(location_id)
);
 

create table employees(
employee_id int(4),
employee_name varchar(20),
salary numeric(7,5),
dateOfJoin date,
job varchar(20),
department_id int(3),
primary key(employee_id),
foreign key(department_id) references departments(department_id)
);
-- drop table departments;
insert into locations values(10,'India');
insert into locations values(11,'SriLanka');
insert into locations values(12,'UK');

insert into departments values(112,'Finance',12);
insert into departments values(112,'Admin',11);
insert into departments values(113,'Operations',10);
insert into departments values(114,'Insurance',10);


insert into employees values(2234,'KING',60,'2001-04-23','PRES',112);
insert into employees values(2235,'SMITTH',20,'2009-04-23','CLERK',null);
insert into employees values(2236,'BLAKE',50,'2005-04-23','MGR',111);
insert into employees values(2237,'TURNER',60,'2008-05-13','CLERK',113);
insert into employees values(2238,'BLUE',30,'2007-05-13','',111);
insert into employees values(2239,'JACK',40,'2007-05-13','PRES',113);
insert into employees values(2240,'PAUL',70,'2008-05-12','MGR',113);
insert into employees values(2250,'PAUL',70,'2008-05-12','MGR',null);
insert into employees values(2251,'PAUL',70,'2008-05-12','MGR',null);

  commit;
 -- drop table employees
 select * from employees;
 select * from locations;clubemployeeplayer
 select * from departments;

select employee_name,department_name from employees join departments on(employees.department_id=departments.department_id);
select employee_name,department_name,location_name from employees join departments on(employees.department_id=departments.department_id)join locations on(departments.location_id=locations.location_id);
select employee_name,department_name from employees Left outer join departments on(employees.department_id=departments.department_id);
select employee_name,department_name from employees Right outer join departments on(employees.department_id=departments.department_id);