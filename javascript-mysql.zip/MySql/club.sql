-- create Table Club(club_id int(2),
-- sport varchar(20),location varchar(20),primary key(club_id));

--  create Table Player(player_id int(2),first_name varchar(20),last_name varchar(20),
-- club_id int(2),foreign key(club_id)  references club(club_id) on delete cascade );

insert into Club values(10,'Tennis','Kochi');
insert into Club values(20,'chess','coimbatore');
insert into club values(30,'cricket','chennai');
insert into club values(40,'papaerboat','navalur');

/*insert into Player values(60,'kumar','raja',10);
insert into Player values(70,'ram','kumar',20);
insert into Player values(80,'mario','kumar',10);*/
-- insert into Player values(44,'luigi','luigi',50);

--  Select *from Club;
-- drop table Club;
-- Select * from  Player;
-- drop table Player;
--  --- possible
-- drop table Player;
-- drop table Club;
--  --- notpossible 
-- drop  table Club;
-- drop  table Player;
 -- delete from Player where player_id=70;
 -- delete from Club where club_id=10;


