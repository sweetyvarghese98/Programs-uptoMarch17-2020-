create database emp_db;
use emp_db;
create table employees(
employee_id int(4),
employee_name varchar(20),
salary numeric(7,5),
dateOfJoin date,
job varchar(20),
department_id int(3),
primary key(employee_id),
foreign key(department_id) references departments(department_id)
);
drop table employee;
select * from employees;
select count(employee_id) from employees;

