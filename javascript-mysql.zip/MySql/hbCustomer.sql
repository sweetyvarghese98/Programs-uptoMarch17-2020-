CREATE USER 'hbcustomer'@'localhost' IDENTIFIED BY 'hbcustomer';-- user and password,ie user with password is created

GRANT ALL PRIVILEGES ON * . * TO 'hbcustomer'@'localhost';-- given all privileges to hbstudent