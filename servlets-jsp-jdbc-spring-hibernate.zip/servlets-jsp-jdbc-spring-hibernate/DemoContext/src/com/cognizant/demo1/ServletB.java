package com.cognizant.demo1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletB extends HttpServlet {
public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException
{
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	ServletConfig cfg=getServletConfig();//cfg is just obj reference variable//one per servlet
		ServletContext ctx=getServletContext();
		String ctxParam=ctx.getInitParameter("OracleDriver");
	ServletConfig config=getServletConfig();
	ctx.setAttribute("user", "driver");
	String driverName=config.getInitParameter("driver");
	out.println("<html><body bgcolor='beige'>");
	out.println("<h2>Init param: "+cfg.getInitParameter("email")+"</h2>");
		out.println("<h2>Context init parameter"+ctxParam+"</h2>");
	out.println("<h2>Init Parameter for driver "+driverName+"</h2>");//driver will be null here.
	out.println("</html></body>");
}
}
