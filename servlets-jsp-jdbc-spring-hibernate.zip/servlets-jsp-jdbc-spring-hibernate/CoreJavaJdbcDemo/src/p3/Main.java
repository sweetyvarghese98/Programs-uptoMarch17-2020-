package p3;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

import com.cognizant.dao.EmployeeDaoimpli;
import com.cognizant.entity.Employee;

public class Main {

	public static void main(String[] args) {
		Connection con=	DBConnector.getConnection();
		EmployeeDaoimpli dao=new EmployeeDaoimpli();
		java.util.Date d=new java.util.Date();
		//for complete data
		
		List<Employee> a1=dao.ListAllEmployee();
		Iterator<Employee> iter=a1.iterator();
		while(iter.hasNext())
		{
			Employee e=iter.next();
			//System.out.println(e.getemployeeName());
			System.out.println(e);//here we are given obj ref variable.so toString method is invoked
		}
		//for inserting
		
		
		/*Employee e1=new Employee(11,"Aruna",10.0,d,"Mgr",113);
		//Employee e1=new Employee(10,null,0.0,d,null,113);
		boolean res=dao.insertEmployee(e1);
		System.out.println("Employee inserted "+res);*/
		
		//for updating
		
		Employee e2=new Employee(108,"ammu",50.0,d,"ccc",112);
		boolean res2=dao.upDateEmployee(108,e2);
		System.out.println("Whether employee 22 is updated: "+res2);
		
		//for deleting
		/*boolean res3=dao.deleteEmployee(2237);
		System.out.println("Whether employee 2237 is deleted: "+res3);
		*/
		//task
		
		/*List<Employee>a2=dao.findByName("PAUL");
		Iterator<Employee> iter1=a2.iterator();
		while(iter1.hasNext())
		{
			Employee ename=iter1.next();
			//System.out.println(e.getemployeeName());
			System.out.println(ename);//here we are given obj ref variable.so toString method is invoked
		}

		List<Employee>a3=dao.findById(2238);
		Iterator<Employee> iter2=a3.iterator();
		while(iter2.hasNext())
		{
			Employee eid=iter2.next();
			//System.out.println(e.getemployeeName());
			System.out.println(eid);//here we are given obj ref variable.so toString method is invoked
		}*/
		
		
		
	}

}
