package p2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JdbcWithProps {

	public static void main(String[] args) {
		FileInputStream fis=null;
		Properties prop=new Properties();
		Connection connection=null;
		Statement statement=null;
		ResultSet resultset=null;
		
		
		try {
			fis=new FileInputStream("C:\\servlets\\CoreJavaJdbcDemo\\src\\p2\\database.properties");
			prop.load(fis);//to load properties file into javaclass.
			
			String db_driver=prop.getProperty("db.driver");
			String db_url=prop.getProperty("db.url");
			String db_user=prop.getProperty("db.user");
			String db_password=prop.getProperty("db.password");
			/*System.out.println(db_driver);
			System.out.println(db_url);
			System.out.println(db_user);
			System.out.println(db_password);*/
			
			Class.forName(db_driver);
			connection=DriverManager.getConnection(db_url,db_user,db_password);
			if(connection!=null)
			{
				System.out.println("connection available");
			}
			DatabaseMetaData dbmd=connection.getMetaData();//metadata(data abt data ie here data abt our database) abt database from connection obj
			String dbname=dbmd.getDatabaseProductName();
			System.out.println("Database product: "+dbname);
			int max_coloumn_name_len=dbmd.getMaxColumnNameLength();
			System.out.println("Maximum column name length in MySql: "+max_coloumn_name_len);//this info can be retrieved using database metadata.
			
		statement=connection.createStatement();
		//resultset=statement.executeQuery("select * from employees");
		resultset=statement.executeQuery("select employee_name,salary from employees");
		while(resultset.next())
		{
			//System.out.println(resultset.getInt(1));//or System.out.println(resultset.getString("employee_name");
			System.out.println(resultset.getString(1));
			//System.out.print(resultset.getString(2));
			System.out.println(resultset.getDouble(2));
			//System.out.println(resultset.getDouble(3));
			/*System.out.print(resultset.getString(4));
			System.out.print(resultset.getString(5));
			System.out.print(resultset.getInt(6));//there are 6 columns*/
			
		}
		} 
		catch (FileNotFoundException e) 
			{
			e.printStackTrace();
			}
		catch (IOException e)
			{
			e.printStackTrace();
			} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
