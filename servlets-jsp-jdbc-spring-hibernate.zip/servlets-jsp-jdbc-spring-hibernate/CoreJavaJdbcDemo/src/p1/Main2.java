package p1;

public class Main2 {
	static {
		//static initializer block
		System.out.println("static block");
	}
	static {
		System.out.println("static block2");
	}
	{
		int a[]=new int[10];
		//instance initializer block.ie whatever written this{} applicable to all
		//obj
	}
	//constructor
	Main2(){
		System.out.println("constructor executed");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main function is executed");
		Main2 obj=new Main2();
		//only static code execute first in a java prgm.
	}

}
