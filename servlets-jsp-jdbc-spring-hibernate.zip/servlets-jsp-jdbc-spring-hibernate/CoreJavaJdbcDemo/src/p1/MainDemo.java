package p1;
class A{
	public void display() {
		System.out.println("display() invoked");
	}
	static void show() {
		System.out.println("show() invoked");
	}
}
public class MainDemo {

	public static void main(String args[]) throws InstantiationException, IllegalAccessException, ClassNotFoundException
	{
		A.show();
		A obj=(A) Class.forName("p1.A").newInstance();//here creating obj of
										        //display without using new keyword.
		obj.display();
	}
}
