package com.cognizant.dao;



import java.util.List;

import com.cognizant.entity.Employee;

public interface EmployeeDao {
	//contract for CRUD
	boolean insertEmployee(Employee e);
	List<Employee> ListAllEmployee();
	boolean upDateEmployee(int employeeId,Employee e);
	boolean deleteEmployee(int employeeId);
	
	//task
	List<Employee> findByName(String employeeName);
	List<Employee> findById(int employeeId);
}
