package com.cognizant.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.entity.Employee;
import com.mysql.jdbc.PreparedStatement;

import p3.DBConnector;

public class EmployeeDaoimpli implements EmployeeDao {

	@Override
	public List<Employee> ListAllEmployee() {
		ArrayList<Employee>empList=new ArrayList<Employee>();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from employees";
		Connection con=DBConnector.getConnection();
		java.util.Date d=null;
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next())
			{
				int id=rs.getInt("employee_id");
				String name=rs.getString("employee_name");
				Double sal=rs.getDouble("salary");
				Date doj=rs.getDate("dateOfJoin");
				d=new java.util.Date(doj.getTime());//converting sql date to util date(java.util.Date.)
				String job=rs.getString("job");
				int depid=rs.getInt("department_id");
				
				Employee e1=new Employee(id,name,sal,doj,job,depid);
				empList.add(e1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList;
	}

	@Override
	public boolean insertEmployee(Employee e) {
		PreparedStatement ps=null;
		String sql="insert into employees values(?,?,?,?,?,?)";
		//String sql="insert into employees(employee_id,dateOfJoin,department_id) values(?,?,?)";
				Connection con=DBConnector.getConnection();
				java.util.Date d=e.getjoinDate();
				java.sql.Date sqlDate=new java.sql.Date(d.getTime());
				boolean result=false;
				
				
				try {
					ps=(PreparedStatement) con.prepareStatement(sql);
					ps.setInt(1, e.getemployeeId());
					//ps.setInt(1, e.getemployeeId());
					ps.setString(2, e.getemployeeName());
					ps.setDouble(3, e.getsalary());
					ps.setDate(4, sqlDate);
					//ps.setDate(2, sqlDate);
					ps.setString(5, e.getjob());
					ps.setInt(6, e.getdepartmentId());
					//ps.setInt(3, e.getdepartmentId());
					int res=ps.executeUpdate();
					if(res==1)
					
						result=true;
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
		return result;
	}

	@Override
	public boolean upDateEmployee(int employeeId, Employee e)//can have Employee e alone
	{
		Connection con=DBConnector.getConnection();
		java.sql.PreparedStatement ps=null;
		boolean result=false;
		java.util.Date sqlDate=new java.sql.Date(e.getjoinDate().getTime());
		String sql="update employees set employee_name=?,salary=?, dateOfJoin=?, job=?,department_id=? where employee_id=?";
		
		try {
			ps= con.prepareStatement(sql);
			ps.setString(1, e.getemployeeName());
			ps.setDouble(2, e.getsalary());
			ps.setDate(3,  (Date) sqlDate);
			ps.setString(4, e.getjob());
			ps.setInt(5, e.getdepartmentId());
			ps.setInt(6, employeeId);//based on primary key employeeid,we are updating.shouldnot update primary key.
			int res=ps.executeUpdate();
			if(res==1)
				result=true;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public boolean deleteEmployee(int employeeId) {
		Connection con=DBConnector.getConnection();
		java.sql.PreparedStatement ps=null;
		boolean result=false;
		String sql="delete from employees where employee_id=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1,employeeId);
			int res=ps.executeUpdate();
			if(res==1)
				result=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public List<Employee> findByName(String employeeName) {
		
		ArrayList<Employee>empList1=new ArrayList<Employee>();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from employees where employee_name='"+employeeName+"'";
		Connection con=DBConnector.getConnection();
		java.util.Date d=null;
		java.sql.PreparedStatement ps=null;
		
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next())
			{
				int id=rs.getInt("employee_id");
				String name=rs.getString("employee_name");
				Double sal=rs.getDouble("salary");
				Date doj=rs.getDate("dateOfJoin");
				d=new java.util.Date(doj.getTime());//converting sql date to util date(java.util.Date.)
				String job=rs.getString("job");
				int depid=rs.getInt("department_id");
				
				Employee e1=new Employee(id,name,sal,doj,job,depid);
				empList1.add(e1);
	
		
		
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList1;
	}

	@Override
	public List<Employee> findById(int employeeId) {
		ArrayList<Employee>empList2=new ArrayList<Employee>();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from employees where employee_id='"+employeeId+"'";
		Connection con=DBConnector.getConnection();
		java.util.Date d=null;
		java.sql.PreparedStatement ps=null;
		
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next())
			{
				int id=rs.getInt("employee_id");
				String name=rs.getString("employee_name");
				Double sal=rs.getDouble("salary");
				Date doj=rs.getDate("dateOfJoin");
				d=new java.util.Date(doj.getTime());//converting sql date to util date(java.util.Date.)
				String job=rs.getString("job");
				int depid=rs.getInt("department_id");
				
				Employee e2=new Employee(id,name,sal,doj,job,depid);
				empList2.add(e2);
	
		
		
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList2;
	}
}
