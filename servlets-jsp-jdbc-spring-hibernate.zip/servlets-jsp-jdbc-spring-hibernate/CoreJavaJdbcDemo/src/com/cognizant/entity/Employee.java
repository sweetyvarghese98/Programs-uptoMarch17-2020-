package com.cognizant.entity;

import java.util.Date;

//POJO Class
public class Employee {
int employeeId;
String employeeName;
Double salary;
Date joinDate;
String job;
int departmentId;

//constructor

public Employee(int employeeId,String employeeName,Double salary,Date joinDate
		,String job,int departmentId)
{
	this.employeeId=employeeId;
	this.employeeName=employeeName;
	this.salary=salary;
	this.joinDate=joinDate;
	this.job=job;
	this.departmentId=departmentId;
}

public void setemployeeId(int employeeId)
{
	this.employeeId=employeeId;
}
public int getemployeeId()
{
	return this.employeeId;
}
public void setemployeeName(String employeeName)
{
	this.employeeName=employeeName;
}
public String getemployeeName()
{
	return this.employeeName;
}
public void setsalary(Double salary)
{
	this.salary=salary;
}
public Double getsalary()
{
	return this.salary;
}
public void setjoinDate(Date joinDate)
{
	this.joinDate=joinDate;
}
public Date getjoinDate()
{
	return this.joinDate;
}

public void setjob(String job)
{
	this.job=job;
}
public String getjob()
{
	return this.job;
}

public void setdepartmentId(int departmentId)
{
	this.departmentId=departmentId;
}
public int getdepartmentId()
{
	return this.departmentId;
}
public String toString() {
	return "Employee[Id= "+employeeId + "," + employeeName +" , "+salary +" ," 
			+ joinDate+", "+job+" ,"+departmentId +"]";
}


}
