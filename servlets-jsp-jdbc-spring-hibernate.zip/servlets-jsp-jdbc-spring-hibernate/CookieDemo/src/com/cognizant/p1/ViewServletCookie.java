package com.cognizant.p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewServletCookie  extends HttpServlet{
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException {
		//to scan the incoming cookie information
		Cookie ck[]=request.getCookies();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html><body bgcolor=");
		//for getting the color
		for(int i=0;i<ck.length;i++)
		{
			Cookie cookie=ck[i];
			String name=cookie.getName();
			String value=cookie.getValue();
			if(name.equals("color"))
				out.println(value+">");
			//out.println("Cookie["+name+" "+value+"]");
		}
		//for printing the value of cookies
		for(int i=0;i<ck.length;i++)
		{
			Cookie cookie=ck[i];
			String name=cookie.getName();
			String value=cookie.getValue();
			
			out.println("Cookie["+name+" "+value+"]");
		}
		out.println("</body></html>");
	}

}
