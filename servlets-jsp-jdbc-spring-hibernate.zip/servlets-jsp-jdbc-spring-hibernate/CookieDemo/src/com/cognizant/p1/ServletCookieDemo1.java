package com.cognizant.p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletCookieDemo1 extends HttpServlet{
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		String userName=request.getParameter("userName");
		Cookie cookie1=new Cookie("User",userName);
		cookie1.setMaxAge(60*60);
		Cookie cookie2=new Cookie("abc","xyz123");
		cookie2.setMaxAge(60*60);
		Cookie cookie3=new Cookie("color","pink");
		cookie3.setMaxAge(60*60);
		response.addCookie(cookie1);
		response.addCookie(cookie2);
		response.addCookie(cookie3);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		out.println("Hi "+userName);
		out.println("<a href='seeCookie'>view cookies</a>");
		out.println("</html></body>");
		
	   
	}

}
