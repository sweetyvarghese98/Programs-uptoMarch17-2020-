package p2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SuccessServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		
		PrintWriter out=response.getWriter();
		String firstname=request.getParameter("fn");
		String lastname=request.getParameter("ln");
		String email=request.getParameter("email");
		String phonenumber=request.getParameter("phone");
		//String s=(String) request.getAttribute("success");
		out.println("<html><body>");
		out.println("Data entered Successfully"+"<br>");
		out.println("FirstName :"+firstname+"<br>");
		out.println("LastName :"+lastname+"<br>");
		out.println("EmailAddress :"+email+"<br>");
		out.println("PhoneNumber :"+phonenumber+"<br>");
		//out.println(s);
		out.println("</html></body>");
		
	}

}
