package p2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmployeeServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		PrintWriter out=response.getWriter();
		String firstname=request.getParameter("fn");
		String lastname=request.getParameter("ln");
		String email=request.getParameter("email");
		String phonenumber=request.getParameter("phone");
		
		ArrayList<String> a1=new ArrayList<String>();
		
		if(firstname.length()<3)
		{
			a1.add("Enter a valid First name");
			
		}
		if(lastname.length()<3)
		{
			a1.add("Enter a valid Last name");
		
		}
		 if(email.length()<10)
		{
			a1.add("Enter a valid Email address");
			
		}
		if(phonenumber.length()<10)
		{
			a1.add("Enter a Valid Phone number");
			
		}
	
		if(firstname.length()<3||lastname.length()<3||email.length()<10||phonenumber.length()<10)
		{

			request.setAttribute("elist", a1);
			RequestDispatcher rd1=request.getRequestDispatcher("error");
			rd1.forward(request, response);
		}
		
		else
		{
			//request.setAttribute("success", "Successful");
			RequestDispatcher rd=request.getRequestDispatcher("success");
			rd.forward(request, response);
		}
		
	}

}
