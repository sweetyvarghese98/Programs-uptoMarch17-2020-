package com.java2s.output;

import com.java2s.output.Printer;

public class OutputHelper 
{
	Printer outputGenerator;//=new JSVPrinter();//because jsvprinter is given in xml
	  public void print()
	  {
	    outputGenerator.print();
	  }
	 public void setOutputGenerator(Printer outputGenerator)
	 {
		  System.out.println("printer arrived");
		  this.outputGenerator = outputGenerator;
	  }
	 public OutputHelper()
	 {
		 System.out.println(" default constructor called");
	 }
	/*public OutputHelper(Printer outputGenerator) 
	{
		System.out.println("constructor called");
		this.outputGenerator = outputGenerator;
	}*/
	  

}
