package com.java2s.common;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.java2s.output.OutputHelper;

public class Main {
	public static void main(String args[])
	{
	      ApplicationContext context = 
	         new ClassPathXmlApplicationContext("com\\java2s\\common\\Spring-Common.xml");
	      OutputHelper output = (OutputHelper)context.getBean("OutputHelper");
	      output.print();
	    }

}
