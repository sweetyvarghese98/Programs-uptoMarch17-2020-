package com.java2s.output;

public interface Printer {
public void print();
}
