package com.java2s.output.impl;

import com.java2s.output.Printer;

public class CSVPrinter implements Printer 
{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Csv Output Printer");
	}
	
}