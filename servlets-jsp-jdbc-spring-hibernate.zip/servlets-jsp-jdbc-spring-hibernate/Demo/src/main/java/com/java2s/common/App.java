package com.java2s.common;

import com.java2s.output.Printer;
import com.java2s.output.impl.CSVPrinter;

public class App 
{
    public static void main( String[] args )
    {
      Printer output = new CSVPrinter();
      output.print();
    }
}
