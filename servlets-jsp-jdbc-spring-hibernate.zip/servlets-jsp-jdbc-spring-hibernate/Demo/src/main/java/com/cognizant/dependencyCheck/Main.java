package com.cognizant.dependencyCheck;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
public static void main(String args[])
{
	ApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\dependencyCheck\\config.xml");
	Prescription presc=ctx.getBean("presc",Prescription.class);
	System.out.println(presc);
}
}
