package com.cognizant.Ambiguity;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String args[])
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\Ambiguity\\config.xml");
		Addition a=ctx.getBean("add",Addition.class);
		//System.out.println(a);
	}
	}

