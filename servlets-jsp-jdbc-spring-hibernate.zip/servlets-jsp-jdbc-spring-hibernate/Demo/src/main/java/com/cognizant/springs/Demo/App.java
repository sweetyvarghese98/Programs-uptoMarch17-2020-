package com.cognizant.springs.Demo;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
        ClassPathXmlApplicationContext context=
        		new ClassPathXmlApplicationContext("config.xml");
        Employee emp= (Employee) context.getBean("emp");//emp is bean id given in xml file.
        System.out.println(emp.getId());
        System.out.println(emp.getName());
    }
}
