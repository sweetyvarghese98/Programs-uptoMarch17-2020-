package com.cognizant.Autowiring;
//Constructor injection
public class Employee {
int id;
Address address;
public Employee(int id, Address address) {
	System.out.println("Constructor is called");
	this.id = id;
	this.address = address;
}
public Employee()
{
	
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
@Override
public String toString() {
	return "Employee [id=" + id + ", address=" + address + "]";
}


}
