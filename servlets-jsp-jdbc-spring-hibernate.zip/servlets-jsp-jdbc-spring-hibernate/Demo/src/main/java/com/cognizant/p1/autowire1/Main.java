package com.cognizant.p1.autowire1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\p1\\autowire1\\config.xml");
Employee e1=ctx.getBean("emp",Employee.class);//this "emp" should be the bean id of Employee class.
System.out.println(e1);
	}

}
