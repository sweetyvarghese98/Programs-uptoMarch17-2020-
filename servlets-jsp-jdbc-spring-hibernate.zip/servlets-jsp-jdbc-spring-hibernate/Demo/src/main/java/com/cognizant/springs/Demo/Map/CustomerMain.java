package com.cognizant.springs.Demo.Map;

import java.util.Map.Entry;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("com\\cognizant\\springs\\Demo\\Map\\configmap.xml");
		Customer c=context.getBean("customer",Customer.class);
		System.out.println(c.getName());
		for(Entry<Integer,String> e:c.getItems().entrySet())
		{
			System.out.println(e.getKey()+" "+e.getValue());
		}
		System.out.println(c.getClass());
		System.out.println(c.getClass().getName());
		
	}

}
