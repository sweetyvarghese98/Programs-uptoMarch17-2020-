package com.cognizant.springs.Demo.Set;

import java.util.Set;

public class CarDealer {
	private String dealerName;
	private Set<String> models;
	public String getDealerName() {
		return dealerName;
	}
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}
	public Set<String> getModels() {
		return models;
	}
	public void setModels(Set<String> models) {
		this.models = models;
	}
	public String toString()
	{
		return "CarDealer["+ dealerName +" "+models  + "]";
	}
}
