package com.cognizant.standalone.set;

public class GFG {
	//SINGLETON DEMO
private static GFG instance;
private GFG()
{
	//PRIVATE CONSTRUCTOR
}
//method to return instance of class
public static GFG getInstance()
{
	if(instance==null)
	{	//if instance is null,initialise
		instance=new GFG();
	}
	return instance;
}
}
