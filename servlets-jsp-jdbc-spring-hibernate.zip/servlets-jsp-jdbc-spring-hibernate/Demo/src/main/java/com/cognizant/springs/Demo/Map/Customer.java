package com.cognizant.springs.Demo.Map;

import java.util.Map;

public class Customer {
private String name;
private Map<Integer,String> items;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Map<Integer, String> getItems() {
	return items;
}
public void setItems(Map<Integer, String> items) {
	this.items = items;
}

}
