package com.cognizant.stereoDemo.Printer;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {
	public static void main(String args[])
	{
	      ClassPathXmlApplicationContext context = 
	         new ClassPathXmlApplicationContext("com\\cognizant\\stereoDemo\\Printer\\config.xml");
	      OutputHelper output = (OutputHelper)context.getBean("outputHelper");
	      output.print();
	      context.close();
	    }

}
