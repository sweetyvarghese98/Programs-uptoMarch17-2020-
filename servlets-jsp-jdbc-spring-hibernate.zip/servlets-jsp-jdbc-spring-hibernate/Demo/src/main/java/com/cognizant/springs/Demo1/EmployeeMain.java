package com.cognizant.springs.Demo1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.springs.Demo.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ClassPathXmlApplicationContext context=
	        		new ClassPathXmlApplicationContext("config.xml");
	        Employee emp= (Employee) context.getBean("emp");//emp is bean id given in xml file.
	        System.out.println(emp.getId());
	        System.out.println(emp.getName());
	        context.registerShutdownHook();
	}

}
