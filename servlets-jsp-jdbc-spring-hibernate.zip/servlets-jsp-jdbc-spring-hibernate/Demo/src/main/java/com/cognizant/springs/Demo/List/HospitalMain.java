package com.cognizant.springs.Demo.List;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HospitalMain {
public static void main(String args[])
{	//baseclass
	ApplicationContext context=new ClassPathXmlApplicationContext("com\\cognizant\\springs\\Demo\\List\\config.xml");
	Hospital hospital=context.getBean("hospital",Hospital.class);
	System.out.println(hospital.getName());
	hospital.getDepartment().forEach(s->System.out.println(s));
	List<String> dep=hospital.getDepartment();
	System.out.println(dep.getClass());
	System.out.println(dep.getClass().getName());
}
}
