package com.cognizant.springs.Demo.ref;

public class Scores {
int maths;
int physics;
int chemistry;
public int getMaths() {
	return maths;
}
public void setMaths(int maths) {
	this.maths = maths;
}
public int getPhysics() {
	return physics;
}
public void setPhysics(int physics) {
	this.physics = physics;
}
public int getChemistry() {
	return chemistry;
}
public void setChemistry(int chemistry) {
	this.chemistry = chemistry;
}
@Override
public String toString() {
	return "Scores [maths=" + maths + ", physics=" + physics + ", chemistry=" + chemistry + "]";
}



}
