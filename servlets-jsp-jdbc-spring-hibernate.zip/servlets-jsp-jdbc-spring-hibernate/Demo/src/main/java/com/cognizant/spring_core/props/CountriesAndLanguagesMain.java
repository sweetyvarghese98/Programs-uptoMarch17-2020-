package com.cognizant.spring_core.props;

import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CountriesAndLanguagesMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\spring_core\\props\\configproperties.xml");
		CountriesAndLanguages cal=ctx.getBean("cal",CountriesAndLanguages.class);
		System.out.println(cal.getCountriesAndLangs());//array is printed
		
		Properties prop=cal.getCountriesAndLangs();
		prop.forEach((k,v)->System.out.println(k+" "+v));//propertes is a map,so 2 values.we can use entry set also for printing.
	}

}
