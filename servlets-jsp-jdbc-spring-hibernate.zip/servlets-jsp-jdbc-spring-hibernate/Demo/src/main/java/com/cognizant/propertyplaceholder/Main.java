package com.cognizant.propertyplaceholder;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
public static void main(String args[])
{
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\propertyplaceholder\\config.xml");
	MyDAO dao=ctx.getBean("myDao",MyDAO.class);
	System.out.println(dao);
}
}
