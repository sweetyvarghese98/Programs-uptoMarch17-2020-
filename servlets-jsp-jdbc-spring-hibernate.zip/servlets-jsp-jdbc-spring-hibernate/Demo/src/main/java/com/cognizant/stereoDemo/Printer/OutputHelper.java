package com.cognizant.stereoDemo.Printer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("outputHelper")
public class OutputHelper 
{	
	//@Value("CSVPrinter")
	Printer outputGenerator;
	  public void print()
	  {
	    outputGenerator.print();
	  }
	  @Autowired
	 public void setOutputGenerator(Printer outputGenerator)
	 {
		  System.out.println("printer arrived");
		  this.outputGenerator = outputGenerator;
	  }
	 
	  

}
