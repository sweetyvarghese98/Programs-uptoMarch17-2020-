package com.cognizant.spring_core.props;

import java.util.Properties;

public class CountriesAndLanguages {
private Properties countriesAndLangs;

public Properties getCountriesAndLangs() {
	return countriesAndLangs;
}

public void setCountriesAndLangs(Properties countriesAndLangs) {
	System.out.println("Setter called");
	this.countriesAndLangs = countriesAndLangs;
}


}
