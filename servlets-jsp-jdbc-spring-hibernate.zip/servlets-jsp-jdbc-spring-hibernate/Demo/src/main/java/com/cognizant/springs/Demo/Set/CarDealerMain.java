package com.cognizant.springs.Demo.Set;

import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarDealerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("com\\cognizant\\springs\\Demo\\Set\\configset.xml");
		CarDealer cardealer=context.getBean("carDealer",CarDealer.class);
		System.out.println(cardealer.getDealerName());
		cardealer.getModels().forEach(s->System.out.println(s));
		Set<String> model=cardealer.getModels();
		System.out.println(model.getClass());
		System.out.println(model.getClass().getName());
	/*	System.out.println(cardealer);
		System.out.println(cardealer.getClass().getName()); *///using toString method
	}

}
