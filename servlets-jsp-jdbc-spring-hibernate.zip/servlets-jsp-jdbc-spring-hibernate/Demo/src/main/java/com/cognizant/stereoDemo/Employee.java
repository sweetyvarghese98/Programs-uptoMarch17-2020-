package com.cognizant.stereoDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//@Component
@Component("emp")
@Scope("prototype")
public class Employee {
	@Autowired
private Address address;

public Employee()
{
	System.out.println("default constructor");
}
//@Autowired
public Employee(Address address) {
	super();
	System.out.println("parametrised constructor");
	this.address = address;
}
public Address getAddress() {
	return address;
}
//@Autowired//Address class obj is injected to Employee,address is the dependancy
public void setAddress(Address address) {
	System.out.println("Setter");
	this.address = address;
}
@Override
public String toString() {
	return "Employee [address=" + address + "]";
}

}
