package com.cognizant.standalone.set;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\standalone\\set\\config.xml");
EmailSet es=ctx.getBean("emailSet",EmailSet.class);
System.out.println(es);
	}

}
