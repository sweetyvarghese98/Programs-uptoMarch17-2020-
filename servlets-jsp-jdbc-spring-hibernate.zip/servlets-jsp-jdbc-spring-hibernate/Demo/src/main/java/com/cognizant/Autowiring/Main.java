package com.cognizant.Autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\Autowiring\\config.xml");
		Employee e1=ctx.getBean("emp",Employee.class);
		System.out.println(e1);
		ctx.close();
	}

}
