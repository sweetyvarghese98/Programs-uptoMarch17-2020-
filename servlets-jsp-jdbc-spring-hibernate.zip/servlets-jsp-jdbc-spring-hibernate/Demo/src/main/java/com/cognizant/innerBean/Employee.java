package com.cognizant.innerBean;
//Address is innerbean of Employee
public class Employee {
Address address;

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}

@Override
public String toString() {
	return "Employee [address=" + address + "]";
}

}
