package com.cognizant.stereoDemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
public static void main(String args[])
{
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\stereoDemo\\config.xml");
		/*
		 * Employee e1=ctx.getBean("employee",Employee.class);//in getbean method
		 * "employee",should start with small case. System.out.println(e1); Employee
		 * e2=ctx.getBean("employee",Employee.class);//in getbean method
		 * "employee",should start with small case. System.out.println(e2);
		 */
	
	Employee e1=ctx.getBean("emp",Employee.class);//in getbean method "employee",should start with small case.
	System.out.println(e1);
	Employee e2=ctx.getBean("emp",Employee.class);//in getbean method "employee",should start with small case.
	System.out.println(e2);
	System.out.println(e1.hashCode());
	System.out.println(e2.hashCode());
	System.out.println(e1==e2);
	ctx.close();
}
}
