package com.cognizant.springs.Demo.ref;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainRef {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\springs\\Demo\\ref\\confighasrelation.xml");
Student s=ctx.getBean("student",Student.class);
System.out.println(s);
	}

}
