package com.cognizant.standalone;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\standalone\\config2.xml");
ProductList plist=ctx.getBean("pl",ProductList.class);
System.out.println(plist);

	}

}
