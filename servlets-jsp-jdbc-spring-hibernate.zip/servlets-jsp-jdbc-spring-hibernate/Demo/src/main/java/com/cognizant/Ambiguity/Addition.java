package com.cognizant.Ambiguity;

public class Addition {
Addition(int a,int b)
{
	System.out.println("Integer constructor");
}
Addition(double a,double b)
{
	System.out.println("Double Constructor");
}
Addition(String a,String b)
{
	System.out.println("String constructor");
}
}
