package com.cognizant.standalone.map;

import java.util.Map;

public class EmailMap {
private Map<String,String> emails;

public Map<String, String> getEmails() {
	return emails;
}

public void setEmails(Map<String, String> emails) {
	this.emails = emails;
}

@Override
public String toString() {
	return "EmailMap [emails=" + emails + "]";
}

}
