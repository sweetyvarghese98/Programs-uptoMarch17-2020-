package com.cognizant.stereoDemo.Printer;

public class JsonPrinter implements Printer {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Json printer prints");
	}

}
