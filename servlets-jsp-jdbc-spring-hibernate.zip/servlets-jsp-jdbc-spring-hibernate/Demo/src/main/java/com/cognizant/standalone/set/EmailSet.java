package com.cognizant.standalone.set;

import java.util.Set;

public class EmailSet {
private Set<String> emails;

public Set<String> getEmails() {
	return emails;
}

public void setEmails(Set<String> emails) {
	this.emails = emails;
}

@Override
public String toString() {
	return "EmailSet [emails=" + emails + "]";
}

}
