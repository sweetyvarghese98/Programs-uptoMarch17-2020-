package com.cognizant.innerBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
public static void main(String args[])
{
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\innerBean\\config.xml");
	Employee e1=ctx.getBean("emp",Employee.class);
	//Employee e1=ctx.getBean("empx",Employee.class);//gives output
	System.out.println(e1);
	Employee e2=ctx.getBean("emp",Employee.class);
	System.out.println(e2);
	System.out.println(e1==e2);//for singleton scope it is true,and false for prototype scope,because in singleton samecopy is returned for each getbean 
	ctx.close();
}
}
