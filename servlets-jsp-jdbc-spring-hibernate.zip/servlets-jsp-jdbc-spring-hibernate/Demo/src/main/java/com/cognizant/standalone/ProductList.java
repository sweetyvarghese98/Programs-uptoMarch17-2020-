package com.cognizant.standalone;

import java.util.List;
//stand-alone collections of java.util.* package
public class ProductList {
	List <String> productNames;



public List<String> getProductNames() {
	return productNames;
}

public void setProductNames(List<String> productNames) {
	this.productNames = productNames;
}

@Override
public String toString() {
	return "ProductList [productNames=" + productNames + "]";
}

}
