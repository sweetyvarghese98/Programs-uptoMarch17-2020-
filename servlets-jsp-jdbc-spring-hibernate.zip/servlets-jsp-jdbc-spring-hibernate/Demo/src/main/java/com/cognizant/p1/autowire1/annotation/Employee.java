package com.cognizant.p1.autowire1.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {
//	@Autowired//possible to give here
private Address address;//this 'address' should be the bean id of Address class,if diff name is given in bean id for eg address1,it show null.
//other variables
public Employee() {
	System.out.println("Zero argument constructor");
}
//@Autowired//possible
public Employee(Address address) {
	//super();
	System.out.println("Parametrised constructor");
	this.address = address;
}

public Address getAddress() {
	return address;
}
@Autowired//possible
//@Qualifier("address1")
public void setAddress(Address address) {
	System.out.println("setter injection");
	this.address = address;
}

@Override
public String toString() {
	return "Employee [address=" + address + "]";
}

}
