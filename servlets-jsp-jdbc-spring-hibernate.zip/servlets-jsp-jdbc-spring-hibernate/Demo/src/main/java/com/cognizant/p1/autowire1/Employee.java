package com.cognizant.p1.autowire1;

public class Employee {
private Address address;//this 'address' should be the bean id of Address class,if diff name is given in bean id for eg address1,it show null.

public Employee() {
	System.out.println("Zero argument constructor");
}
public Employee(Address address) {
	//super();
	System.out.println("Parametrised constructor");
	this.address = address;
}

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	System.out.println("setter injection");
	this.address = address;
}

@Override
public String toString() {
	return "Employee [address=" + address + "]";
}

}
