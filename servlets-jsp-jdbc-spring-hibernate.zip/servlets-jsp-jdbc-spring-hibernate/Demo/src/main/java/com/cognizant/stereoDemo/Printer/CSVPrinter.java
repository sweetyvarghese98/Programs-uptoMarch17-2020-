package com.cognizant.stereoDemo.Printer;

import org.springframework.stereotype.Component;
@Component
public class CSVPrinter implements Printer{
	
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("csv printer prints");
	}

}
