package com.cognizant.standalone.map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.standalone.set.EmailSet;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com\\cognizant\\standalone\\map\\config.xml");
		EmailMap em=ctx.getBean("emailMap",EmailMap.class);
		System.out.println(em);
	}

}
