package com.cognizant.springs.Demo.ref;

public class Student {
private int id;
private Scores scores;//student has a scores object,ie has a relationship.

private Address address;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public Scores getScores() {
	return scores;
}

public void setScores(Scores scores) {
	this.scores = scores;
}

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}

@Override
public String toString() {
	return "Student [id=" + id + ", scores=" + scores + ", address=" + address + "]";
}



}




