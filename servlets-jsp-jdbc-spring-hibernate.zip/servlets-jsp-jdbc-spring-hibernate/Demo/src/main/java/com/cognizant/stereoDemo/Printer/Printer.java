package com.cognizant.stereoDemo.Printer;

import org.springframework.stereotype.Component;

@Component
public interface Printer {
public void print();
}
