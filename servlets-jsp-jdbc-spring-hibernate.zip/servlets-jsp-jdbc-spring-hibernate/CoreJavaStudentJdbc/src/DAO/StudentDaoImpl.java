package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Entity.Student;
import p.DataBaseConnector;

public class StudentDaoImpl implements StudentDao{

	@Override
	public List<Student> list() {
		// TODO Auto-generated method stub
		ArrayList<Student>a1=new ArrayList<>();
		Connection con=DataBaseConnector.getConnection();
		Statement st=null;
		ResultSet rs=null;
		String sql="select * from student";
		
		try {
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next())
			{
				int rno=rs.getInt("s_No");
				String name=rs.getString("s_Name");
				Date date=rs.getDate("s_dob");
				
				Student s=new Student(rno, name, date);
				a1.add(s);
				
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return a1;
	}

	@Override
	public boolean insertStudent(Student s) {
		// TODO Auto-generated method stub
		Connection con=DataBaseConnector.getConnection();
		PreparedStatement ps=null;
		String sql="insert into student values(?,?,?,)";
		java.util.Date d=s.getDoB();
		java.sql.Date sqldate=new java.sql.Date(d.getTime());
		boolean result=false;
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, s.getRoll_No());
			ps.setString(1, s.getStudentName());
			ps.setDate(3, sqldate);
			int res=ps.executeUpdate();
			if(res==1)
			{
				result=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

}
