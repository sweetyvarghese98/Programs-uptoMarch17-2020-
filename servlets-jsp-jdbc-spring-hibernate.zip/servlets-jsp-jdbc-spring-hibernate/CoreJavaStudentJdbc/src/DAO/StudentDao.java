package DAO;

import java.util.List;

import Entity.Student;

public interface StudentDao {
	List<Student> list();
	boolean insertStudent(Student s);
}
