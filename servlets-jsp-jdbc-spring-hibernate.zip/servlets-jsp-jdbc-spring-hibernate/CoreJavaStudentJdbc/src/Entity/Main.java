package Entity;

import java.sql.Connection;
import java.util.List;

import DAO.StudentDaoImpl;
import p.DataBaseConnector;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Connection con=DataBaseConnector.getConnection();
StudentDaoImpl dao=new StudentDaoImpl();
List<Student>a1=dao.list();
System.out.println(a1);

java.util.Date d=new java.util.Date();
Student s=new Student(104,"Jazeera",d);
boolean res=dao.insertStudent(s);
System.out.println("Inserted: "+res);

	}

}
