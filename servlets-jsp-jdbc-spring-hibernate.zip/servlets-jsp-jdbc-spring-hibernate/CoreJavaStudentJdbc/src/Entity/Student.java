package Entity;

import java.util.Date;

public class Student {
int roll_No;
String studentName;
Date doB;

public Student(int roll_No, String studentName, Date doB) {
	super();
	this.roll_No = roll_No;
	this.studentName = studentName;
	this.doB = doB;
}
public int getRoll_No() {
	return roll_No;
}
public void setRoll_No(int roll_No) {
	this.roll_No = roll_No;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public Date getDoB() {
	return doB;
}
public void setDoB(Date doB) {
	this.doB = doB;
}
@Override
public String toString() {
	return "Student [roll_No=" + roll_No + ", studentName=" + studentName + ", doB=" + doB + "]";
}

}
