package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletD extends HttpServlet{
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		String userName=request.getParameter("username");
		Double price=(Double) request.getAttribute("price");
		String old=request.getParameter("oldreading");
		String newReading=request.getParameter("newreading");
		double totalBill=
				price*(Integer.parseInt(newReading)-Integer.parseInt(old));
		PrintWriter out =response.getWriter();
		out.println("<br>User: "+userName);
		out.println("<br>Old Reading: "+old);
		out.println("<br>New Reading: "+newReading);
		out.println("<br>Bill Amount:  "+totalBill+"<br>");
		
		
	}

}
