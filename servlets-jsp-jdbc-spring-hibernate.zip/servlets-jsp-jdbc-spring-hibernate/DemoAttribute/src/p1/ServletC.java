package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletC extends HttpServlet{
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		
		request.setAttribute("price",25.0);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("<html><body>");
		out.println("Bill details");
		
		//RequestDispatcher rd=request.grtRequestDispatcher("four");
		//rd.include(request,response);
		
		ServletContext ctx=getServletContext();
		RequestDispatcher rd=ctx.getRequestDispatcher("/four");
		rd.include(request, response);//include is used to get response of D to C and C is giving to user.
		
		out.println("Done");
		out.println("</body></html>");
	}

}
