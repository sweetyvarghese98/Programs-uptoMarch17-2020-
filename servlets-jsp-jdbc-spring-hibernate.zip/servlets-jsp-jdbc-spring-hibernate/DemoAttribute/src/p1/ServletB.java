package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletB extends HttpServlet{
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
	String userName=request.getParameter("username");
	// retrieve the attribute using getAttribute(name)
	
	ArrayList<String>fruitlist =(ArrayList<String>) request.getAttribute("fruitlist");
	Date d=new Date();
	PrintWriter out=response.getWriter();
	out.println("<html><body bgcolor='beige'>");
	out.println("Home Page<br>");
	out.println("Hello "+userName+" !<br>");
	out.println("Today's Date is: "+d+"<br>");
	out.println("fruits available for today!<br>");
	for(String fruit:fruitlist)
	{
		out.println("Fruit :"+fruit);
	}
	out.println("</body></html>");
	
	
	
	}
}
