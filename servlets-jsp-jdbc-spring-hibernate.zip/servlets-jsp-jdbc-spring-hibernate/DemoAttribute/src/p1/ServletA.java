package p1;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletA  extends HttpServlet{
	
		protected void doPost(HttpServletRequest request,HttpServletResponse response)
				throws ServletException, IOException{
				
				ArrayList<String>a1=new ArrayList<String>();
				a1.add("apple");
				a1.add("orange");
				a1.add("grape");
				
			request.setAttribute("fruitlist", a1);//fruitlist attaches the arraylist a1 to request obj
			
			//to dispatch the request to another servlet
			
			/*RequestDispatcher rd=request.getRequestDispatcher("two");
			rd.forward(request, response);*/
			
			//another approach to obtain req.dispatcher
			ServletContext ctx=getServletContext();
			RequestDispatcher rd=ctx.getRequestDispatcher("/two");//"two
			rd.forward(request, response);
				
		

		}
}