package p1;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entity.Product;
import Entity.ProductdaoImpl;

/**
 * Servlet implementation class validateServlet
 */
public class validateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public validateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=new Integer(request.getParameter("productid"));
		String name=request.getParameter("productname");
		Double price=new Double(request.getParameter("price"));
		String date1=request.getParameter("date");
		Date d1=null;
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		try {
			d1=sdf.parse(date1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Date d1=null;
		//SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		//try {
		//	d1=sdf.parse(date);
		//} catch (ParseException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		//}
		String option=request.getParameter("dropdown");
		
		Product p1=new Product(id,name,price,d1);
		ProductdaoImpl dao=new ProductdaoImpl();
		if(option.equals("insert"))
		{
		boolean p=dao.insertProduct(p1);
		System.out.println(p);
		}
		Product p2=new Product(id,name,price,d1);
		if(option.equals("update"))
		{
		boolean p=dao.updateProduct(p2);
		System.out.println(p);
		
		}
		
		if(option.equals("delete"))
		{
		boolean p=dao.deleteProduct(id);
		System.out.println(p);
		}
	}

	


	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
