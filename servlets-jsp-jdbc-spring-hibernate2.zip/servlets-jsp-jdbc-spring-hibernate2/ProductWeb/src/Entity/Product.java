package Entity;

import java.util.Date;

public class Product {

	public int productId;
	String productName;
	Double price;
	Date dateOfManufacture;
	
	
	
	
	public Product(int productId,String productName,Double price,
			Date date)
	{
		this.productId=productId;
		this.productName=productName;
		this.price=price;
		this.dateOfManufacture=date;
		
		
		
	}
	
	public Product(String id, String name, String price2) {
		// TODO Auto-generated constructor stub
	}

	public void setproductId(int productId)
	{
		this.productId=productId;
		
	}
	public int getproductId()
	{
		return this.productId;
	}
	
	public void setproductName(String productName)
	{
		this.productName=productName;
		
	}
	public String getproductName()
	{
		return this.productName;
	}
	
	
	public void setprice(Double price)
	{
		this.price=price;
		
	}
	public Double getprice()
	{
		return this.price;
	}
	
	public void setdateOfManufacture(Date dateOfManufacture)
	{
		this.dateOfManufacture=dateOfManufacture;
		
	}
	public Date getdateOfManufacture()
	{
		return this. dateOfManufacture;
	}
	public String toString() {
		return "Product[Id= "+productId + "," +productName +" , "+price +" ," 
				+dateOfManufacture+"]";
	}
	

}

