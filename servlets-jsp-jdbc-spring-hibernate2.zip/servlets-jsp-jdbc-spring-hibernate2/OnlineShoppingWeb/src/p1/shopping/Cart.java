package p1.shopping;

import java.util.ArrayList;

public class Cart {
static ArrayList<String>a=new ArrayList<String>();
public static ArrayList<String> addToArray(String item[])
{	
	for(int i=0;i<item.length;i++)
		a.add(item[i]);
	return a;
	
}

}
