package p1;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;


public class MyServletRequestListener implements ServletRequestListener {

    public MyServletRequestListener() {
        // TODO Auto-generated constructor stub
    }

    public void requestDestroyed(ServletRequestEvent arg0)  { 
         // TODO Auto-generated method stub
    	System.out.println("Request destroyed");
    }

	
    public void requestInitialized(ServletRequestEvent arg0)  { 
         // TODO Auto-generated method stub
    	System.out.println("Request initialized");
    }
	
}
