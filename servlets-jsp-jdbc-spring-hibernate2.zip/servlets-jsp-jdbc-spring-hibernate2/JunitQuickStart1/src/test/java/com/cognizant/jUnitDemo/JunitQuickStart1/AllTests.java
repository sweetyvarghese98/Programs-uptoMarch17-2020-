package com.cognizant.jUnitDemo.JunitQuickStart1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestArrayDemo.class, TestCalculator.class })
public class AllTests {

}
