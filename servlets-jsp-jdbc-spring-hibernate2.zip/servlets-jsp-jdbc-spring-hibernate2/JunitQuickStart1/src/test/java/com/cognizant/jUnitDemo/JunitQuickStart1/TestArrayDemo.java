package com.cognizant.jUnitDemo.JunitQuickStart1;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class TestArrayDemo {

	@Test
	public void testGetFruitList() {
		String[] expectedOutput= {"apple","mango","grape"};
		ArrayDemo d=new ArrayDemo();
		assertArrayEquals(expectedOutput,d.getFruitList());
	}

	@Test
	public void testGetDate() {
		ArrayDemo d=new ArrayDemo();
		Date exp=new java.util.Date();
		assertEquals(exp,d.getDate());
	}

}
