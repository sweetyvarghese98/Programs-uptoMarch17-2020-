package com.cognizant.jUnitDemo.JunitQuickStart1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCalculator {

	@Test
	public void testAdd() {
		Calculator c=new Calculator();
		/*
		 * //(expected result,actualresult),comparing assertEquals(6,c.add(2,
		 * 3));//assertEquals is an inbuilt method in junit.
		 */		
		int res=c.add(6, 6);
		int expected=13;
		assertEquals(expected,res);// no failures
		
	}

}
