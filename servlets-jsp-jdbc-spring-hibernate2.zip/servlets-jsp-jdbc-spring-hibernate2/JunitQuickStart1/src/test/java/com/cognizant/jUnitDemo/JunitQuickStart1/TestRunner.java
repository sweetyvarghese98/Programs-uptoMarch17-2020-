package com.cognizant.jUnitDemo.JunitQuickStart1;

import java.util.List;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {

	public static void main(String[] args) {
		
		Result result=JUnitCore.runClasses(AllTests.class);
		List<Failure> failures=result.getFailures();
		for(Failure f:failures)
		{
			System.out.println(f.getTrace());
			System.out.println(f.getMessage());
			System.out.println(f.getDescription());
			System.out.println(f.getTestHeader());
		}
	}

}
