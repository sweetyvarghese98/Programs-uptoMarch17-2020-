package com.cognizant.jUnitDemo.JunitQuickStart1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestString {
//ORDER OF INVOCATION OF METHODS s in dictinary order of names
	//one test method should be independent of other test method
	@Test
	public void testC() {
		System.out.println(1);
	}
	@Test
	public void testA() {
		System.out.println(2);
	}
	@Test
	public void testB()
	{
		System.out.println(3);
	}
	//output =>2,3,1
	//if testA,testB,testC=>1,2,3
	//if testB,testA,testC=>2,1,3
	@Test
	//aasertEquals method is overloaded in all
	public void testStringUpperCase() {
		String s1="abcdef";
		String s2=s1.toUpperCase();
		assertEquals("ABCDEF",s2);
		
	}

}
