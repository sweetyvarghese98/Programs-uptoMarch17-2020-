package com.cognizant.jUnitDemo.JunitQuickStart1;

public class Discount {
public int calculateDiscountedPrice(int amount,int rateOfDiscount)
{
	return (amount-amount*rateOfDiscount/100);
}
}
