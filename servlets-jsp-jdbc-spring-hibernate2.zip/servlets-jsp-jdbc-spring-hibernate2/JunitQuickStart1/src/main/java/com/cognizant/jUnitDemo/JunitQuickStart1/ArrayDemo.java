package com.cognizant.jUnitDemo.JunitQuickStart1;

import java.util.Date;

public class ArrayDemo {

	public String[] getFruitList() {
		String[] fruits=new String[] {"apple","mango","grape"};
		return fruits;
	}
	public Date getDate() {
		return new java.util.Date();
	}
}
