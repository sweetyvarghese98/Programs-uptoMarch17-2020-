package com.cognizant.jUnitDemo.JunitQuickStart1;

public class Calculator {
public int add(int a,int b)
{
	return a+b;
}
public int check(int a)
{
	if(a>10)
		return 1;
	else
		return -1;
	
}

public int findMinimumOfTwoNumbers(int a,int b)
{
	return Math.min(a, b);
	
}

}
