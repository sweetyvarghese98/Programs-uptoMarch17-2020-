package com.cognizant.sports;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//requesting spring to create objects.
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Coach coach=context.getBean("myCricketCoach",Coach.class);//myCricketCoach is id given in xml page.
		System.out.println(coach.getDailyWorkOut());
		
		coach=context.getBean("myBaseBallCoach",Coach.class);
		System.out.println(coach.getDailyWorkOut());
		
		coach=context.getBean("myTennisCoach",Coach.class);
		System.out.println(coach.getDailyWorkOut());

	}

}
