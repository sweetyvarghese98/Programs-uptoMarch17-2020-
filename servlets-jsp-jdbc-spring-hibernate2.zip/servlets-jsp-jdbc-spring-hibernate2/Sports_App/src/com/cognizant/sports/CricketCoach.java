package com.cognizant.sports;

public class CricketCoach implements Coach {

	@Override
	public String getDailyWorkOut() {
		return "practice for 2 hours";
	}

}
