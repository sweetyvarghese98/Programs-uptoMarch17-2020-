function sayhello()
{
alert("hello world");
}
document.getElementById("myBtn").onclick=sayhello;
