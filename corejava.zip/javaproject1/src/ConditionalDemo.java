
public class ConditionalDemo {
	public static void main(String args[])
	{
		int a=2,b=3,c=6,d=5;
		//int e=(a<5)?++b:++c;
		/*System.out.println("b is"+b);
		System.out.println("c is"+c);
		System.out.println("e is"+e);*/
		if((a==2)|(++b==c))
		{
			System.out.println("a");
		}
		System.out.println(b);
		System.out.println(c);
		/*int f=(a<5)?b++:c++;
		System.out.println("b is"+b);
		System.out.println("c is"+c);
		System.out.println("f is"+f);*/
	}

}
