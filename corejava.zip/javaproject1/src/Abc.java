
/*public class Abcd {
final void display(){
	System.out.println();

}
}
class Xyz extends Abc{
	
	
	void display(){//reducing so error
		
		System.out.println();
	}
}*/