class A{
	int a;
	A(int a)
	{
		this.a=a;
		System.out.println(1);
	}
}//A class is closed here
class B extends A
{
	int b;
	B(int a,int b)
	{
		super(a);
		this.b=b;
		System.out.println(2);
	}
}
public class DemoInheritance2 {
	public static void main(String args[])
	{
		B bRef=new B(10,20);
		System.out.println(bRef.a);
		System.out.println(bRef.b);
	}

}
