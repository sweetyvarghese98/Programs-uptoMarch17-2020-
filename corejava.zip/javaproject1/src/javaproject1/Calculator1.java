package javaproject1;
import java.util.*;
public class Calculator1 {
	int calculateSum(int number1,int number2){
		int Sum=number1+number2;
		return Sum;
		
	}
	int calculateDifference(int number1,int number2){
		int Difference=number1-number2;
		return Difference;
	}
	public static void main(String args[])
	{
		Scanner s1=new Scanner(System.in);
		System.out.println("Enter First number:");
		int number1=s1.nextInt();
		System.out.println("Enter Second number:");
		int number2=s1.nextInt();
		Calculator1 m=new Calculator1();
		int Add=m.calculateSum( number1, number2);
		int Sub=m.calculateDifference(number1, number2);
		System.out.println("The sum is:"+Add);
		System.out.println("The difference is:"+Sub);
		
		
	}
}
