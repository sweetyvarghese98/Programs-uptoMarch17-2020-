package javaproject1;
import java.util.*;
public class GreateFinder {
	int findGreater2(int number1,int number2)
	{
		int max=(number1>number2)?number1:number2;
		return max;
	}
	int findGreater3(int number1,int number2,int number3)
	{
		if((number1>number2)&&(number1>number3))
		{return number1;
		}
		else if((number2>number1)&&(number2>number3)){
			return number2;
		}
		else{
			return number3;
		}

				
	}
	
		public static void main(String args[])
		{
			Scanner s=new Scanner(System.in);
			System.out.println("Enter the 2 numbers");
			int num1=s.nextInt();
			int num2=s.nextInt();
			GreateFinder m=new GreateFinder();
			int greater2=m.findGreater2( num1, num2);
			System.out.println("Enter the 3 numbers");
			int n1=s.nextInt();
			int n2=s.nextInt();
			int n3=s.nextInt();
			int greater3=m.findGreater3( n1, n2, n3);
			System.out.println("Biggest of two numbers :"+greater2);
			System.out.println("Biggest of three numbers :"+greater3);
		}
	}


