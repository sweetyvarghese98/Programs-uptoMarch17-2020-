package javaproject1;
import java.util.*;
public class MessagePrinter1 {
	public static void main(String args[]){
		String s;
	Scanner s1=new Scanner(System.in);
	System.out.println("Enter the String Value:");
	s=s1.nextLine();
	MessagePrinter1 m=new MessagePrinter1();
	m.printMessage(s);
	
	

}
void printMessage(String name)
{
	System.out.println("Hello "+name);
}
}
