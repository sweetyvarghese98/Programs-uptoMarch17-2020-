package javaproject1;
import java.util.*;
public class Factorial {
	int calculateFactorial(int num)
	{int i,f=1;
	for(i=1;i<=num;i++)
	{
		f=f*i;
	}
	return f;
		
	}
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Number");
	int n=s.nextInt();
	Factorial m=new Factorial();
	int result=m.calculateFactorial(n);
	System.out.println("The Factorial is: "+result);
	
	
	
}
}
