package javaproject1;

public class Calculator {
	int calculateSum(int number1,int number2){
		int Sum=number1+number2;
		return Sum;
	}
	int calculateDifference(int number1,int number2){
		int Difference=number1-number2;
		return Difference;
	}
	public static void main(String args[])
	{
		Calculator c=new Calculator();
		int res=c.calculateSum(5,6);
		System.out.println(res);
		int diff=c.calculateDifference(6,5);
		System.out.println(diff);
	
		
	}

}
