class Abc{
	final int a=5;
	void display(){
	
	}
}
public class InheritanceDem {
	public static void main(String args[])
	{
		Abc ob=new Abc();
		ob.a=45;//not possible because a is final
	}

}
