class Vehicle{
	
	Vehicle(){
		System.out.println("Constructor in base");
	}
}
class Car extends Vehicle{
Car(){
	System.out.println("Constructor in subclass");
}
}
//DemoInheritance Example
public class DemoInheritance {
public static void main(String args[]){
	Car c=new Car();

}
}
