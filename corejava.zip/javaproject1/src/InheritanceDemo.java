class SuperClass{
	/*public void display()
	{
		System.out.println("SUPERCLASS METHOD");
	}*/
}
class SubClass extends SuperClass{
	public void display()
	{
		System.out.println("SUBCLASS METHOD");}}
public class InheritanceDemo {
	public static void main(String args[]){
		SuperClass s1=new SuperClass();
		SubClass sub=new SubClass();
		s1.display();//compiler assumes superclass method is called and that what happens
		sub.display();
		//upcast
		s1=sub;
		s1.display();//compiler assumes superclass method is invoked and that doesnot
		//doesnot happen.understand that it was baseclass method only during runtime.
		}}
