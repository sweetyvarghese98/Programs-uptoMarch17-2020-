
public class DemoArrays {
public static void main(String args[])
{
	int myArray2[]={1,2,3,4};
	for(int i=0;i<myArray2.length;i++)
	{
		System.out.println(myArray2[i]);
	}
	
	String[] str=new String[5];//ss is the variable of String
	for(String ss:str){
		System.out.println(ss);
	}
	int[] myArray=new int[5];
	for(int i=0;i<myArray.length;i++)
	{
		System.out.println(myArray[i]);
	}
	double myDoubleArray[]=new double[5];
	for(double d:myDoubleArray)
	{
		System.out.println(d);
	}
}
}
