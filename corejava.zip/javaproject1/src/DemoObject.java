
class Student1 {
	int studentId;
	String studentName;
	Student1(int studentId,String studentName)
	{
		this.studentId=studentId;
		this.studentName=studentName;
	}
	public String toString()//greenarrow on side indicate overriding
	{
		return "["+studentId+" "+studentName+"]";
	}
}
public class DemoObject {
public static void main(String args[])
{
	Student1 s1=new Student1(100,"sweety");
	Student1 s2=new Student1(100,"simi");
	System.out.println(s1);
	System.out.println(s2);
}
}
