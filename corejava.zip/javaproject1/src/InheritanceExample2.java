class Circle1{
	int radius;
	//constructor
	Circle1(int radius)
	{
		this.radius=radius;}
	void displayArea(){
		double area=3.14*radius*radius;
		System.out.println("Area of circle "+area);
	}
}
class Cylinder1 extends Circle1
{
	int height;
	Cylinder1(int radius,int height)
	{
		super(radius);
		this.height=height;
		
		}
	void displayArea(){
		double area=3.14*radius*radius*height;
		System.out.println("Area of cylinder "+area);
		System.out.println("Going to print area of circle");
		super.displayArea();
}
}
public class InheritanceExample2 {
	public static void main(String args[])
	{

		Cylinder1 cy=new Cylinder1(2,4);
		cy.displayArea();
	}

}
