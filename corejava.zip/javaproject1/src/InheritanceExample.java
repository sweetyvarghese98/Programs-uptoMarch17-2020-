class Circle{
	int radius;
	//constructor
	Circle(int radius)
	{
		this.radius=radius;}
	void displayArea(){
		double area=3.14*radius*radius;
		System.out.println("Area of circle "+area);
	}
	
}
class Cylinder extends Circle
{
	int height;
	Cylinder(int radius,int height)
	{
		super(radius);
		this.height=height;
		
		}
	//overriding(when called using baseclass obj only baseclass method will b called)
	void displayArea(){
		double area=3.14*radius*radius*height;
		System.out.println("Area of cylinder "+area);
}
}
public class InheritanceExample {
	public static void main(String args[])
	{

	Cylinder cy=new Cylinder(2,4);
	cy.displayArea();
	Circle ci=new Circle(3);
	ci.displayArea();//use separate object for circle method to be printed

}
}
