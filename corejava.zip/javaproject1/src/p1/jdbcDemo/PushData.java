package p1.jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;

public class PushData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//to insert data we need prepared statement
		Date d=new Date();
		long ms=d.getTime();
		java.sql.Date date1=new java.sql.Date(ms);
		Connection con=null;
		java.sql.PreparedStatement ps=null;
		String sql="insert into employees values(?,?,?,?,?,?)";//later on values get inserted into it
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			
			//obtain connection
			con =DriverManager.getConnection("jdbc:mysql://localhost:3306/new_empdata_db","root","root");
		ps=con.prepareStatement(sql);
		ps.setInt(1, 2349);
		ps.setString(2, "Aquaman");
		ps.setDouble(3, 60);
		ps.setDate(4, date1);
		ps.setString(5, "CLERK");
		ps.setInt(6, 113);
		//
		int res=ps.executeUpdate();
		if(res==1)
			System.out.println("Inserted one record");
		
		}catch(Exception e){
			e.printStackTrace();}
		finally{
			try{
				ps.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		
			}
			
		
	}


