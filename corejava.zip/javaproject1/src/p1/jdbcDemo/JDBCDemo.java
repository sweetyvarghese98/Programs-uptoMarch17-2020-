package p1.jdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

public class JDBCDemo {

	public static void main(String[] args) {
		Connection con=null;
		java.sql.Statement statement=null;
		String sql="select * from employees";
		ResultSet rs=null;
	
		//load the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		
		//obtain connection
		con =DriverManager.getConnection("jdbc:mysql://localhost:3306/new_empdata_db","root","root");
		//create statement object(sql statements)
		statement=con.createStatement();
		rs=statement.executeQuery(sql);
		while(rs.next()){
			int empId=rs.getInt("employee_id");
			String empName=rs.getString("employee_name");
			Double sal=rs.getDouble("salary");
			java.sql.Date date=rs.getDate("dateOfJoin");
			String job=rs.getString("job");
			int department_id=rs.getInt("department_id");
			System.out.println(empId+" "+empName+" "+sal+" "+date+" "+" "+job+" "+department_id);
		}
		if(con!=null)
			System.out.println("connection successful");
		else
			System.out.println("no connection");
		}
		catch (ClassNotFoundException | SQLException cnf) {
			// TODO Auto-generated catch block
			cnf.printStackTrace();
		}
		finally{
			try{
				
			
			con.close();
			statement.close();
			rs.close();
			
			}
			catch(SQLException e)
			{
				
			}
		
	}
	
	}
}


