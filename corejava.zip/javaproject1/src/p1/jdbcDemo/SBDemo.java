package p1.jdbcDemo;

public class SBDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//StringBuffer sb=new StringBuffer();
		StringBuilder sb=new StringBuilder();
sb.append("abcdefghijkl");
System.out.println("original >>"+sb);
//sb.reverse();
//sb.delete(1, 5);
//sb.deleteCharAt(5);
String s1=sb.toString();
System.out.println(s1);
	}

}
