package p1.jdbcDemo;
//string builder
public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//not thread safe//legacy
StringBuffer sb=new StringBuffer();//16
System.out.println("string buffer capacity"+sb.capacity());//16
sb.append("abc");
sb.append("xyz");
sb.append("querty");

sb.append("sdgshd");
System.out.println("string buffer capacity"+sb.capacity());//34
System.out.println(sb);
String s1=sb.toString();

System.out.println(s1);

//string builder thread safe mordern
StringBuilder sbuilder=new StringBuilder();
System.out.println("string builder capacity"+sbuilder.capacity());
sbuilder.append("abc");
sbuilder.append("xyz");
String s2=sbuilder.toString();
System.out.println(s2);

	}

}
