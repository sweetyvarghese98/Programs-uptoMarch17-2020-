class Employee{
	int empId;
	String empName;
	Employee(int empId,String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
}
class PartTimeEmployee extends Employee
{
int noOfHours;
PartTimeEmployee(int empId,String empName,int noOfHours)
{	
	super(empId,empName);
	this.noOfHours=noOfHours;
	
	}
void calculateSalary()
{
	int salary=noOfHours*100;
	System.out.println("Salary of parttime employee  of "+empId+" "+empName+" : "+salary);
}
}
class FullTimeEmployee extends Employee
{	int noOfDays;

	FullTimeEmployee(int empId,String empName,int noOfDays)
	{
		super(empId,empName);
		this.noOfDays=noOfDays;
	
	}
	void calculateSalary()
	{
		int salary=noOfDays*1000;
		System.out.println("Salary of fulltime employee of "+empId+" "+empName+" : "+salary);
	
	}
}
public class EmployeeDemo {
	public static void main(String args[])
	{
		FullTimeEmployee fe=new FullTimeEmployee(100,"sweety",30);
		fe.calculateSalary();
		PartTimeEmployee pe=new PartTimeEmployee(101,"simi",60);
		pe.calculateSalary();
		
		
		
	}

}
