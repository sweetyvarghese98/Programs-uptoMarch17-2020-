class A1
{
	void display()
	{
		System.out.println("Base class");
	}
}
class B1 extends A1
{
	void display()
	{
		System.out.println("Sub class");
	}
}
public class DemoCasting {
	public static void main(String args[])
	{
	A1 s1=new A1();
	s1.display();
	B1 s2=new B1();
	s2.display();
	//upcast
	s1=s2;
	s2.display();
	//downcast
	s2=(B1)s1;
	s1.display();
	A1 s3=new A1();
	s3.display();
	

}
}