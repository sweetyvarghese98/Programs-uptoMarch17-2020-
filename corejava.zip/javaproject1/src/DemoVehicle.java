class Vehicle1{
	int numberOfSeats;
Vehicle1(int numberOfSeats){
	this.numberOfSeats=numberOfSeats;
	System.out.println("Constructor in baseclass");
}
}
class Car1 extends Vehicle1{
	String manufacturer;
	String color;
Car1(int numberOfSeats,String manufacturer,String color){
	super(numberOfSeats);
	this.manufacturer=manufacturer;
	this.color=color;
	System.out.println("Constructor in subclass");
}
}
public class DemoVehicle {
	public static void main(String args[]){
	Car1 c=new Car1(4,"ABC","Red");
	System.out.println(c.numberOfSeats);
	System.out.println(c.manufacturer);
	System.out.println(c.color);
	

}
}