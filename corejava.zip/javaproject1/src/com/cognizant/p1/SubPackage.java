package com.cognizant.p1;

public class SubPackage extends MyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
MyClass m=new MyClass();
System.out.println(m.a);
m.display();
	}

}
