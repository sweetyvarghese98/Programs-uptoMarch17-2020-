package com.cognizant.p1;

public class MyClass {
	int a=5;
	void display()
	{
	System.out.println("Display method in MyClass");
	}

}
