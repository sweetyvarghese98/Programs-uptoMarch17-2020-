package com.cognizant.comparatorHandsown;
import java.util.Comparator;
public class DateOfJoiningComparator implements Comparator<Customer>{

	@Override
	public int compare(Customer c1, Customer c2) {
		// TODO Auto-generated method stub
		return c1.dateOfJoin.compareTo(c2.dateOfJoin);
	}
	

}
