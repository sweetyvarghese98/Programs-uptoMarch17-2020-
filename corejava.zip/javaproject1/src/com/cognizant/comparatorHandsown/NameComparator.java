package com.cognizant.comparatorHandsown;
import java.util.Comparator;
public class NameComparator implements Comparator<Customer>{
	


@Override
public int compare(Customer c1, Customer c2) {
	// TODO Auto-generated method stub
	return c1.name.compareTo(c2.name);
}
}	



