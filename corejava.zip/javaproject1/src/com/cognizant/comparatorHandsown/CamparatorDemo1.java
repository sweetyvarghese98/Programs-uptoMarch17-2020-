package com.cognizant.comparatorHandsown;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;



class Customer{
	int id;
	String name;
	Date dateOfJoin;

	Customer(int id,String name,Date dateOfJoin)
	{
		this.id=id;
		this.name=name;
		this.dateOfJoin=dateOfJoin;
	}
	public String toString(){
		return "Id "+id+" name"+name+ " dateofjoin "+dateOfJoin;
	}
}
public class CamparatorDemo1 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Customer> clist=new ArrayList<Customer>();
GregorianCalendar gc=new GregorianCalendar(2020,03,6);
Date d1=gc.getTime();
Customer c1=new Customer(100," Anjaly",d1);
gc=new GregorianCalendar(2020,03,12);
Date d2=gc.getTime();
Customer c2=new Customer(101," Sweety",d2);
gc=new GregorianCalendar(2020,03,20);
Date d3=gc.getTime();
Customer c3=new Customer(102," Sweety",d3);
gc=new GregorianCalendar(2020,03,26);
Date d4=gc.getTime();
Customer c4=new Customer(103," Ammu",d4);

clist.add(c1);
clist.add(c2);
clist.add(c3);
clist.add(c4);
System.out.println("Sorting");
NameComparator nac=new NameComparator();
Collections.sort(clist,new IDComparator().thenComparing(new NameComparator()).thenComparing(new DateOfJoiningComparator()));
for(Customer c:clist)
{
	System.out.println(c);
}
	}

}

