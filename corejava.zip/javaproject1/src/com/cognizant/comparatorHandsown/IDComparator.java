package com.cognizant.comparatorHandsown;
import java.util.Comparator;
public class IDComparator implements Comparator<Customer>{

	@Override
	public int compare(Customer c1, Customer c2) {
		// TODO Auto-generated method stub
		return c1.id-c2.id;
	}
	

}
