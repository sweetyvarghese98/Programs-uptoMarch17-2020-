package com.cognizant.Encapsulation;

public class Account {
int accId;
String type;
double initialBalance;
Account(int accId,String type,double initialBalance)
{
	this.accId=accId;
	this.type=type;
	this.initialBalance=initialBalance;
}
public void setAccid(int accId)
{
	this.accId=accId;
}
public int getAccid()
{
	return this.accId;
}
public void setType(String type)
{
	this.type=type;
}
public String getType()
{
	return this.type;
}
}
