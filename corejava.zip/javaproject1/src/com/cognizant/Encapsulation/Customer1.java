package com.cognizant.Encapsulation;
//entity classes
public class Customer1 {
private int customerId;
private String customerName;
private Address address;
public Customer1(int customerId,String customerName,Address address)
{
	this.customerId=customerId;
	this.customerName=customerName;
	this.address=address;
	
}
public void setCustomerId(int customerId)
{
	this.customerId=customerId;
}
public int getCustomerId()
{
	return this.customerId;
}
public void setCustomerName(String customerName)
{
	this.customerName=customerName;
}
public String getCustomerName()
{
	return this.customerName;
}
public void setAddress(Address address)
{
	this.address=address;
}
public Address getAddress()
{
	return this.address;
}



}
