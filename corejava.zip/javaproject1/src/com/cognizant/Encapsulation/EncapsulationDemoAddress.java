package com.cognizant.Encapsulation;

public class EncapsulationDemoAddress {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address customeraddress=new Address(1,"sirseri","chennai",679322);
		Customer1 c=new Customer1(101,"sweety",customeraddress);
		System.out.println("Customer details are:");
		System.out.println(c.getCustomerId());
		System.out.println(c.getCustomerName());
		Address address=c.getAddress();
		System.out.println("Address details of customer:");
		System.out.println("Door no: "+address.getDoorNo());
		System.out.println("Street: "+address.getStreet());
		System.out.println("Area: "+address.getArea());
		System.out.println("Pincode: "+address.getPincode());
		
		
	}

}
