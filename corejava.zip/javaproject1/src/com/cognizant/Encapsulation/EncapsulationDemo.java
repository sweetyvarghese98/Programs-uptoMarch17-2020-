package com.cognizant.Encapsulation;


public class EncapsulationDemo {
	public static void main(String args[])
	{
	
	Account ac=new Account(8084,"savings",1000.0);
	Employee e1=new Employee(100,"SWEETY",30000.9,true,ac);
	//e1.id=>direct access ,it is not possible,use getter and setter,getter methods to access
	
	e1.setId(101);
	System.out.println(e1.getId());
	e1.setIsCitizenOfIndia(false);
	System.out.println(e1.getIsCitizenOfIndia());
	e1.setName("SIMI");
	System.out.println(e1.getName());
	e1.setSalary(22000);
	System.out.println(e1.getSalary());
	Account account =e1.getAccount();
	account.setAccid(8086);
	System.out.println(account.getAccid());
	account.setType("salary");
	System.out.println(account.getType());
	
	
	
	
	
	
	
}
}