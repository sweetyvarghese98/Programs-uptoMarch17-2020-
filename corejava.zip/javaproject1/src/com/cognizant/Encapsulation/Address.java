package com.cognizant.Encapsulation;

public class Address {
	private int doorNo;
	private String street;
	private String area;
	private int pincode;
	Address(int doorNo,String street,String area,int pincode)
	{
		this.doorNo=doorNo;
		this.street=street;
		this.area=area;
		this.pincode=pincode;
	}
	public void setDoorNo(int doorNo)
	{
		this.doorNo=doorNo;
	}
	public int getDoorNo()
	{
		return this.doorNo;
	}
	public void setStreet(String street)
	{
		this.street=street;
	}
	public String getStreet()
	{
		return this.street;
	}
	public void setArea(String area)
	{
		this.area=area;
	}
	public String getArea()
	{
		return this.area;
	}
	public void setPincode(int pincode)
	{
		this.pincode=pincode;
	}
	public int getPincode()
	{
		return this.pincode;
	}

}
