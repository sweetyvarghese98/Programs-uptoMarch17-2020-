package com.cognizant.Encapsulation;

public class Employee {
	private int id;//can use wrapper also ie Integer id
	private String name;
	private double salary;
	private boolean isCitizenOfIndia;
	private Account account;//employee has account
	
	Employee(int id,String name,double salary,boolean isCitizenOfIndia,Account account)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
		this.isCitizenOfIndia=isCitizenOfIndia;
		this.account=account;
	}
	//setter method//mutator
	public void setId(int id)
	{
		this.id=id;
	}
	//getter method//accessor
	public int getId()
	{
		return this.id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return this.name;
	}
	public void setSalary(double salary)
	{
		this.salary=salary;
	}
	public double getSalary()
	{
		return this.salary;
	}
	public void setIsCitizenOfIndia(boolean isCitizenOfIndia)
	{
		this.isCitizenOfIndia=isCitizenOfIndia;
	}
	public boolean getIsCitizenOfIndia()
	{
		return this.isCitizenOfIndia;
	}
	public Account getAccount(){
		return this.account;
	}
	public void setAccount(Account account)
	{
		this.account=account;
	}

}
