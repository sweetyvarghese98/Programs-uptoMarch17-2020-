package com.cognizant.polymorphism;

abstract class Person
{
	abstract String getName(String name);

public void hello()
{
	System.out.println("HELLO");
}
}


abstract class Person1 extends Person{
public void print1()//should create a subclass of person1 to invoke this
	{
		System.out.println("Unimplemented subclass");
	}
}



class Person2 extends Person{
	String getName(String name)
	{
		return name;
	}
	public void print()
	{
		System.out.println("Implemented subclass");
	}
}

public class AbsDemo1 {
	public static void main(String args[])
	{
		Person2 p2=new Person2();
		String Pname=p2.getName("sweety");
		System.out.println("Name:" +Pname);
		p2.print();
		p2.hello();
		
	  
		
		
		
	}

}
