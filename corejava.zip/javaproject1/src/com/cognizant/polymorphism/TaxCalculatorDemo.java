package com.cognizant.polymorphism;
abstract class TaxCalculator{
	abstract void calculateSalesTax(double productPrice);
}

class TaxIndia extends TaxCalculator{
	void  calculateSalesTax(double productPrice)
	{double tax;
		if(productPrice>500)
		{
			tax=Math.round(productPrice*(0.07));//for rounding the o/p
		}
		else
		{
			tax=Math.round(productPrice*(0.03));
		}
		System.out.println("TaxIndia for price "+productPrice+" : "+tax);
}
}

class TaxChina extends TaxCalculator{
	void calculateSalesTax(double productPrice)
	{ double tax;
		double price=productPrice/2;
		tax=price*(0.05);
		System.out.println("TaxChina for price "+productPrice+" :"+tax);
	}
}


public class TaxCalculatorDemo {
	public static void main(String args[])
	{
	TaxIndia i=new TaxIndia();
	i.calculateSalesTax(5000);
	TaxChina c=new TaxChina();
	c.calculateSalesTax(900);

}
}
