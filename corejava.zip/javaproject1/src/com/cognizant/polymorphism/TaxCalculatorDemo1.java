package com.cognizant.polymorphism;
import java.util.Scanner;
abstract class TaxCalculator1{
	abstract void calculateSalesTax(double productPrice);
}
class TaxIndia1 extends TaxCalculator1{
	void  calculateSalesTax(double productPrice)
	{double tax;
		if(productPrice>500)
		{
			tax=Math.round(productPrice*(0.07));//for rounding the o/p
		}
		else
		{
			tax=Math.round(productPrice*(0.03));
		}
		System.out.println("TaxIndia for price "+productPrice+" : "+tax);
}
}
class TaxChina1 extends TaxCalculator1{
	void calculateSalesTax(double productPrice1)
	{ double tax;
		double price=productPrice1/2;
		tax=price*(0.05);
		System.out.println("TaxChina for price "+productPrice1+" :"+tax);
	}
}

public class TaxCalculatorDemo1 {
public static void main(String args[])
{	
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Product price for India");
	double ProductPrice=s.nextDouble();
	System.out.println("Enter the product price for china");
	double ProductPrice1=s.nextDouble();
	TaxIndia i=new TaxIndia();
	i.calculateSalesTax(ProductPrice);
	TaxChina c=new TaxChina();
	c.calculateSalesTax(ProductPrice1);
	
}
}
