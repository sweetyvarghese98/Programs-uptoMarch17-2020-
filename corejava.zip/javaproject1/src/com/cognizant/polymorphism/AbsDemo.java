package com.cognizant.polymorphism;
abstract class Shape3{
	abstract double calculateArea(int x,int y);
	public void draw()
	{
		System.out.println("draw a shape");
	}
}
class Rectangle extends Shape3
{
	double calculateArea(int x,int y)
	{
		return x*y;
		
	}
}
class Triangle2 extends Shape3
{
	double calculateArea(int x,int y)
	{
		return (x*y)/2;
	}
}
public class AbsDemo {
	public static void main(String args[])
	{
		//Shape3 s=new Shape3();//not possible,compile time error
		Rectangle r=new Rectangle();
		double area1=r.calculateArea(4,5);
		System.out.println("Area1 :"+area1);
		r.draw();
//reference type of shape is possible and it refers to subclass object rectangle
		Shape3 s=new Rectangle();
		double area2=s.calculateArea(4,5);
		System.out.println("Area1 :"+area2);
		s.draw();
		s=new Triangle2();
		double area3=s.calculateArea(2, 3);
		System.out.println("Area3 :" +area3);
		s.draw();
		
		
		
	}

}
