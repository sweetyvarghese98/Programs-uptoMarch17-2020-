package com.cognizant.polymorphism;
class Shape2{void display(){
		System.out.println("Shape Display");}void hello(){
		System.out.println("hello");}}
class Circle2 extends Shape2
{void display(){
		System.out.println("Circle display");}
	void print(){
		System.out.println("printing method in circle");}}
class Painter{
	void method(Shape2 s){
		s.display();
		s.hello();
		//s.print();//it will not work because abstration is done for print method
		//in circle clss
		}}public class AbstractDemo {
	public static void main(String args[])
	{ Shape2 shape=new Shape2();
	  Circle2 circle=new Circle2();
	  Painter p=new Painter();
	  p.method(shape);//everything in shape class is passed
	  p.method(circle);//only those extended frm superclass is passed.other things hided
	//implies abstraction
}}


