package com.cognizant.polymorphism;
class A
{void callMe(){
		System.out.println("A");
	}
}
class B extends A
{	
	void callMe(){
	System.out.println("B");}}
class C extends A
{
	void callMe()
	{
		System.out.println("C");}}
public class DemoPolymorphism {
	public static void main(String args[]){
		A ref=new A();
		ref.callMe();
		ref=new B();
		ref.callMe();
		ref=new C();
		ref.callMe();}}
