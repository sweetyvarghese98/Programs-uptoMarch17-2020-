package com.cognizant.polymorphism;
class Shape{
	void draw(){
		System.out.println("Im drawing a shape");}}
class Circle extends Shape{
	void draw(){
		System.out.println("Im drawing a circle");
	}}
class Square extends Shape{
	void draw(){
		System.out.println("Im drawing a square");}}
class Triangle extends Shape{
	void draw(){
		System.out.println("Im drawing a traingle");}}
public class DemoPolymorphism1 {
	public static void main(String args[]){
		Shape s=new Shape();
		s.draw();
		s=new Circle();//here also upcasting is done that step can be avoided
		s.draw();//gives draw of subclass circle that is overriding superclass draw
		s=new Square();
		s.draw();
		s=new Triangle();
		s.draw();}}
