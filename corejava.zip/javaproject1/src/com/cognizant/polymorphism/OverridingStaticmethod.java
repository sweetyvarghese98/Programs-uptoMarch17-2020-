package com.cognizant.polymorphism;
class W
{
	static void draw(){
		System.out.println("im drawing");
	}
}
class S extends  W
{
	static void draw(){
		System.out.println("im drawing in subclass");
	}
}
public class OverridingStaticmethod {
	public static void main(String args[])
	{
		S obj=new S();
		obj.draw();
		
	}

}
