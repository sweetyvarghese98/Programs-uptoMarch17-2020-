package com.cognizant.polymorphism;
class Shape1{
	void draw(){
		System.out.println("Im drawing a shape");}}
class Circle1 extends Shape1{
	void draw(){
		System.out.println("Im drawing a circle");}
	void hello(){//abstraction or hiding ie hello method is circles it cant be accesssed
		//using superclass obj,should create circle obj and call using it
		System.out.println("sayhello");}}
class Square1 extends Shape1{
	void draw(){
		System.out.println("Im drawing a square");}}
class Triangle1 extends Shape1{
	void draw(){
		System.out.println("Im drawing a traingle");}
}public class DemoPolymorphismShape {
	public static void main(String args[])
	{Shape1 s=new Shape1();
		s.draw();
		s=new Circle1();//here circle is a shape only
		Circle1 c=new Circle1();
		c.hello();
		//s.hello();//to get this we have to create object of circle
		}}
