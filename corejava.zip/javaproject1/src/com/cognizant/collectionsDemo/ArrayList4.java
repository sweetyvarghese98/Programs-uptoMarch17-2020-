package com.cognizant.collectionsDemo;

import java.util.ArrayList;
import java.util.Iterator;

class CountryClass{
	ArrayList<String> createCountryList(){
		ArrayList<String> countrylist=new <String>ArrayList();
		countrylist.add("India");
		countrylist.add("Australia");
		countrylist.add("China");
		countrylist.add("US");
		countrylist.add("Russia");
		return countrylist;
		
		
		
	}
}
public class ArrayList4 {
	public static void main(String args[]){
	CountryClass cc=new CountryClass();
	ArrayList result=cc.createCountryList();
	Iterator<String> iterator=result.iterator();
	while(iterator.hasNext())
	{
		String country=iterator.next();
		System.out.println(country);
	}
		
	}

}
