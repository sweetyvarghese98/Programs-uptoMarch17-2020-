package com.cognizant.collectionsDemo;

import java.util.ArrayList;

public class ArrayListMain2 {
public static void main(String args[])
{
	ArrayList<String> a1=new ArrayList<String>();
	a1.add("Apple");
	a1.add("Orange");
	a1.add("apple");
	a1.add("orange");
	a1.add(0,"mango");//it will push 0th index value to first
	System.out.println(a1);
	a1.add("KIWI");
	System.out.println(a1);
	//create empty collection
	ArrayList<String> a2=new ArrayList<String>();
	boolean res=a2.isEmpty();
	System.out.println("a2 is empty?"+res);
	a2.addAll(a1);
	System.out.println("a2 is empty?"+a2.isEmpty());
	a2.addAll(a1);
	System.out.println(a2);
	a2.clear();
	System.out.println(a2);
	boolean o=a2.contains("mango");
	System.out.println(o);
	boolean r=a1.contains("apple");
	System.out.println(r);
	for(String myElement:a2){
		System.out.println(myElement);
		//objRef.method(myElement);
		}
	System.out.println("Index of apple:"+a1.indexOf("apple"));
	System.out.println("What is the last index of apple:");
	System.out.println(a1.lastIndexOf("apple"));
	System.out.println(a1.indexOf("mango"));//if mango is not there
	System.out.println(a1.lastIndexOf("Apple"));
	//remove method
	a1.remove(0);//removed 0th index value
	System.out.println(a1);
}
}
