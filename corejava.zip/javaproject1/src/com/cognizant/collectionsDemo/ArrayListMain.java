package com.cognizant.collectionsDemo;
import java.util.ArrayList;
import java.util.Collections;
class Employee
{
	int id;
	String name;
}
public class ArrayListMain {
	public static void main(String sargs[])
	{	Employee e1=new Employee();
		Employee e2=new Employee();
		Integer i2=new Integer(25);
		ArrayList<String> a1=new ArrayList<String>();//now only give string in array list
		//ArrayList<Integer> a1=new ArrayList<Integer>();//for integers only
		//ArrayList<Employee> a1=new ArrayList<Employee>();//for employee objects
		a1.add("Apple");
		a1.add("Orange");
		a1.add("Mango");
		a1.add("apple");
		a1.add("orange");
		a1.add("mango");
		a1.add("apple");
		//a1.add(new Integer(25));
		//a1.add(e1);
		//a1.add(e2);
		//a1.add(i2);
		System.out.println(a1);
		System.out.println(a1.get(2));
		Collections.sort(a1);//static utility method
		System.out.println(a1);
	}

}
