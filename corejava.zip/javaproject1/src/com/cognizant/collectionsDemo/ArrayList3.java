package com.cognizant.collectionsDemo;

import java.util.ArrayList;
import java.util.Iterator;

class StateClass
{
	//ArrayList is the returntype for method
	ArrayList<String> createStateList(){
	ArrayList<String> statelist=new <String>ArrayList();
	statelist.add("Kerala");
	statelist.add("TamilNadu");
	statelist.add("Karnataka");
	statelist.add("Andrapradesh");
	return statelist;
	}
	
}
public class ArrayList3 {
public static void main(String args[])
{	
	StateClass st=new StateClass();
	ArrayList<String> result=st.createStateList();
	//use iterator or enhanced for loop
	/*for(String s:result)
	{
		System.out.println(s);
	}*/
	Iterator<String> iterator=result.iterator();
	while(iterator.hasNext())
	{
		String states=iterator.next();
		System.out.println(states);
	}
}
}
