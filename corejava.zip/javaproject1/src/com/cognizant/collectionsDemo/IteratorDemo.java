package com.cognizant.collectionsDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorDemo {
	public static void main(String args[])
	{
		ArrayList<String> colorlist=new ArrayList<String>();
		colorlist.add("red");
		colorlist.add("white");
		colorlist.add("black");
		//to obtain the iterator
		Iterator<String> iterator=colorlist.iterator();
		//use whileloop
		while(iterator.hasNext())
		{
			String element=iterator.next();
			System.out.println(element);
			if(element.equals("white"))
				iterator.remove();
		}
		System.out.println(colorlist);
	}

}
