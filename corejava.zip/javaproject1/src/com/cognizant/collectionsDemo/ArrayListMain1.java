package com.cognizant.collectionsDemo;

import java.util.Collections;
import java.util.Vector;

public class ArrayListMain1 {
	public static void main(String args[])
	{
		Vector<String> a1=new Vector<String>();
		a1.add("Apple");
		a1.add("Orange");
		a1.add("Mango");
		a1.add("apple");
		a1.add("orange");
		a1.add("mango");
		a1.add("apple");
		String s=a1.get(2);
		System.out.println(a1);
		System.out.println(a1.get(2));
		Collections.sort(a1);
		System.out.println(a1);
		
	}

}
