package com.cognizant.collectionsDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListMain3 {
public static void main(String args[])
{
	ArrayList<String> a1=new ArrayList();
	a1.add("Apple");
	a1.add("Orange");
	a1.add("Melon");
	a1.add("Pumpkin");
	System.out.println("a1: "+a1);
	ArrayList<String>a2=new ArrayList();
	a2.add("Apple");
	a2.add("Pumpkin");
	//a1.removeAll(a2);//remove from a1 which is common in a2
	System.out.println("a1: "+a1);
	System.out.println("a2: "+a2);
	System.out.println("before retainall a1 size:"+a1.size());
	a1.retainAll(a2);//what is common or matching is retained in a1
	System.out.println("a1: "+a1);
	Iterator <String> iterator=a1.iterator();
	System.out.println("a1: using iterator");
	while(iterator.hasNext())
	{
		String first=iterator.next();
		System.out.println(first);
	}
	//System.out.println(a1.removeRange( 0, 1));
	System.out.println("after retainall a1 size:"+a1.size());

}
}
