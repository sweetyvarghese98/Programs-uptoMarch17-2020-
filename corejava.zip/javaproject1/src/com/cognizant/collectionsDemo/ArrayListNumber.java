package com.cognizant.collectionsDemo;

import java.util.ArrayList;
import java.util.Iterator;

class NumberGenerator{
	ArrayList<Integer> generateNumberList(){
		ArrayList<Integer> numberlist=new <Integer>ArrayList();
			for(int i=100;i<=110;i++)
			{
				numberlist.add(i);//or numberlist.add(new integer(i))//integer is converted to wrapper(obj type);
			}
			return numberlist;
		}
	}

public class ArrayListNumber {

	public static void main(String[] args) {
		NumberGenerator ng=new NumberGenerator();
		ArrayList<Integer>result=ng.generateNumberList();
		System.out.println(result);
		Iterator<Integer> iterator=result.iterator();
		while(iterator.hasNext())
		{
			Integer number=iterator.next();
			System.out.println(number);
		
	}
		/*for(Integer i:result)
		 {System.out.println(i.intValue());} //obj to primitive*/
		 
		

	}

}
