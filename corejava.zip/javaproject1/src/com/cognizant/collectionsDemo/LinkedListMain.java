package com.cognizant.collectionsDemo;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListMain {
public static void main(String args[])
{	LinkedList<String> a1=new <String>LinkedList();
	a1.add("Apple");
	a1.add("Orange");
	a1.add("Mango");
	a1.add("apple");
	a1.add("orange");
	a1.add("mango");
	a1.add("apple");
	System.out.println(a1);
	//to print one by one iterator is used
	Iterator<String> iterator=a1.iterator();
	while(iterator.hasNext())
	{
		String fruit=iterator.next();
		System.out.println(fruit);
	}
	System.out.println("******");
	System.out.println(a1.get(2));//to get 2nd index value
	System.out.println(a1.indexOf("Mango"));//to get index of Mango
}
}
