package com.cognizant.p3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
class Employee implements Comparable<Employee>{
	int id;
	String name;
	Date dateOfJoin;
	Double salary;
	
	Employee(	int id,String name,Date dateOfJoin,Double salary)
	{
		this.id=id;
		this.name=name;
		this.dateOfJoin=dateOfJoin;
		this.salary=salary;
	}
	public String toString(){
		return "Id "+id+ " name " +name+ "  datOfJoin "+dateOfJoin +" salary "+salary;
	}
	public void getId()
	{
		
	}
	@Override
	/*public int compareTo(Employee o) {
		//return integer always
		// TODO Auto-generated method stub
		return this.id-o.id;//int and double give -
		
	}*/
/*	public int compareTo(Employee o)
	 {
	  //returns an integer always
	 return this.name.compareTo(o.name);//for strings give .compareTo
 
}*/
	public int compareTo(Employee o){
	return (int) (this.salary-o.salary);	//since salary is double casting is given
	}
/*	public int  compareTo(Employee o)
	{
		//returns an integer always
		return this.dateOfJoin.compareTo(o.dateOfJoin);
	}*/
}
public class ComparableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Employee> Emplist=new ArrayList<Employee>();
GregorianCalendar gc=new GregorianCalendar(2011,04,25);
Date d1=gc.getTime();
Employee e1=new Employee(2345,"paul",d1,3500.0);
gc=new GregorianCalendar(2011,05,26);
Date d2=gc.getTime();
Employee e2=new Employee(2346,"kumar",d2,7500.0);
gc=new GregorianCalendar(2012,05,26);
Date d3=gc.getTime();
Employee e3=new Employee(2347,"Arun",d3,6500.0);
gc=new GregorianCalendar(2011,05,27);
Date d4=gc.getTime();
Employee e4=new Employee(2348,"Ram",d4,5500.0);

Emplist.add(e4);
Emplist.add(e2);
Emplist.add(e3);
Emplist.add(e1);
System.out.println("Before sorting");
//System.out.println(Emplist);,to print one by one
for(Employee e:Emplist)
{
	System.out.println(e);
}

System.out.println("After sorting");
Collections.sort(Emplist);
for(Employee e:Emplist){
System.out.println(e);//toString method is called because e is obj ref variable
}
	
System.out.println("After sorting in reverse order");
Collections.sort(Emplist,Collections.reverseOrder());
for(Employee e:Emplist){
System.out.println(e);
		
	}
	
}

	}


