package com.cognizant.p3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;

class Product implements Comparable<Product>
{
	int productId;
	String productName;
	Date dateOfManufacture;
	Double price;

Product (int productId,String productName,Date dateOfManufacture,Double price){
	this.productId=productId;
	this.productName=productName;
	this.dateOfManufacture=dateOfManufacture;
	this.price=price;
}
public String toString()
{
	return "Productid "+productId+ " Productname "+productName+" dateofmanufacture "+dateOfManufacture+
			" Price "+price;
}
/*public int compareTo(Product o){
	return this.productId-o.productId;
}*/
/*public int compareTo(Product o){
	return this.productName.compareTo(o.productName);
}*/
/*public int compareTo(Product o){
	return this.dateOfManufacture.compareTo(o.dateOfManufacture);
}*/
public int compareTo(Product o){
	return (int) (this.price-o.price);
}
}
public class ComparableDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Product> Plist=new ArrayList<Product>();
		GregorianCalendar gc=new GregorianCalendar(2020,01,19);
		Date d1=gc.getTime();
		Product p1=new Product(100,"TV",d1,20000.0);
		gc=new GregorianCalendar(2020,01,20);
		Date d2=gc.getTime();
		Product p2=new Product(200,"FRIDGE",d2,30000.0);
		gc=new GregorianCalendar(2020,01,21);
		Date d3=gc.getTime();
		Product p3=new Product(300,"WASHING MACHINE",d3,40000.0);
		gc=new GregorianCalendar(2020,01,22);
		Date d4=gc.getTime();
		Product p4=new Product(400,"AC",d4,50000.0);
		Plist.add(p4);
		Plist.add(p2);
		Plist.add(p3);
		Plist.add(p1);
		
		System.out.println("Before sorting");
		for(Product p:Plist){
			System.out.println(p);
		}
		
		/*System.out.println("After Sorting based on productid");
		Collections.sort(Plist);
		for(Product p:Plist){
			System.out.println(p);
		}
		
		System.out.println("After Sorting based on productname");
		Collections.sort(Plist);
		for(Product p:Plist){
			System.out.println(p);
		}
		
		System.out.println("After Sorting based on dateofmanufacture");
		Collections.sort(Plist);
		for(Product p:Plist){
			System.out.println(p);
		}*/
		
		System.out.println("After Sorting based on price");
		Collections.sort(Plist);
		for(Product p:Plist){
			System.out.println(p);
		}
		
	}

}
