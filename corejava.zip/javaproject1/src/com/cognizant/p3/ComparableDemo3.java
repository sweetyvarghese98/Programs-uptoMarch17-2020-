package com.cognizant.p3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;


class Customer implements Comparable<Customer>{
	int id;
	String name;
	Date dateOfJoin;

	Customer(int id,String name,Date dateOfJoin)
	{
		this.id=id;
		this.name=name;
		this.dateOfJoin=dateOfJoin;
	}
	public String toString(){
		return "Id "+id+" name"+name+ " dateofjoin "+dateOfJoin;
	}
	@Override
	public int compareTo(Customer o) {
		// TODO Auto-generated method stub
		if(this.id-o.id!=0)
		{
			return this.id-o.id;
		}
	else if(this.name.compareTo(o.name)!=0)
		{
			return this.name.compareTo(o.name);
		}
		else
		{
			return this.dateOfJoin.compareTo(o.dateOfJoin);
		}
	}
	
}
public class ComparableDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Customer> clist=new ArrayList<Customer>();
		GregorianCalendar gc=new GregorianCalendar(2020,03,6);
		Date d1=gc.getTime();
		Customer c1=new Customer(100," Anjaly",d1);
		gc=new GregorianCalendar(2020,03,12);
		Date d2=gc.getTime();
		Customer c2=new Customer(100," Sweet",d2);
		gc=new GregorianCalendar(2020,03,20);
		Date d3=gc.getTime();
		Customer c3=new Customer(100," Sweety",d3);
		gc=new GregorianCalendar(2020,03,26);
		Date d4=gc.getTime();
		Customer c4=new Customer(100," Ammu",d4);

		clist.add(c1);
		clist.add(c2);
		clist.add(c3);
		clist.add(c4);
		System.out.println("Sorting");
		Collections.sort(clist);
		for(Customer c:clist)
		{
			System.out.println(c);
		}
		
			}

		}
