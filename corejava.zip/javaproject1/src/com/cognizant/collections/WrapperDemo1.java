package com.cognizant.collections;

public class WrapperDemo1 {
public static void main(String args[])
{
	//using string creating wrappper
	String s1=new String("100");
	Integer i1=new Integer(s1);//converted to integer wrapper class
	System.out.println(i1);
	int res=i1.intValue();//converted back to primitive int
	System.out.println(res+1);//to show res is converted to primitive res+1
	byte b=i1.byteValue();//show value if integer bet -256 and +256
	System.out.println(b);
	float f=i1.floatValue();
	System.out.println(f);
	Double dd=i1.doubleValue();//automatically converted to wrapper
	System.out.println(dd);
	//+ can be used for concatenation
	String str="100"+1;//"1001"
	System.out.println(str+1);
	Integer i2=new Integer(str);
	System.out.println(i2.intValue());
	//not a number => NaN
	Double double1=new Double(0.0/0.0);
	System.out.println(double1);
	Double double2=new Double(1.0/0.0);
	System.out.println(double2.isNaN());//false
	//boolean Wrapper
	boolean bool1=true;
	Boolean bw=new Boolean(bool1);
	System.out.println(bw);
	Boolean bool2=new Boolean("true");//boolean not case sensitive
	Boolean bool3=new Boolean("TRUE");//"
	Boolean bool4=new Boolean("fAlSe");//"
	Boolean bool5=new Boolean(false);//"
	System.out.println(bool2);
	System.out.println(bool3);
	System.out.println(bool4);
	System.out.println(bool5);
}
}
