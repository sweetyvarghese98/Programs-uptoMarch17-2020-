package com.cognizant.collections;
class DemoInt{
	static int x=45;
}
public class MaxValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		System.out.println(DemoInt.x);
		System.out.println(Double.MAX_VALUE);
		System.out.println(Double.MIN_VALUE);
	}

}
