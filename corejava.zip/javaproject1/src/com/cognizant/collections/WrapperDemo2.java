package com.cognizant.collections;
class Product{
	Integer productId;//datatype is wrapper
	String productName;
	Double price;//datatype is wrapper
	Boolean isExpiryDateAvailable;
	String barCodeInfo;
	String manufacturer;
	Float tax;
	Product(Integer productId,String productName,Double price,Boolean isExpiryDateAvailable,
	String barCodeInfo,String manufacturer,Float i)
	{	this.productId=productId;
		this.productName=productName;
		this.price=price;
		this.isExpiryDateAvailable=isExpiryDateAvailable;
		this.barCodeInfo=barCodeInfo;
		this.manufacturer=manufacturer;
		this.tax=i;
		
	}
	public String toString()//used tostring method also to print
	{
		
		return "["+this.productId +","+this.productName+","+ price+"," + isExpiryDateAvailable+","+ barCodeInfo+","+tax+"]";
	}
}
public class WrapperDemo2 {
	public static void main(String args[])
	{	Product p=new Product(100,"abc",365.9,true,"EFGDJ","ABC",5.2f);
		Product p1=new Product(102,"ght",257.0,false,"fgfgfg","GHT",3.5f);
		//Product P=new P 
		/*System.out.println(p.productId);
		System.out.println(p.productName);
		System.out.println(p.price);
		System.out.println(p.isExpiryDateAvailable);
		System.out.println(p.barCodeInfo);
		System.out.println(p.manufacturer);
		System.out.println(p.tax);*/
		System.out.println(p);
		System.out.println(p1);
		Product[] productsArr=new Product[2];
		productsArr[0]=p;
		productsArr[1]=p1;
		for(int i=0;i<productsArr.length;i++){
			Product obj=productsArr[i];
			System.out.println(obj);
		}
		
		
		
		
	}

}
