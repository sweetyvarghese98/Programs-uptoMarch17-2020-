package com.cognizant.collections;

public class StringDemo {
public static void main(String args[])
{
	String s1="abcd";
	String s2="abcd";
	System.out.println(s1==s2);//same memory to s1 and s2 strings so true
	s2="bcdd";
	System.out.println(s1==s2);//false
	String s3=new String("abcd");//here new memory is given to abcd 
	System.out.println(s1==s3);//so false
	String s4=new String("abcd");
	System.out.println(s1==s4);
	String s5=new String("abcd");
	System.out.println(s4==s5);
	
	String s6=new String("1234");
	String s7=new String("1234");
	System.out.println(s6==s7);
}
}
