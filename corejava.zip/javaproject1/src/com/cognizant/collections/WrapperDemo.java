package com.cognizant.collections;

public class WrapperDemo {
public static void main(String args[])
{
	//int 
	int a=25;
	Integer i1=new Integer(a);//primitive int converted to wrapper
	System.out.println(i1);
	int b=i1.intValue();//intvalue for converting wrapper back to primitive
	System.out.println(a==b);
	System.out.println(i1);
	char c='m';
	Character c1=new Character(c);
	System.out.println(c1);
	
	
}
}
