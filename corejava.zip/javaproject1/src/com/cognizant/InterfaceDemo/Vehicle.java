package com.cognizant.InterfaceDemo;

public class Vehicle {
	

}
class Aeroplane extends Vehicle implements Flyer{

	@Override
	public void fly() {
		// TODO Auto-generated method stub
	System.out.println("Aeroplane flies");	
	}

	@Override
	public void land() {
		// TODO Auto-generated method stub
	System.out.println("Aeroplane lands");	
	}

	@Override
	public void takeoff() {
		// TODO Auto-generated method stub
		System.out.println("Aeroplane takeoff");
	}

}
