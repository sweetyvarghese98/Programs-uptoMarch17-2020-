package com.cognizant.InterfaceDemo;

public class Animal {
	

}
class Bird extends Animal implements Flyer{

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("Bird flies");
	}

	@Override
	public void land() {
		// TODO Auto-generated method stub
		System.out.println("Bird lands");
	}

	@Override
	public void takeoff() {
		// TODO Auto-generated method stub
		System.out.println("Bird takeoff");
	}
	
}
