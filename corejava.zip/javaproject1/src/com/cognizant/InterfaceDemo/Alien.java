package com.cognizant.InterfaceDemo;

public class Alien {

}
class Superman extends Alien implements Flyer{

	@Override
	public void fly() {
		// TODO Auto-generated method stub
	System.out.println("Superman flies");	
	}

	@Override
	public void land() {
		// TODO Auto-generated method stub
	System.out.println("Superman lands");
	}

	@Override
	public void takeoff() {
		// TODO Auto-generated method stub
	System.out.println("Superman takeoff");	
	}
	
}
