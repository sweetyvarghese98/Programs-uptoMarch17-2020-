package com.cognizant.InterfaceDemo;

interface Flyer {
	void fly();
	void land();
	void takeoff();

}
