package com.cognizant.InterfaceDemo;

public class MainClass {
	public static void main(String args[])
	{
	Flyer ob=new Bird();
	ob.fly();
	ob.land();
	ob.takeoff();
	Flyer ob1=new Aeroplane();
	ob1.fly();
	ob1.land();
	ob1.takeoff();
	
	}

}
