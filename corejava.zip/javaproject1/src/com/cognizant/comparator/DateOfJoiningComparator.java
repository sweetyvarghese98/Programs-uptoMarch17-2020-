package com.cognizant.comparator;
import java.util.Comparator;
public class DateOfJoiningComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
	return o1.dateOfJoin.compareTo(o2.dateOfJoin);	
	}

}
