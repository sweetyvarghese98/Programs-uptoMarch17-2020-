package com.cognizant.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;




class Employee{
	int empId;
	String empName;
	Date dateOfJoin;
	Double salary;
Employee(int empId,String empName,Date dateOfJoin,Double salary)
{
	this.empId=empId;
	this.empName=empName;
	this.dateOfJoin=dateOfJoin;
	this.salary=salary;
}
public String toString()
{
	return "id "+empId+" name "+empName+" datofjoin "+dateOfJoin+ " salary "+salary;
}
}
public class CamparatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee> emplist=new ArrayList<Employee>();
		GregorianCalendar gc=new GregorianCalendar(2020,05,2);
		Date d1=gc.getTime();
		Employee e1=new Employee(100, "Sweety",d1,20000.0);
		gc=new GregorianCalendar(2020,05,10);
		Date d2=gc.getTime();
		Employee e2=new Employee(101, "Sweety",d1,30000.0);
		gc=new GregorianCalendar(2020,05,12);
		Date d3=gc.getTime();
		Employee e3=new Employee(102, "Parvathy",d3,40000.0);
		gc=new GregorianCalendar(2020,05,20);
		Date d4=gc.getTime();
		Employee e4=new Employee(103, "Anjaly",d4,50000.0);
		
		emplist.add(e1);
		emplist.add(e3);
		emplist.add(e2);
		emplist.add(e4);
		SalaryComparator idc=new SalaryComparator();
		//Collections.sort(emplist,new NameComparator().thenComparing(new DateOfJoiningComparator()));
		
		Collections.sort(emplist,idc);
		for(Employee e:emplist){
		System.out.println(e);
		}
		System.out.println("******");
		Collections.sort(emplist,new NameComparator().thenComparing(new DateOfJoiningComparator()).thenComparing(new SalaryComparator()));
	
		for(Employee e:emplist){
			System.out.println(e);
			}
		

	}
}
