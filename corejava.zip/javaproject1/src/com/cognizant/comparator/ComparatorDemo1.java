package com.cognizant.comparator;

import java.util.ArrayList;
import java.util.Collections;

class Movie implements Comparable<Movie>{
	int id;
	String name;
	Double price;
	Movie(int id,String name,Double price)
	{
		this.id=id;
		this.name=name;
		this.price=price;
	}
	public String toString()
	{
		return "id "+id+ " name"+name+"price "+price;
	}
	@Override
	public int compareTo(Movie o) {
	if(this.id-o.id!=0){
		return this.id-o.id;
	}
	else if(this.name.compareTo(o.name)!=0)
	{
		return this.name.compareTo(o.name);
	}
	else
		return this.price.compareTo(o.price);
		
	}
}
public class ComparatorDemo1 {

	public static void main(String[] args) {
		ArrayList<Movie> am=new ArrayList<Movie>();
		Movie m=new Movie(100, "a", 200.0);
		Movie m1=new Movie(100, "b", 300.0);
		Movie m2=new Movie(100, "b", 250.0);
		am.add(m);
		am.add(m1);
		am.add(m2);
		Collections.sort(am);
		for(Movie mo:am)
		{
			System.out.println(mo);
		}
		Collections.sort(am,Collections.reverseOrder());
		for(Movie mo:am)
		{
			System.out.println(mo);
		}
		
		
		
	}

}
