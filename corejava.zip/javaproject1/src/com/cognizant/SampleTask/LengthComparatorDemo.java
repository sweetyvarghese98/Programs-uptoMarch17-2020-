package com.cognizant.SampleTask;

import java.util.ArrayList;
import java.util.Collections;


public class LengthComparatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> a1=new ArrayList<String>();
/*StringSort ss1=new StringSort("nnn");
StringSort ss2=new StringSort("MMMM");
StringSort ss3=new StringSort("yyyyyyy");
StringSort ss4=new StringSort("XXXX");
StringSort ss5=new StringSort("aaaaa");
StringSort ss6=new StringSort("bbbbbbb");
StringSort ss7=new StringSort("cccc");
StringSort ss8=new StringSort("dddd");
StringSort ss9=new StringSort("eeeef");
StringSort ss10=new StringSort("oooooooooo");*/

a1.add("nnn");
a1.add("MMMM");
a1.add("yyyyyyy");
a1.add("XXXX");
a1.add("aaaaa");
a1.add("bbbbbbb");
a1.add("cccc");
a1.add("dddd");
a1.add("eeeef");
a1.add("oooooooooo");
LengthComparator lc=new LengthComparator();
Collections.sort(a1,lc);
System.out.println("Sorting based on ascending order of length ");
for(String s1:a1)
{
	System.out.println(s1);
}
Collections.sort(a1,Collections.reverseOrder(lc));
System.out.println("Sorting based on descending order of length ");
for(String s1:a1)
{
	System.out.println(s1);
}





	}

}
