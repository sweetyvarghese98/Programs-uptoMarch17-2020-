package com.cognizant.SampleTask;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class FileString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1=new File("C://file//string.txt");//similarly audio etc will work
		File dest1=new File("C://file//string_copy.txt");
		FileInputStream fis=null;
		FileOutputStream fos=null;
		int b;
		System.out.println("Started");
		try {
			fis=new FileInputStream(f1);
			fos=new FileOutputStream(dest1);
			
			//to copy
			
			while( (b=fis.read() ) !=-1){
				ArrayList<Character> a1=new ArrayList<Character>();
				a1.addAll('b');
				LengthComparator lc=new LengthComparator();
				Collections.sort(a1,lc);
				System.out.println("Sorting based on ascending order of length ");
				for(String s1:a1)
				{
					System.out.println(s1);
					
				}
				
				fos.write(a1);
			}
			fos.flush();//to force 1 file copy to other
			System.out.println("end");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


			}

		
	}


