package com.cognizant.InterfaceDemoTask;

interface publicTransport {
	void getMaximumPassengers();

}
