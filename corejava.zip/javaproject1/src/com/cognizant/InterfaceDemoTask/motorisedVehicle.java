package com.cognizant.InterfaceDemoTask;

interface motorisedVehicle {
	void drive();
	void turnLeft();
	void turnRight();

}
