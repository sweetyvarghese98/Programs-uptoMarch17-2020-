package com.cognizant.InterfaceDemoTask;

public class InterfaceDemoTask {
	public static void main(String srgs[])
	{
		car m=new car();
		m.drive();
		m.turnLeft();
		m.turnRight();
		bus p=new bus();
		p.drive();
		p.turnLeft();
		p.turnRight();
		p.getMaximumPassengers();
		
		
		
		
	}

}
