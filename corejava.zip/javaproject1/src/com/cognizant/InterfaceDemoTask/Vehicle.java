package com.cognizant.InterfaceDemoTask;

public class Vehicle {

}
class car extends Vehicle implements motorisedVehicle{

	@Override
	public void drive() {
		// TODO Auto-generated method stub
	System.out.println("car driving");	
	}

	@Override
	public void turnLeft() {
		// TODO Auto-generated method stub
	System.out.println("car turnleft");	
	}

	@Override
	public void turnRight() {
		// TODO Auto-generated method stub
	System.out.println("car turnright");	
	}
	
}
class bus extends Vehicle implements motorisedVehicle,publicTransport{

	@Override
	public void getMaximumPassengers() {
		// TODO Auto-generated method stub
	System.out.println(5);
	}

	@Override
	public void drive() {
		// TODO Auto-generated method stub
	System.out.println("bus driving");	
	}

	@Override
	public void turnLeft() {
		// TODO Auto-generated method stub
	System.out.println("bus turnleft");	
	}

	@Override
	public void turnRight() {
		// TODO Auto-generated method stub
	System.out.println("bus turnright");	
	}
	
}