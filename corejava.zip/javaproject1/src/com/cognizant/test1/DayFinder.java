package com.cognizant.test1;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class DayFinder {

public static void main(String[] args) {
Scanner s=new Scanner(System.in);
System.out.println("Enter the Ist date in yyyy-MM-dd format");
String str1=s.nextLine();
System.out.println("Enter the 2nd date in yyyy-MM-dd format");
String str2=s.nextLine();
System.out.println("Enter the 2nd date in yyyy-MM-dd format");
String str3=s.nextLine();
SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
SimpleDateFormat sdf1=new SimpleDateFormat("EEEE");
java.util.Date date=null;
String ds1=null;

 try {
	date=sdf.parse(str1);
	ds1=sdf1.format(date);
} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
 java.util.Date date1=null;
 String ds2=null;
try {
	date1=sdf.parse(str2);
	ds2=sdf1.format(date1);
} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
java.util.Date date2=null;
String ds3=null;
try {
	date2=sdf.parse(str3);
	ds3=sdf1.format(date2);
} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
ArrayList<String>a1=new ArrayList<String>();
a1.add(ds1);
a1.add(ds2);
a1.add(ds3);
System.out.println(a1);

	}

}
