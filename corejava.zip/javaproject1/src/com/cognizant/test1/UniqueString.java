package com.cognizant.test1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
class Count{
	HashMap<String,Integer> hm=new HashMap<String,Integer>();
	HashSet<Character> hs=new HashSet<Character>();
	int checkCache(String s){
		int cacheCount = 0;
		Set< Entry<String,Integer>>entries=hm.entrySet();
		ArrayList<String>a1=new ArrayList<String>();
		for(Entry<String,Integer>e:entries)
		{
			String key=e.getKey();
			Integer value=e.getValue();
			a1.add(key);
		}
		Iterator<String>i=a1.iterator();
		while(i.hasNext())
		{
			String strkey=i.next();
			
			for(Entry<String,Integer>e:entries)
			{
				String key=e.getKey();
				Integer value=e.getValue();
				if(s.equals(strkey))
				{
					cacheCount=e.getValue();
					
				}
			}
		
		
	}
		return cacheCount;}
	public Integer uniqueString(String s)
	{	int count=0;
		int cacheValue=checkCache(s);
		if(cacheValue==0)
		{
			
			for(int i=0;i<s.length();i++)
			{
				Character c=s.charAt(i);
				hs.add(c);
			}
			count=hs.size();
			hm.put(s, count);
			System.out.println(hm);
			//System.out.println(count);
			}
		return count;
		}
}

	


public class UniqueString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the string");
String str=s.nextLine();
Count c=new Count();
int res=c.uniqueString(str);
System.out.println(res);



	}

}
