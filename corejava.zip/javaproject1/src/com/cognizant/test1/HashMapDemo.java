package com.cognizant.test1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;

class Country  {
	void sortHashMap(HashMap<String,String> hm){
	ArrayList<String>a1=new ArrayList<String>();
	Set <Entry<String,String>> entries=hm.entrySet();
	for(Entry<String,String>e:entries)
	{
		String key=e.getKey();
		String value=e.getValue();
		a1.add(value);
	}
		Collections.sort(a1);
		System.out.println(a1);
		Iterator<String> i=a1.iterator();
	while(i.hasNext())
	
	{
		String str1=i.next();
		for(Entry<String,String>e:entries)
		{
			String key=e.getKey();
			String value=e.getValue();
			if(str1.compareTo(value)==0){
				System.out.println(key +"   "+value);
										}
		}
	}
}
}

public class HashMapDemo {

	public static void main(String[] args) {
		HashMap<String,String> hm=new HashMap();
		hm.put("India", "NewDelhi");
		hm.put("China","Beijing");
		hm.put("Australia","Canberra");
		hm.put("Us", "WashingtonD.C");
		Country c=new Country();
		c.sortHashMap(hm);

			}

		}

