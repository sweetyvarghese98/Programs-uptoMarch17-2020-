package com.cognizant.test1;

import java.util.Date;

public class Movie {
private int movieId;
private String movieName;
private Date date;
private Double price;

Movie(int movieId,String movieName,Date date,Double price){
	this.movieId=movieId;
	this.movieName=movieName;
	this.date=date;
	this.price=price;
	
}
public void setmovieId(int movieId){
	this.movieId=movieId;
}
public int getmovieId(){
return this.movieId;	
}

public void setmovieName(String movieName){
	this.movieName=movieName;
}
public String getmovieName(){
return this.movieName;	
}

public void setdate(Date date){
	this.date=date;
}
public Date getdate(){
return this.date;	
}

public void setprice(double price){
	this.price=price;
}
public double getprice(){
return this.price;	
}


}
