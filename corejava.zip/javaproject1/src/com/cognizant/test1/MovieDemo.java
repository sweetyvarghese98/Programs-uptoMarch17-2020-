package com.cognizant.test1;

import java.sql.Date;
import java.util.GregorianCalendar;

public class MovieDemo {

	public static void main(String[] args) {
		
		GregorianCalendar gc=new GregorianCalendar(2020,9,16);
		java.util.Date d1=gc.getTime();
		Movie m=new Movie(100,"Movie1",d1,100.0);
		m.setmovieId(101);
		m.setmovieName("Movie1");
		m.setdate(d1);
		m.setprice(200.0);
		System.out.println(m.getmovieId());
		System.out.println(m.getmovieName());
		System.out.println(m.getdate());
		System.out.println(m.getprice());
		
		




	}

}
