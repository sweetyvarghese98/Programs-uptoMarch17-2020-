package com.cognizant.test1;

import java.util.Scanner;
class CountNumber{int count1=0,count2=0;
	void countVc(String str){
		
		for(int i=0;i<15;i++){
			
			if(str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u'||str.charAt(i)=='A'
					||str.charAt(i)=='E'||str.charAt(i)=='I'||str.charAt(i)=='O'||str.charAt(i)=='U')
			{
			count1=count1+1;
			
			}
		else{
			count2=count2+1;
			
			}
		}
		System.out.println("vowels: "+count1);
		System.out.println("consanants: "+count2);
		
	}
}
	
public class StringCountVC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);

System.out.println("Enter a string of length 15 characters");



	String str=s.nextLine();

CountNumber cn=new CountNumber();
cn.countVc(str);


	}

		}

