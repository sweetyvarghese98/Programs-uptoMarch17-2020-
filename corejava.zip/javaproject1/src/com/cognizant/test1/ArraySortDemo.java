package com.cognizant.test1;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
public class ArraySortDemo {
public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the array");
		int a[]=new int[4];
		LinkedList<Integer> list=new LinkedList<Integer>();
		for(int i=0;i<4;i++)
		{
			a[i]=s.nextInt();
			list.add(a[i]);
		}
		Collections.sort(list);
		System.out.println("The array is:"+list);
		System.out.println("Enter a number");
		int n=s.nextInt();
		if(list.contains(n)){
			System.out.println("Index of entered number:"+list.indexOf(n));}else {
			list.add(n);
			Collections.sort(list);
			System.out.println(list);
			System.out.println("Index:"+list.indexOf(n));}}}
