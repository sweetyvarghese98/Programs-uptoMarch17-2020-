package com.cognizant.test1;
import java.util.Scanner;
public class Calculator {
	static void add(int a,int b){
		int res=a+b;
		System.out.println("Sum: "+res);
	}
	static void sub(int a,int b){
		int res=a-b;
		System.out.println("Difference: "+res);
		
	}
	static void mult(int a,int b){
		int res=a*b;
		System.out.println("Product: "+res);
		
	}
	static void div(double a,double b){
		double res=a/b;
		System.out.println("Result of division:"+res);
		
	}
		
public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the first number");
int n1=s.nextInt();
System.out.println("Enter the second number");
int n2=s.nextInt();
add(n1,n2);
sub(n1,n2);
mult(n1,n2);
div(n1,n2);

	}

}
