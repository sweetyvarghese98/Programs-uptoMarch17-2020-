package com.cognizant.test1;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import java.util.Set;
class Validate{
	ArrayList<String> validateAge(HashMap<String,String> s) throws ParseException{
		ArrayList<String>r=new ArrayList<String>();
		Date today=new Date();
		SimpleDateFormat sdftoday=new SimpleDateFormat("yyyy");
		String today1=sdftoday.format(today);
		int t1=Integer.parseInt(today1);
		
		Set<Entry<String,String>> entries=s.entrySet();
		for(Entry<String,String> e:entries){
			String key=e.getKey();
			String values=e.getValue();
			
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
			Date valuesdate=sdf.parse(values);
			SimpleDateFormat sdf1=new SimpleDateFormat("yyyy");
			String t=sdf1.format(valuesdate);
			int f=Integer.parseInt(t);
			
			
			
			if(t1-f>18)
			{
				r.add(key);
			}
			
			
		
		}
		return r;
	}
}
public class VoterDemo {

public static void main(String[] args) throws ParseException {
	HashMap<String,String> t=new HashMap<String,String>();
	
	
	t.put("aruna","14/2/2004");
	t.put("lata","24/03/1987");
	
	Validate v=new Validate();
	ArrayList<String> s=new ArrayList<String>();
	s=v.validateAge(t);
	System.out.println("eligible candidates:");
	for(String e:s){
		System.out.println(e);
	}

}

}



