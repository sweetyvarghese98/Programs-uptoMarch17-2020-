package com.cognizant.test1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
class ProductSort{
	void sortArrayList(ArrayList<Product> alist)
	{
		Collections.sort(alist);
		System.out.println("sorting in ascending order");
		for(Product p:alist)
		{
			System.out.println(p);
		}
		
		
		
		Collections.sort(alist,Collections.reverseOrder());
		System.out.println("sorting in descending order");
		for(Product p:alist)
		{
			System.out.println(p);
		}
		
	
}
}
class Product implements Comparable<Product>{
	String productName;
	Date dateOfManufacture;
	Double price;
	Product(String productName,Date dateOfManufacture,Double price)
	{
		this.productName=productName;
		this.dateOfManufacture=dateOfManufacture;
		this.price=price;
	}
	
	
		
	
	public String toString(){
		return "name "+productName+" dateOfManufacture "+dateOfManufacture+" price "+price;
	}
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
	
	if(this.dateOfManufacture!=o.dateOfManufacture)
	{
		return this.dateOfManufacture.compareTo(o.dateOfManufacture);
	}
	else{
		return (int) (this.price-o.price);
	}
	}
	
	
	
}

public class ProductDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Product> alist=new ArrayList<Product>();
GregorianCalendar gc=new GregorianCalendar(2020,9,9);
Date d1=gc.getTime();
Product p1=new Product("TV",d1,30000.0);
gc=new GregorianCalendar(2020,9,10);
Date d2=gc.getTime();
Product p2=new Product("AC",d2,40000.0);
gc=new GregorianCalendar(2020,9,19);
Date d3=gc.getTime();
Product p3=new Product("FRIDGE",d3,50000.0);
gc=new GregorianCalendar(2020,9,10);
Date d4=gc.getTime();
Product p4=new Product("MICROWAVE",d4,20000.0);
alist.add(p1);
alist.add(p2);
alist.add(p3);
alist.add(p4);
System.out.println("Before sorting");
for(Product plist:alist)
{
	System.out.println(plist);
}

ProductSort p=new ProductSort();
p.sortArrayList(alist);



	}

}

