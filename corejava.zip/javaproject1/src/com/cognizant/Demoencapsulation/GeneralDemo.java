package com.cognizant.Demoencapsulation;
class Animal{
	int animalId=10;
	void createSound(){
		System.out.println("animal makes a sound");
	}
}
public class GeneralDemo {
	public static void main(String args[])
	{
		Animal a1=new Animal();
		System.out.println(a1.animalId);
		a1.createSound();//one object used twice
		a1.createSound();//one object
		
		new Animal().createSound();//separate object
		new Animal().createSound();//separate object
		System.out.println(new Animal().animalId);
		
	}

}
