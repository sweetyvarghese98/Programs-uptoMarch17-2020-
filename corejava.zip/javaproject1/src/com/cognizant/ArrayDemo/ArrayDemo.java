package com.cognizant.ArrayDemo;
//dollar to rupees
class Calculator{
	double []currencyConverter(double arr[])//passing arr as parameter andreturnng arr
	{
		for(int i=0;i<arr.length;i++){
			arr[i]=arr[i]*60;
		}
		return arr;
		}
	}

public class ArrayDemo {
	public static void main(String args[])
	{	double[] resultArray;
		Calculator c=new Calculator();
		resultArray=c.currencyConverter(new double[] {20,30,40,50,60,});
		for(double d:resultArray){
			System.out.println(d);
		
		}
	}

}
