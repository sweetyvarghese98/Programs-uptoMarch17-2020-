package com.cognizant.test2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
class StudentMedal{
	HashMap<Integer,String>getStudents(HashMap<Integer,Double>hm1)
	{	HashMap<Integer,String> hm2=new HashMap<Integer,String>();
		Set<Entry<Integer,Double>>entries=hm1.entrySet();
		ArrayList<Double>a=new ArrayList<Double>();
	for(Entry<Integer,Double>e:entries)
	{	
		Integer regno=e.getKey();
		Double  mark=e.getValue();
		//System.out.println(regno+" "+mark);
		a.add(mark);
		Iterator<Double>i= a.iterator();
		while(i.hasNext())
		{
			Double v=i.next();
			if(v>=90)
			{
				hm2.put(regno, "Gold");
			}
			else if(v>=80&&v<90)
			{
				hm2.put(regno, "silver");
			}
			else if(v>=70&&v<80){
				hm2.put(regno,"bronze");
			}
			
		}
		
	}
		return hm2;
		
	}
}
public class StudentMedalDemo {

	public static void main(String[] args) {
		HashMap<Integer,Double> hm1=new HashMap<Integer,Double>();
		hm1.put(100, 90.5);
		hm1.put(101,85.6);
		hm1.put(102,75.9);
		hm1.put(103,72.3);
		hm1.put(104,92.5);
		/*Set<Entry<Integer,Double>>entries=hm1.entrySet();
		for(Entry<Integer,Double>e:entries)
		{
			Integer regno=e.getKey();
			Double  mark=e.getValue();
			//System.out.println(regno+" "+mark);
		}*/
		StudentMedal sm=new StudentMedal();
		HashMap<Integer, String>res=sm.getStudents(hm1);
		Set<Entry<Integer,String>>entries=res.entrySet();
		for(Entry<Integer,String>e:entries)
		{
			Integer regno=e.getKey();
			String  medal=e.getValue();
			System.out.println(regno+" "+medal);
		}
		
	}

}
