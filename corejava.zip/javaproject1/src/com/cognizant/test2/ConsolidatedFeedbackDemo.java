package com.cognizant.test2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
class ConFeedback{
	ConcurrentHashMap<String,Integer>getConsolidateFeedback(ConcurrentHashMap<String,Integer>hme,ConcurrentHashMap<String,Integer>hmm){
		ConcurrentHashMap<String,Integer>hmresult=new ConcurrentHashMap<String,Integer>();
	
		//english entry set
		Set <Entry<String,Integer>> entries1=hme.entrySet();
		Set <Entry<String,Integer>> entries2=hmm.entrySet();
		
		for(Entry<String,Integer>e1:entries1){
		for(Entry<String,Integer>e2:entries2){
		
				
				if(e1.getKey().equals(e2.getKey()))
				{
					if(e1.getValue()>e2.getValue())
					{
					hmresult.put(e1.getKey(),e1.getValue());
					}
					else{
					hmresult.put(e2.getKey(),e2.getValue());
					hme.remove(e1.getKey());
					hmm.remove(e2.getKey());
					}
					
				}
				else
				{
					//hmresult.put(e1.getKey(), e1.getValue());
					hmresult.putAll(hmm);
					hmresult.putAll(hme);
				}
		}
		}
			
		return hmresult;
		
	}
}
public class ConsolidatedFeedbackDemo {
public static void main(String args[])
{
	ConcurrentHashMap<String,Integer>hme=new ConcurrentHashMap<String,Integer>();
	hme.put("sweety",10);
	hme.put("Anjaly",9);
	hme.put("Parvathy",10);
	hme.put("Jazeera",7);
	
	ConcurrentHashMap<String,Integer>hmm=new ConcurrentHashMap<String,Integer>();
	hmm.put("sweety",8);
	hmm.put("Megha",9);
	hmm.put("Parvathy",9);
	hmm.put("Pravitha",7);
	
	ConFeedback cf=new ConFeedback();
	ConcurrentHashMap<String,Integer>res=cf.getConsolidateFeedback(hme,hmm);
	Set<Entry<String,Integer>>entries=res.entrySet();
	for(Entry<String,Integer>e:entries)
	{
		String name=e.getKey();
		Integer  feedback=e.getValue();
		System.out.println(name+" "+feedback);
	}
	
	
}
}
