package com.cognizant.test2;

import java.util.Scanner;
class UserMainCode{
	static int validateDate(String str){
		int flag=0;
		String arr[]=str.split("/");
		if(arr[0].length()==2&&arr[1].length()==2&arr[2].length()==4)
		{
			flag=1;
		}
		return flag;
		
	}
}
public class ValidateDate4 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a date");
		String str=s.nextLine();
		int res=UserMainCode.validateDate(str);
		if(res==1)
		{
			System.out.println("Valid date format");
		}
		else
		{
			System.out.println("Invalid date format");
		}
		
		

	}

}
