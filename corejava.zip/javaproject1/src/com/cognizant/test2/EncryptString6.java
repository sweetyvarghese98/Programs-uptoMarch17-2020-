package com.cognizant.test2;

import java.util.Scanner;
class UserMainCode2{
	static String encrypt(String str){
	char ch[]=new char[str.length()];
	
	for(int i=0;i<str.length();i++)
	{	 
		if(i%2==0)
		{
			char ch1=str.charAt(i);
			if(ch1=='z')
			{
			ch1='a';
			}
			else if(ch1=='Z')
			{
				ch1='A';
			}
			else{
				ch1++;
		    }
			
			ch[i]=ch1;
		}
		
		else{
			ch[i]=str.charAt(i);
		}
	}
	String a=new String(ch);
	return a;
	
}
}
public class EncryptString6 {

	public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the string");
	String str=s.nextLine();
	String res=UserMainCode2.encrypt(str);
	System.out.println(res);

	}

}
