package com.cognizant.test2;

import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;
class FeedBack{
	HashMap<String,Integer> getConsolidatedFeedBack(HashMap<String, Integer> eng,HashMap<String, Integer> math){
		Set<Entry<String,Integer>>entries =eng.entrySet();
		Set<Entry<String,Integer>>entries1 =math.entrySet();
		HashMap<String,Integer> h1=new HashMap<String,Integer>();
		String keyeng=null,keymath;
		String valueeng,valuemath;
		for(Entry<String,Integer> e:entries){
			for(Entry<String,Integer> e1:entries1){
				if(e.getKey().equals(e1.getKey())){
					if(e1.getValue()>e.getValue()){
						h1.put(e1.getKey(),e1.getValue());
					}
					else{
						h1.put(e.getKey(),e.getValue());
					}
				}
				else{
					h1.put(e.getKey(),e.getValue());
					h1.put(e1.getKey(),e1.getValue());
				}
			}
			
			
		}
		return h1;
		
		
		
	}
}
public class ConsolidateFeed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String,Integer> eng=new HashMap<String,Integer>();
		HashMap<String,Integer> math=new HashMap<String,Integer>();
		HashMap<String,Integer> res=new HashMap<String,Integer>();
		eng.put("sweety",10);
		eng.put("Anjaly",9);
		eng.put("Parvathy",8);
		eng.put("Jazeera",7);
		math.put("sweety",8);
		math.put("Megha",9);
		math.put("Parvathy",9);
		math.put("Pravitha",7);
		FeedBack ff=new FeedBack();
		res=ff.getConsolidatedFeedBack(eng, math);
		Set<Entry<String,Integer>>entries =res.entrySet();
		for(Entry<String,Integer> e:entries){
			String key=e.getKey();
			Integer value=e.getValue();
			System.out.println(key+"  "+value);
		}
	}

}

