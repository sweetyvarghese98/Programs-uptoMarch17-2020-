package com.cognizant.test2;

public class ValidateTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
