package com.cognizant.test2;

import java.util.Scanner;
class UserMainCode1{
	static int validateTime(String str){
	int flag=0;
		String ar[]=str.split(":");
		int n1=Integer.parseInt(ar[0]);
		String br[]=ar[1].split(" ");
		int n2=Integer.parseInt(br[0]);
		if(((ar[0].length()==2)&&(n1<=12)&&(br[0].length()==2)&&(n2<=59))&&((br[1].equals("am"))||
				(br[1].equals("pm"))||(br[1].equals("AM"))||(br[1].equals("PM"))))
		{
			flag=1;
		}
		return flag;
		
	}
}
public class ValidateTime5 {

	public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter a time in hh:mm am or hh:mm:pm format");
	String str=s.nextLine();
	int res=UserMainCode1.validateTime(str);
	if(res==1)
	{
		System.out.println("valid time format");
	}
	else
	{
		System.out.println("Invalid time format");
	}
	}

}
