package com.cognizant.test2;

	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Scanner;
	class FetchElement{
	ArrayList<Integer>getElements(ArrayList<Integer>a1){
		ArrayList<Integer> result=new ArrayList<Integer>();
		result.add(a1.get(2));
		result.add(a1.get(6));
		result.add(a1.get(8));
		
		return result;
		
			
		}
	}


public class ArraySorting3 {
	
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
	Scanner s=new Scanner(System.in);
	System.out.print("Enter array of size 5");
	int a[]=new int[5];
	ArrayList<Integer> a1=new ArrayList<Integer>();

	for(int i=0;i<5;i++)
	{
		a[i]=s.nextInt();
		a1.add(a[i]);
		
	}
	//System.out.println(a1);

		
		
		System.out.print("Enter array of size 5");
		int b[]=new int[5];
		ArrayList<Integer> b1=new ArrayList<Integer>();

		for(int i=0;i<5;i++)
		{
			b[i]=s.nextInt();
			b1.add(b[i]);
			
		}
		//System.out.println(b1);
		a1.addAll(b1);
		Collections.sort(a1);
		FetchElement n=new FetchElement();
		ArrayList<Integer>res=n.getElements(a1);
		System.out.println("result");
		for(Integer v:res)
		{
			System.out.println(v);
		}
			}
		
		

	}
