package com.cognizant.demoEqual;
class Employee{
	int employeeId;
	String employeeName;
	Employee(int employeeId,String employeeName)
	{
		this.employeeId=employeeId;
		this.employeeName=employeeName;
		}
	public boolean equals(Object o)
	{
		Employee argument=(Employee)o;
		boolean result=false;
		if(this.employeeId==argument.employeeId&&
		   this.employeeName.equals(argument.employeeName))
		{
			result=true;
			}
		return result;
		}
	public int hashCode(){
		return this.employeeId;}}
public class DemoEqual {
public static void main(String args[])
{	//to compare objects
	Employee e1=new Employee(100,"sweety");
	Employee e2=new Employee(100,"sweety");
	System.out.println(e1.equals(e2));
	System.out.println(e2.equals(e1));
	System.out.println(e1.hashCode());
	System.out.println(e2.hashCode());
	
}
}
