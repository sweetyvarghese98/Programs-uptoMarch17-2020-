package com.cognizant.demoEqual;
class Product{
	int productId;
	String productName;
	double price;
Product(int productId,String productName,double price){
	this.productId=productId;
	this.productName=productName;
	this.price=price;}
public boolean equals(Object c)//overriding equals
{if(c==null){
	return false;}
	Product obj=(Product)c;
	boolean result=false;
	if(this.productId==obj.productId){
		result=true;}
	return result;}}
public class DemoProductEqual {
	public static void main(String args[]){
		Product p1=new Product(100,"abc",600);
		Product p2=new Product(101,"abc",600);
		Product p3=new Product(100,"abc",600);
		Employee e4=null;
		System.out.println(p1.equals(p2));
		System.out.println(p2.equals(p3));
		System.out.println(p1.equals(p3));
		System.out.println(e4);
		}}



