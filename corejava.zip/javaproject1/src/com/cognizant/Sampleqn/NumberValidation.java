package com.cognizant.Sampleqn;
import java.util.Scanner;
class UserMainCode1{
	static int validateNumber(String s1){
		int count=0;
		if(s1.charAt(3)=='-'&& s1.charAt(7)=='-')
		{
			count++;
			
		}
		if(count==1)
		{
			
			System.out.println("valid");
			return 1;
		}
		else
		{
			System.out.println("Invalid format");
			return -1;
		}
		
	}
	
		
		
	
}
public  class NumberValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a 10 digit number");
String s1=s.nextLine();
int res=UserMainCode1.validateNumber(s1);
System.out.println(res);
	}
}




