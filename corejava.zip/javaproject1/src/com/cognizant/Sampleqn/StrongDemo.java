package com.cognizant.Sampleqn;

import java.util.Scanner;

public class StrongDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a number");
int n=s.nextInt();
int temp=n;
int sum=0;
while(n!=0)
{	
	int d=n%10;
	int f=1;
	for(int i=1;i<=d;i++){
	f=f*i;
	}
	sum=sum+f;
	n=n/10;
	
}
if(sum==temp)
{
	System.out.println("Strong number:"+temp);
}
else
{
	System.out.println("Entered number is not a strong number");
}
	}

}
