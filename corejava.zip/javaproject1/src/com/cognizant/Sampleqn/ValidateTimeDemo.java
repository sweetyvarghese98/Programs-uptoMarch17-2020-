package com.cognizant.Sampleqn;

import java.util.Scanner;
class UserMainCode8{
int	validateTimePresent(String str)
	{	int flag=0;
		String arr[]=str.split(":");
		int n1=Integer.parseInt(arr[0]);
		//System.out.println(n1);
		
		
		String brr[]=arr[1].split(" ");
		int n2=Integer.parseInt(brr[0]);
		//System.out.println(n2);
		//System.out.println(brr[1]);
		if(((arr[0].length()==2)&&(n1<=12)&&(brr[0].length()==2)&&(n2<=59))&&((brr[1].equals("am"))||
				(brr[1].equals("pm"))||(brr[1].equals("AM"))||(brr[1].equals("PM"))))
		{
			flag=1;
			
		}
		
	
		return flag;
	}

	
}
public class ValidateTimeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the Time in hh:mm am or hh:mm pm");
String str=s.nextLine();
UserMainCode8 us=new UserMainCode8();
int res=us.validateTimePresent(str);
if(res==1){
	System.out.println("Valid time");
}
else{
	System.out.println("Invalid time");
}
	}

}
