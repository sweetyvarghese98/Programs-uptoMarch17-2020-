package com.cognizant.Sampleqn;

import java.util.Scanner;

class UserMainCode6{
	static String formNewWord(String str,int n){
	if(str.length()%2==0)
	{	String str1=str.substring(0,n);
		String str2=str.substring(str.length()-n,str.length());
		String str3=str1+str2;
		return str3;
	}else
	System.out.println("invalid");
	return str;
	
	
}
	
}
public class FormNewWord {

public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a string");
String str=s.nextLine();
System.out.println("Enter a number");
int n=s.nextInt();
String res=UserMainCode6.formNewWord(str, n);
System.out.println(res);

	}

}
