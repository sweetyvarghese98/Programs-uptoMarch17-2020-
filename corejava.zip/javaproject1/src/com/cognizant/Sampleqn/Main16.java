package com.cognizant.Sampleqn;

import java.util.Scanner;
class Position{
	void position(String[] array,String word,int limit){
		for(int i=0;i<limit;i++){
			for(int k=i+1;k<limit;k++){
				
				String temp;
				if(array[i].compareTo(array[k])>0){
					temp=array[i];
					array[i]=array[k];
					array[k]=temp;
				}
				
			}
			if(array[i].equals(word)){
				System.out.println(i);
			}
		}
	}
}
public class Main16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String[] array=new String[10];
		System.out.println("enter the limit:");
		int limit=s.nextInt();
		for(int i=0;i<limit;i++){
			array[i]=s.next();
			//System.out.println(array[i].indexOf(i));
		}
		//for(int i=0;i<limit;i++){
		//System.out.println(array[i]);
		//}
		System.out.println("enter the word:");
		String word=s.next();	
		Position p=new Position();
		p.position(array,word,limit);
	}

}

