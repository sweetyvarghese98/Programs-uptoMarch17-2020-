package com.cognizant.Sampleqn;

import java.util.Scanner;

public class StrongArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the array");
int a[]=new int[5];
int r[]=new int[5];
int i;
for(i=0;i<5;i++)
{
	a[i]=s.nextInt();
	r[i]=a[i];
}

for(i=0;i<5;i++)
{	int sum=0;
	while(a[i]!=0)
	{	
		int d=a[i]%10;
		int f=1;
		for(int j=1;j<=d;j++)
		{
			f=f*j;
		}
		sum=sum+f;
		a[i]=a[i]/10;
		
		
	}
	if (sum==r[i])
	{	//System.out.println("Strong numbers in array");
		System.out.println(r[i]);
	}
	
}



	}

}
