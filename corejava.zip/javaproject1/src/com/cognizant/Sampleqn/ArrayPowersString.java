package com.cognizant.Sampleqn;

import java.util.Scanner;
class UserMainCode11{
	
	static int []getSumPower(int a[])
	{	int a1[]=new int[a.length];
		for(int i=0;i<a.length;i++)
	{
		
	}
		return a;
		
	}
}
public class ArrayPowersString {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of elements in array");
		int n=s.nextInt();
		System.out.println("Enter the elements in array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=s.nextInt();
		}
		int res[]=new int[n];
		res=UserMainCode11.getSumPower(a);
	}

}
