package com.cognizant.Sampleqn;

import java.util.Scanner;

public class PalindromeArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter no. of elements of string");
		int n=s.nextInt();
		String str[]=new String[n];
		System.out.println("Enter a elements of string array");
		int i;
		
		for(i=0;i<n;i++)
		{
			str[i]=s.next();
		}
		
		int c = 0;
		for(i=0;i<str.length;i++){//str.length is to get length of str array
			int flag=0;
			
			for(int k=0, j=str[i].length()-1;k<str[i].length()/2;k++,j--)
			{	
				if(str[i].charAt(k)!=str[i].charAt(j)){
					flag=1;
					break;
				}
				
			}
			
			if(flag==0)
			{	c++;
				//System.out.println(str[i]);
				
			}
			
		}System.out.println(c);
		
		
		
		
	}

}
