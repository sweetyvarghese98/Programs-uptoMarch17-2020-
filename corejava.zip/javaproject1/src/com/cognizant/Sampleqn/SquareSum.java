package com.cognizant.Sampleqn;

import java.util.Scanner;
class UserMainCode2{
	static int sumOfSquaresOfEvenDigits(int n)
	{	int sum=0;
		while(n!=0)
		{
			int d=n%10;
			if(d%2==0)
			{
				sum=sum+d*d;
			}
			n=n/10;
		}
		return sum;
	}
}

public class SquareSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a number");
int n=s.nextInt();
int res=UserMainCode2.sumOfSquaresOfEvenDigits(n);
System.out.println(res);


	}

}
