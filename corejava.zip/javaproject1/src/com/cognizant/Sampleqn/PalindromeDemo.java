package com.cognizant.Sampleqn;

import java.util.Scanner;

public class PalindromeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a string");
String str=s.nextLine();
int length=str.length();
System.out.println("length of string:"+length);
String rev="";
for(int i=length-1;i>=0;i--)
{
	rev=rev+str.charAt(i);
}
if(rev.equals(str))
{
	System.out.println("Palindrome "+rev);
}
else{
	System.out.println("Not a palindrome");
}
	}

}
