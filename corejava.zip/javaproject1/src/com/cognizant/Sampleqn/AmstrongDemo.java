package com.cognizant.Sampleqn;

import java.util.Scanner;

public class AmstrongDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a number");
int n=s.nextInt();
int t=n;
int sum=0;
while(n!=0)
{	
	int d=n%10;
	sum=sum+(d*d*d);
	n=n/10;
}
if(sum==t){
	System.out.println("Number is amstrong");

	}
else{
	System.out.println("Not an amstrong");
}

}
}