package com.cognizant.Sampleqn;

import java.util.Scanner;
class UserMainCode9{
	int validatePassword(String str){
		int flag=0;
		if(str.length()>=6&&str.length()<20){
		for(int i=0;i<str.length();i++){
			
		if(str.charAt(i)=='@'||str.charAt(i)=='#'||str.charAt(i)== '$'||
			str.charAt(i)=='#'){
			flag++;
			break;
			
		}}
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)=='0'||str.charAt(i)=='1'||str.charAt(i)=='2'||str.charAt(i)=='3'||
					str.charAt(i)=='4'||str.charAt(i)=='5'||str.charAt(i)=='6'||str.charAt(i)=='7'||str.charAt(i)=='8'||str.charAt(i)=='9')
				{
				flag++;
				break;
				}}}
		if(flag==2)
		{
			return 1;
		}
		
		else
		{
			return -1;
		}
	
	}
}
	
public class PasswordValidationDemo {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=s.nextLine();
		UserMainCode9 us=new UserMainCode9();
		int res=us.validatePassword(str);
		if(res==1)
		{
			System.out.println("valid format");
		}
		else
		{
			System.out.println("invalid format");
		}
		

	}

}
