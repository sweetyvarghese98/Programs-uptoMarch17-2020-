package com.cognizant.Sampleqn;

import java.util.Scanner;
class UserMainCode3
{
	static String getMiddleChars(String str)
	{	
		int len=str.length();
		System.out.println("length of string "+len);
		String str2=str.substring((len/2-1),(len/2+1));
		return str2;
		
		
		
	}
}
public class FetchingMiddleChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a string of even length");
String str=s.nextLine();
String res=UserMainCode3.getMiddleChars(str);
System.out.println(res);

	}

}
