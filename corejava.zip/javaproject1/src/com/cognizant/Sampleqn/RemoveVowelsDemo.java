package com.cognizant.Sampleqn;

import java.util.Scanner;
class UserMainCode10{
	String removeEvenVowels(String str){
		char c[]=new char[str.length()];
		//char ch;
		int j=0,count=0;
		for(int i=0;i<str.length();i++)
		{
			if(i%2!=0)
			{
				//char ch=str.charAt(i);
				if(str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||
				str.charAt(i)=='o'||str.charAt(i)=='u'||str.charAt(i)=='A'||
				str.charAt(i)=='E'||str.charAt(i)=='I'||str.charAt(i)=='O'||str.charAt(i)=='U')
				{count++;
				//ch=str.charAt(i+1);
				}
				else{	
					c[j]=str.charAt(i);
					j++;
				}
				
			}
			else{	
				c[j]=str.charAt(i);
				j++;
			}
			
			
			
		}
		String a=new String(c);
		a=a.substring(0,str.length()-count);
		return a;
		
	}
}
public class RemoveVowelsDemo {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=s.nextLine();
		UserMainCode10 us=new UserMainCode10();
		String res=us.removeEvenVowels(str);
		System.out.println(res);
		
		

	}

}
