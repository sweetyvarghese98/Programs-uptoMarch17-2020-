package com.cognizant.Sampleqn;
import java.util.Scanner;
class UserMainCode{
	static int checkSum(int n){
		int sum=0;
		while(n!=0)
		{
			int d=n%10;
			sum=sum+d;
			n=n/10;
			
		}
		if(sum%2==0)
			{	
			System.out.println("Sum of odd digits is even");
			return 1;
			}
			else	
			{
			System.out.println("Sum of odd digits is odd");
			return -1;
			}
				
		}
		
		
	}

public class SumOddDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter any number");

int n=s.nextInt();
int res=UserMainCode.checkSum(n);
System.out.println(res);


	}

}
