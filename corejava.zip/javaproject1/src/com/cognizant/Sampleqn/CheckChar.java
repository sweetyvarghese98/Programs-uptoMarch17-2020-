package com.cognizant.Sampleqn;

import java.util.Scanner;
class UserMainCode4{
	static int checkCharacters(String str){
		 char str1=str.charAt(0);
		char str2=str.charAt(str.length()-1);
		if(str1==str2)
		{System.out.println("Valid");
			return 1;
			
		}
		else
			System.out.println("InValid");
		return -1;
		
		
	}
}
public class CheckChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a string");
String str=s.nextLine();
int res=UserMainCode4.checkCharacters(str);
System.out.println(res);



	}

}
