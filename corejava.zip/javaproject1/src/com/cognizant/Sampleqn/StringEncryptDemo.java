package com.cognizant.Sampleqn;

import java.util.Scanner;
class Encrypt{
	String stringEncrypt(String str){
		char ch[]=new char[str.length()];
		
		for(int i=0;i<str.length();i++)
		{	 
			if(i%2==0)
			{
				char ch1=str.charAt(i);
				if(ch1=='z')
				{
				ch1='a';
				}
				else if(ch1=='Z')
				{
					ch1='A';
				}
				else{
					ch1++;
			    }
				
				ch[i]=ch1;
			}
			
			else{
				ch[i]=str.charAt(i);
			}
		}
		String a=new String(ch);
		
		return a;
		
	}
}
public class StringEncryptDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a string");
String str=s.nextLine();
Encrypt e=new Encrypt();
String res=e.stringEncrypt(str);
System.out.println(res);



	}

}
