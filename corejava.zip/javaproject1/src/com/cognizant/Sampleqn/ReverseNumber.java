package com.cognizant.Sampleqn;
import java.util.Scanner;
class UserMainCode5{
	static int reverseNumber(int n)
	{	int rev=0;
		while(n!=0)
	{	
		int d=n%10;
		rev=rev*10+d;
		n=n/10;
		
	}
		return rev;
		
		
	}
}


public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a number");
int n=s.nextInt();
int res=UserMainCode5.reverseNumber(n);
System.out.println(res);
	}

}
