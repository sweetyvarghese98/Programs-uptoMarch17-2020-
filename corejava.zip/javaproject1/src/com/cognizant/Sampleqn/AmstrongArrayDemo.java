package com.cognizant.Sampleqn;
import java.util.Scanner;
public class AmstrongArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
int a[]=new int[5];
System.out.println("Enter an array");
int i;
int t;
int s1[]=new int[5];
for(i=0;i<5;i++)
{
	a[i]=s.nextInt();
	s1[i]=a[i];
}
for(i=0;i<5;i++){
int sum=0;
while(a[i]!=0)
{		
	int d=a[i]%10;
	sum=sum+(d*d*d);
	a[i]=a[i]/10;
}
	if(sum==s1[i])
	{
	System.out.println(s1[i]);
	

}
	}
	}
}

