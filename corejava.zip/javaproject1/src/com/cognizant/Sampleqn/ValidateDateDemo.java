package com.cognizant.Sampleqn;

import java.util.Scanner;

class UserMainCode7{
	int validateDate(String str){
		int flag=0;
		String arr[]=str.split("/");
		if(arr[0].length()!=2||arr[1].length()!=2||arr[2].length()!=4)
		{
			flag=1;
			
		}
		return flag;
		
		
	}
}
public class ValidateDateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the date");
String date=s.next();
UserMainCode7 us=new UserMainCode7();
int res=us.validateDate(date);
if(res==1)
{
	System.out.println("Invalid date format");
}
else{
	System.out.println("valid date format");
}

	}

}
