package com.cognizant.p2;

import com.cognizant.p1.MyClass;

public class DiffClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
MyClass m=new MyClass();
System.out.println(m.a);
m.display();
	}

}
