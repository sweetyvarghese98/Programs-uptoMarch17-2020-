package com.cognizant.p2;

import com.cognizant.p1.MyClass;

public class SubDiffpackage extends MyClass{

	public static void main(String[] args) {
		SubDiffpackage s=new SubDiffpackage();
		System.out.println(s.a);
		s.display();

	}

}
