package com.example.tax;

public class Primeno {
	public static void main(String args[])
	{	int i,j;
	System.out.println("Primenos from 1 to 150 are:");
		for(i=1;i<=150;i++)
		{int count=0;
			for(j=1;j<=i;j++)
			{
				if(i%j==0)
				{
					count=count+1;
					
				}
				
			}
			if(count==2){
			
				System.out.print(i+",");
		}
	}

}
}