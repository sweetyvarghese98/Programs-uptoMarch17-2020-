package com.example.tax;

public class Circle {
	int sideLength;
	

	void calculateArea(){
		double Area=(3.14)*sideLength*sideLength;
		System.out.println("Area of the circle is"+Area);

}
}
