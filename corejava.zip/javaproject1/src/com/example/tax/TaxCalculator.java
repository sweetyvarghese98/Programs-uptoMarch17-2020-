package com.example.tax;

public class TaxCalculator {
	float basicSalary;
	boolean citizenship;
	float tax;
	int netSalary;
	void calculateTax()
	{
		tax=(30*basicSalary)/100;
		System.out.println("The tax of the employee for the"+basicSalary+"is: "+tax);
	}
	void deductTax()
	{
		netSalary=(int)basicSalary-(int)tax;
		System.out.println("The net salary of the employee: "+netSalary);
		
	}
	void validateSalary()
	{
		if((basicSalary>100000)&&(citizenship))
		{
		System.out.println("The salary and citizenship eligibility true");
		}
		else
		{
		System.out.println("The salary and citizenship eligibility false");
		}
	}
	

}
