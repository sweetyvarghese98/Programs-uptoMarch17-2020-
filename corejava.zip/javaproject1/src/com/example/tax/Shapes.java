package com.example.tax;
public class Shapes {
int numberOfSides,sideLength;
void calculateShapeArea(int numberOfSides,int Length)
{
	if(numberOfSides==1)
	{
		Circle c=new Circle();
		c.sideLength=Length;
		c.calculateArea();
	}
	else if(numberOfSides==4)
	{
		Square s=new Square();
		s.sideLength=Length;
		s.calculateArea();
	}
	else if(numberOfSides==3)
	{
		Triangle t=new Triangle();
		t.sideLength=Length;
		t.calculateArea();}
	else
	{System.out.println("No shapes Present");
	}}
public static void main(String args[])
{	Shapes m=new Shapes();
	m.calculateShapeArea(3,12);}}
