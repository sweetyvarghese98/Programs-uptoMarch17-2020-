package com.example.tax;

public class EmployeeTax {
	public static void main(String args[]){
	

		TaxCalculator m=new TaxCalculator();
		m.basicSalary=125000;
		m.citizenship=true;
		m.calculateTax();
		m.deductTax();
		m.validateSalary();
	}

}
