package com.example.tax;

public class Triangle {
	int sideLength;
	void calculateArea()
	{
		double Area=(sideLength*sideLength)*1.732/4;
		System.out.println("The area of the Triangle "+Area);
		
	}

}
