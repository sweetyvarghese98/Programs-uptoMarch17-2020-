package com.example.tax;

public class Shapess {
	int numberOfSides,sideLength;
	void calculateShapeArea(int numberOfSides,int Length)
	{
		switch(numberOfSides){
		case 1:
			Circle c=new Circle();
			c.sideLength=Length;
			c.calculateArea();
			break;

			case 2:
			Square s=new Square();
			s.sideLength=Length;
			s.calculateArea();
			break;
		
			case 3:
		
			Triangle t=new Triangle();
			t.sideLength=Length;
			t.calculateArea();
			break;
		default:
		System.out.println("No shapes Present");
		}}
	public static void main(String args[])
	{	Shapes m=new Shapes();
		m.calculateShapeArea(4,12);}


}
