package com.example.tax;

public class Square {
	int sideLength;
	void calculateArea(){
		double Area=sideLength*sideLength;
		System.out.println("The area of square is "+Area);
		
	}

}
