class Student2{
	int studentId;
	String studentName;
	int marksArray[]={20,20,20,20,20};
	Student2(int studentId,String studentName)
	{
		this.studentId=studentId;
		this.studentName=studentName;
	
	}
}
class Calculator{
	void calculateMark(Student2 s){
		double averageMarks=(s.marksArray[1]+s.marksArray[2]+s.marksArray[3]+s.marksArray[4]+s.marksArray[0])/5;
		System.out.println("Average mark of"+s.studentId+" "+s.studentName+" "+averageMarks);
	
	}
}
public class StudentMarks {
	public static void main(String args[])
	{
		Student2 s1=new Student2(100,"sweety");
		Calculator ref=new Calculator();
		ref.calculateMark(s1);
	}

}
