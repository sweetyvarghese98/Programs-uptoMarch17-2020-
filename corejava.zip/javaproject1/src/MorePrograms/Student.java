
class Student {
	int studentId;
	String StudetName;
}
