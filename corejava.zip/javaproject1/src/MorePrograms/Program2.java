import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

class Feedback{
	ConcurrentHashMap<String,Integer> getConsolidateFeedback(ConcurrentHashMap<String,Integer> englishFeedback,ConcurrentHashMap<String,Integer> mathsFeedback){
		ConcurrentHashMap<String,Integer> consolidatedFeedback=new ConcurrentHashMap<String,Integer>();
		
		Set<Entry<String,Integer>> en=englishFeedback.entrySet();
		for(Entry<String,Integer> e1:en){
			String name=(String) e1.getKey();
			int fb=(Integer) e1.getValue();
			if(mathsFeedback.containsKey(name)){
				if(fb>mathsFeedback.get(name)){
					consolidatedFeedback.put(name, fb);
					
				}
				else
					consolidatedFeedback.put(name,mathsFeedback.get(name));
				mathsFeedback.remove(name);	
				englishFeedback.remove(name);
			}
				
		}
		//englishFeedback.replaceAll(consolidatedFeedback);
		consolidatedFeedback.putAll(englishFeedback);
		consolidatedFeedback.putAll(mathsFeedback);
		return consolidatedFeedback;
	}
}
public class Program2 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.print("Enter number of English teachers: ");
		int en=s.nextInt();
		System.out.print("Enter number of Maths teachers: ");
		int ma=s.nextInt();
		ConcurrentHashMap<String,Integer> englishFeedback=new ConcurrentHashMap<String,Integer>();
		ConcurrentHashMap<String,Integer> mathsFeedback=new ConcurrentHashMap<String,Integer>();
		System.out.println("English Feedback ");
		for(int i=0;i<en;i++){
			System.out.print("Enter teacher's name: ");
			String name=s.next();
			System.out.print("Enter Feedback: ");
			int fb=s.nextInt();
			englishFeedback.put(name,fb);
			
		}
		System.out.println("Maths Feedback ");
		for(int i=0;i<ma;i++){
			System.out.print("Enter teacher's name: ");
			String name=s.next();
			System.out.print("Enter Feedback: ");
			int fb=s.nextInt();
			mathsFeedback.put(name,fb);
			
		}
		Feedback f=new Feedback();
		ConcurrentHashMap<String,Integer> consolidatedFeedback=f.getConsolidateFeedback(englishFeedback, mathsFeedback);
		System.out.println(consolidatedFeedback);
	}
}
