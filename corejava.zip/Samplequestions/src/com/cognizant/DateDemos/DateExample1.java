package com.cognizant.DateDemos;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateExample1 {

	public static void main(String[] args) {
		//to create a date object
		Date today=new Date();//Date format,automatic customization
		Date d1=new Date();
		System.out.println(today.toString());
		System.out.println(today);
		System.out.println(d1);
		
		
		
		//to display any other date
		//choice1
		
		Calendar calender=Calendar.getInstance();
		calender.set(calender.YEAR,2020);
		calender.set(calender.MONTH,0);
		calender.set(calender.DATE,29);
		Date d=calender.getTime();
		System.out.println(d);//output 
		System.out.println(d.toString());
		
		//choice2
		
		GregorianCalendar gc=new GregorianCalendar(1998,2,11);//year,month,date format
		Date anyOtherDate=gc.getTime();
		System.out.println(anyOtherDate);//anyotherdate is a variable//output will have zero time
		
	}

}
