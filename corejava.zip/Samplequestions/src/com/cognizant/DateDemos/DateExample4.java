package com.cognizant.DateDemos;

import java.util.Date;
import java.util.GregorianCalendar;

public class DateExample4 {

	public static void main(String[] args) {
		Date newdate=new Date();//today
		GregorianCalendar gc=new GregorianCalendar(2020,01,04);
		Date olddate=gc.getTime();
		System.out.println(newdate.after(olddate));//true since todays date comes after old date
		System.out.println(olddate.after(newdate));
		
		System.out.println(newdate.compareTo(olddate));// 1 if todays date after old date given
		System.out.println(olddate.compareTo(newdate));
		System.out.println(newdate.compareTo(newdate));
		
		System.out.println(newdate.equals(olddate));
		System.out.println(olddate.equals(olddate));//true

	}

}
