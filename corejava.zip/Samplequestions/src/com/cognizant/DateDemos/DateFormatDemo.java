package com.cognizant.DateDemos;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class DateFormatDemo {

	public static void main(String[] args) {
		//Date format
		Date today=new Date();
		DateFormat df1=DateFormat.getDateInstance(DateFormat.FULL,Locale.UK);
		DateFormat df2=DateFormat.getDateInstance(DateFormat.MEDIUM,Locale.UK);
		DateFormat df3=DateFormat.getDateInstance(DateFormat.SHORT,Locale.UK);
		DateFormat df4=DateFormat.getDateInstance(DateFormat.LONG,Locale.UK);
		String formatted_uk_full=df1.format(today);
		String formatted_uk_medium=df2.format(today);
		String formatted_uk_short=df3.format(today);
		String formatted_uk_long=df4.format(today);
		System.out.println(formatted_uk_full);
		System.out.println(formatted_uk_medium);
		System.out.println(formatted_uk_short);
		System.out.println(formatted_uk_long);
		//converting to date
		Date d2=null;
		try {
			d2=df1.parse(formatted_uk_full);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println();
		System.out.println();
		
		DateFormat df5=DateFormat.getDateInstance(DateFormat.FULL,Locale.FRENCH);
		DateFormat df6=DateFormat.getDateInstance(DateFormat.MEDIUM,Locale.FRENCH);
		DateFormat df7=DateFormat.getDateInstance(DateFormat.SHORT,Locale.FRENCH);
		DateFormat df8=DateFormat.getDateInstance(DateFormat.LONG,Locale.FRENCH);
		String formatted_french_full=df5.format(today);
		String formatted_french_medium=df6.format(today);
		String formatted_french_short=df7.format(today);
		String formatted_french_long=df8.format(today);
		System.out.println(formatted_french_full);
		System.out.println(formatted_french_medium);
		System.out.println(formatted_french_short);
		System.out.println(formatted_french_long);
	}

}
