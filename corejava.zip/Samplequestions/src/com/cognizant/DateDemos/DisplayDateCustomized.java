package com.cognizant.DateDemos;

import java.text.SimpleDateFormat;
import java.util.Date;
//customized by us
public class DisplayDateCustomized {

	public static void main(String[] args) {
		Date d=new Date();
		//(System.out.println(d);//todays date in dateformat)
		SimpleDateFormat sdf=new SimpleDateFormat("z yyyy-MM-dd");
		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MMM-dd");
		SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MMMMM-dd");
		SimpleDateFormat sdf3=new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		String Result=sdf.format(d);
		String Result1=sdf1.format(d);
		String Result2=sdf2.format(d);
		System.out.println(Result);
		System.out.println(Result1);
		System.out.println(Result2);
		

	}

}
