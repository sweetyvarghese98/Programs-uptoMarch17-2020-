package com.cognizant.DateDemos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateExample5 {
//string is inp and date is output
	public static void main(String[] args) {
		String myDateString="2020-03-15";//format given here should b equal to when converting to string ie yyyy-MM-dd
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date date=null;
		
		try {
			date=sdf.parse(myDateString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("String converted into date  " + date);

	}

}
