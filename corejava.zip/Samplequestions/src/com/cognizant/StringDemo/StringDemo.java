package com.cognizant.StringDemo;

public class StringDemo {
	public static void main(String args[])
	{
		
		String s3=new String("square");
		byte b[]={'a','b','c'};
		String s4=new String(b);
		System.out.println(s4);
		//function charAt()
		System.out.println(s3.charAt(0));
		System.out.println(s3.charAt(1));
		System.out.println(s3.charAt(2));
		System.out.println(s3.charAt(3));
		System.out.println(s3.charAt(4));
		// string toCharArray
		char[] charArray=s3.toCharArray();
		for(int i=0;i<charArray.length;i++)
		{
			System.out.println(charArray[i]);
		}
		String s1=new String("square");
		String s2=new String("apple");
		//abcdefghijklmnopqrstuvwxyz
		System.out.println(s1.compareTo(s2));
		System.out.println(s2.compareTo(s1));
		System.out.println("APPLE".compareTo("apple"));
		System.out.println("APPLE".compareTo("boy"));//no consideration for cap or small
		//concat
		String s5="super";
		String s6="man";
		//s1+s2 without assignment give compile time error
		String s7=s1+s2;
		System.out.println(s7);
		//System.out.println(s.concat( String s6));
		//contains
		
		

}
}