package com.cognizant.StringDemo;

public class SplitDemo {

	public static void main(String[] args) {
		String s1="Bring me a world map";
		String arr[]=s1.split(" ");//words in a sentence is splitted
									//here space is delimiter
		for(String s:arr)
		{
			System.out.println(s);
		}
		String s2="29/01/2020";
		arr=s2.split("/");//here / is delimiter
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		/* or for(String s:arr)
		{
			System.out.println(s);
		}*/
		
		String s3="aaa'bbb'ccc";
		arr=s3.split("'");//here delimiter is '
		for(String ss:arr)
		System.out.println(ss);
		//substring extract particular part of string
		String s4="IndiaRussiaChina";
		String s5=s4.substring(5,11);
		System.out.println(s5);
		String s6="   abcd   ";
		System.out.println(s6.length());//10
		String s7=s6.trim();
		System.out.println(s7.length());//4

	}

}
