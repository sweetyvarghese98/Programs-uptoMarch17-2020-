package com.cognizant.StringDemo;

public class StringDemo2 {
//anything can b converted to string
	public static void main(String[] args) {
		//primitive to string using valueOf
		//int to String
		int a=5,b=66;
		String s1=String.valueOf(a);//a converted to string s1
		String s2=String.valueOf(b);//b converted to string s2
		
		System.out.println(a+b);//addition
		System.out.println(s1+s2);//concatenation
		
		//boolean to string
		String s3=String.valueOf(true);
		System.out.println(s3);//it means "true"
		
		//float to string
		System.out.println(String.valueOf(33.3f));//"33.3"
		
		
	}

}
