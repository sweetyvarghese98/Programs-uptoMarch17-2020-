package com.cognizant.StringDemo;

public class StringDemo1 {

	public static void main(String[] args) {
		String s1="squareonthehypotenuseq";
		boolean b=s1.contains("hypo");
		System.out.println(b);//true
		System.out.println(s1.endsWith("use"));//true
		
		String s2="squareonthehypotenuse";
		System.out.println(s1.equals(s2));
		
		String s3=s2.toUpperCase();
		System.out.println(s3);
		
		System.out.println(s1.equalsIgnoreCase(s3));//true
		System.out.println(s1.indexOf('q',2));//looks from 2nd index,if last q is not there ans -1
		System.out.println(s1.indexOf("hypo"));
		//s1="";
		System.out.println(s1.isEmpty());
		System.out.println(s1.lastIndexOf('q'));
		System.out.println(s1.lastIndexOf('e'));
		String s4="jack";
		String s5=s4.replace('j','b');
		System.out.println(s4);//jack
		System.out.println(s5);//back

	}

}
