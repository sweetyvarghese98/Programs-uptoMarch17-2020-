package com.cognizant.ThredsDemo;
class ComputeSquares implements Runnable{
	//public void run()//mixed thread output
	public synchronized void run(){
		for(int i=1;i<=10;i++)
		{
			String name=Thread.currentThread().getName();
			System.out.println(name+" "+i*i);
		}
	}
}
public class ThreadDemo {
	public static void main(String args[])
	{
		ComputeSquares r=new ComputeSquares();
		
		Thread t1=new Thread(r);
		t1.setName("SquareThread-1");
		t1.start();
		//ComputeSquares r1=new ComputeSquares(); if used this mixed
		Thread t2=new Thread(r);
		t2.setName("SquareThread-2");
		t2.start();
	}

}
