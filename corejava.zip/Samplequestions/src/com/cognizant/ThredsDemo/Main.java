package com.cognizant.ThredsDemo;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Thread thread=Thread.currentThread();
String name=thread.getName();
System.out.println("Name of the thread that executes main method:: "+name);
System.out.println(Thread.currentThread().getName());//to get thred name easily
	}

}
