package com.cognizant.ThredsDemo;
class MyClass1 extends Thread
{//synchronized is not working
	public void run()
	{
		String name=Thread.currentThread().getName();
		for(int i=0;i<100;i++)
		{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println(name+" "+i*i);
		}
	}
}
public class ThreadDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass1 t1=new MyClass1();
		t1.setDaemon(true);//to convert userthread to daemon thread
		t1.start();
		t1.setName("firstThread");
		
MyClass1 t2=new MyClass1();
t2.start();
t2.setName("secondThread");
MyClass1 t3=new MyClass1();
t3.start();
t3.setName("ThirdThread");

	}

}
