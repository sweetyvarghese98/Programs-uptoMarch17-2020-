package com.cognizant.ThredsDemo;
class MyClass extends Thread
{
	public void run()
	{
		String name=Thread.currentThread().getName();
		for(int i=0;i<100;i++)
		{
			System.out.println(name+" "+i+i);
		}
	}
}
public class ThreadDemo2 {

	public static void main(String[] args) {
		MyClass t1=new MyClass();
				t1.setDaemon(true);//to convert userthread to daemon thread
				t1.start();
				t1.setName("firstThread");
		MyClass t2=new MyClass();
		t2.start();
		t2.setName("secondThread");
		MyClass t3=new MyClass();
		t3.start();
		t3.setName("ThirdThread");
		
	}

}
