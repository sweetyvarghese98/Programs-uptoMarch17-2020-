package com.cognizant.exDemo;
class DemoClass{
	void methodA() throws Exception{
	System.out.println("method invoked");
	throw new Exception();//throwing an exception..here throw 
	//above throw should b declared
	
}
	
	}

public class Ex7 {

	public static void main(String[] args) {
		DemoClass d=new DemoClass();
		
		try {
			d.methodA();
			}
		catch (Exception e)
		{
			System.out.println("Exception occured but handled");
			e.printStackTrace();
		}
	}

}
