package com.cognizant.exDemo;
//Ex5 with exception
public class Ex6 {
static int doActualCalculation(int a,int b)
{
	System.out.println("Actual method performs calculation");
	int res=a/b;
	return res;
}
static int calculate(int x,int y)
{
	System.out.println("Calculate method invoked");
	int res=doActualCalculation(x,y);
	return res;
}
	public static void main(String[] args) {
		int a=50,b=0;
		System.out.println("Main is invoked");
		int res=calculate(a,b);
		System.out.println("Result is: "+res);
		System.out.println("Program ends");
		
	}

}
