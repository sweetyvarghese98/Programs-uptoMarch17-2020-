package com.cognizant.exDemo;

public class AgeInvalidException extends Exception {
	AgeInvalidException(String exceptionMessage){
		super(exceptionMessage);
		
	}

}


