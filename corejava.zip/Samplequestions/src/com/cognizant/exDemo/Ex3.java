package com.cognizant.exDemo;

import java.io.File;

public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File f=new File();


	}

}
