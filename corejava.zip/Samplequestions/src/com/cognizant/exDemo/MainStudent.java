package com.cognizant.exDemo;

public class MainStudent {
public static void main(String args[])
{	boolean res=false;
	Student student=new Student("SWEETY",16,true);
	StudentInfoValidator v=new StudentInfoValidator();
	try {
		res=v.validateStudentDetails(student);
	} catch (AgeInvalidException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (CitizenInvalidException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	if(res==true)
	{
		System.out.println("Elibile to apply for loan");
	}
	else
	{
		System.out.println("Not eligible to apply for loan");
	}
	
}
}
