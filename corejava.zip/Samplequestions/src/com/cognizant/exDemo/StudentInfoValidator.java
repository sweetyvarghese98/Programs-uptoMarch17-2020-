package com.cognizant.exDemo;

public class StudentInfoValidator{
	boolean validateStudentDetails(Student student)  throws AgeInvalidException,CitizenInvalidException
	{	boolean result=false;
		if(student.getAge()<18)
		{
			throw new AgeInvalidException("Age Should be above 18");
		}
		else if(student.getIsCitizen()==false)
		{
			throw new CitizenInvalidException("Citizenship is not valid");
		}
		else{
			result=true;
			return result;
		}
	}

}
