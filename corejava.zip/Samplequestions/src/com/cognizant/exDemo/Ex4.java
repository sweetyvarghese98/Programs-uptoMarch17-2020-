package com.cognizant.exDemo;

public class Ex4 {

	public static void main(String[] args) {
		int myArray[]=new int[2];

		try{
			
		System.out.println(1);
		
		//System.out.println(2/0);
		System.out.println(myArray[3]);
		System.out.println(6);

			}
		/*catch(Exception e)//=> compile time error because exception is superclass of
		 * Arithmetic and ArrayIndexException
		{	e.printStackTrace();
			
		}*/
		catch(ArithmeticException ae)
		{
			System.out.println("Exception has occured:-1");
			//System.out.println(ae.getMessage());
			ae.printStackTrace();////print exception message
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println("Exception has occured:-2");
			//System.out.println(aie.getMessage());
			aie.printStackTrace();////print exception message
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		finally{
			System.out.println("finallyblock executed");
		}


	}

}
