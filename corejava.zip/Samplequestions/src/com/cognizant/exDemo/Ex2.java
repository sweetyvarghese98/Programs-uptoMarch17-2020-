package com.cognizant.exDemo;
//with try catch//unchecked exception compiler will not check
public class Ex2 {

	public static void main(String[] args) {
	int myArray[]=new int[2];

	try{
		
	System.out.println(1);
	System.out.println(myArray[3]);
	//System.out.println(2/0);//exception occures and goes to catch block which prevent 
	//abrupt halting of program 
	System.out.println(6);

		}
	catch(Exception e)
	{
		System.out.println("Exception has occured");
		//System.out.println(e.getMessage());
		e.printStackTrace();//give more details abt exception
	}

}
}


