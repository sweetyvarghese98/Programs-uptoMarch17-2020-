package com.cognizant.exDemo;

public class CitizenInvalidException extends Exception {
	
		CitizenInvalidException(String exceptionMessage){
			super(exceptionMessage);
		
		}
}
