package com.cognizant.exDemo;
//without exception
public class Ex5 {
	static int doActualCalculation(int a,int b)
	{
		System.out.println("Actual method performs calculation");
		int result=a/b;
		return result;
	}
	static int calculate(int x,int y){
		System.out.println("Calculate method");
		int result=doActualCalculation(x,y);
		return result;
	}

	public static void main(String[] args) {
		int a=50,b=5;
		int result=calculate(a,b);
		System.out.println("Result is:-  "+result);

	}

}
