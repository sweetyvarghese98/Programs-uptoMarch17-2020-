package com.cognizant.exDemo;

public class Student {
	String name;
	int age;
	boolean isCitizen;


public Student(String name,int age,boolean isCitizen)
{
	this.name=name;
	this.age=age;
	this.isCitizen=isCitizen;
}
public  String getName()
{
	return this.name;
}
public  int getAge()
{
	return this.age;
}
public  boolean getIsCitizen()
{
	return this.isCitizen;
}
}