package com.cognizant.task;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
class MyClass5
{
	HashMap<String,String>displayMap(String stateArray[])
	{HashMap<String,String> h=new HashMap<String,String>();
		for(int i=0;i<5;i++)
		{
			String key1=stateArray[i].substring(0,3);
			key1=key1.toUpperCase();
			h.put(key1, stateArray[i]);
			
		}
		return h;
		
	}
}
public class StringHahMapReturn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter 5 states");
		int i;
		String []stateArray=new String[5];
		for(i=0;i<5;i++)
		{
			stateArray[i]=s.nextLine();
			
		}
		
		MyClass5 mc=new MyClass5();
		HashMap h=mc.displayMap(stateArray);
		Set<Entry<String,String>> entry=h.entrySet();
		for(Entry<String,String> e:entry)
		{
			String key=e.getKey();
			String value=e.getValue();
			System.out.println(key +" "+value);
		}
		
		
	}

}
