package com.cognizant.task;

import java.util.Scanner;
class Usermaincode39{
	static String swapCharacter(String s1)
	{	StringBuffer sb=new StringBuffer();
		if(s1.length()%2==0)
	{
		for(int i=0;i<s1.length()-1;i=i+2)
		{
			char a=s1.charAt(i);
			char b=s1.charAt(i+1);
			sb.append(b).append(a);
		}
		return sb.toString();
	}	
		else
		{
			for(int i=0;i<s1.length()-2;i=i+2)
			{
				char a=s1.charAt(i);
				char b=s1.charAt(i+1);
				sb.append(b).append(a);
			}
			sb.append(s1.charAt(s1.length()-1));
			{
				return sb.toString();
			}
			
		}
		
		
		
		
	}
}
public class Main39 {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter a string");
	String s1=s.nextLine();
	String res=Usermaincode39.swapCharacter(s1);
	System.out.println(res);
	
}
}
