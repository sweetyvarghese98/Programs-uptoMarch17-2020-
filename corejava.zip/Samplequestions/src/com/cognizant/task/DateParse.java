package com.cognizant.task;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateParse {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
String mydate="20-03-2020";
SimpleDateFormat sd=new SimpleDateFormat("dd-MM-yyyy");
Date d=null;
d=sd.parse(mydate);
System.out.println("String converted into date  " + d);
	}
	
}
