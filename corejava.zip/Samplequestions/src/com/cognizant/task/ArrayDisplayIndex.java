package com.cognizant.task;

import java.util.Scanner;

public class ArrayDisplayIndex {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter length of array");
		int n=s.nextInt();
		int a[]=new int[n];
		System.out.print("Enter elements in array");
		int i;
		for( i=0;i<n;i++)
		{
			a[i]=s.nextInt();
		}
		System.out.print("Enter an element in array");
		int e=s.nextInt();
		int flag=0;
		for(i=0;i<n;i++)
		{
			if(a[i]==e)
			{
				System.out.println("entered number is in index: "+i);
				flag=1;
			}
		}
			if(flag==0){
				System.out.println("entered no. is not in array");
			}
		
			
		
	}

}
