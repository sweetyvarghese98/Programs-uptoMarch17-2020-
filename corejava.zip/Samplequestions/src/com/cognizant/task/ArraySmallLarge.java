package com.cognizant.task;

import java.util.Scanner;

public class ArraySmallLarge {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter length of array");
		int n=s.nextInt();
		int a[]=new int[n];
		System.out.print("Enter elements in array");
		int i;
		for( i=0;i<n;i++)
		{
			a[i]=s.nextInt();
		}
		int small=a[0];
		int large=a[0];
		for(i=1;i<n;i++)
		{
			if(a[i]<small)
			{
				small=a[i];
			}
			if(a[i]>large)
			{
				large=a[i];
			}
		}
		System.out.println("small number "+small);
		System.out.println("large number "+large);
		

	}

}
