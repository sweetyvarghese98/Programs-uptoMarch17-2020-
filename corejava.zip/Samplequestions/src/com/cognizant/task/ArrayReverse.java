package com.cognizant.task;
import java.util.*;
class Evaluator{
	
	int[] reverseArray(int a[],int length)
	{int i=0;
	int[]arr=new int[length];
	
	while(i<length)
	{int n=a[i];
	int rev=0;
		while(n>0)
			{
			int num=n%10;
			rev=(rev*10)+num;
			n=n/10;
			
			}
		
arr[i]=rev;
i++;
		
		
	}
	return arr  ;
}
}
public class ArrayReverse {
	public static void main(String args[])
	{	Scanner s=new Scanner(System.in);
	
		System.out.println("Enter the length of array");
		int length=s.nextInt();
		int []a=new int[length];
		System.out.println("Enter the elements of array");
		for(int i=0;i<length;i++)
		{
		 a[i]=s.nextInt();
		}
		Evaluator e=new Evaluator();
		int []resultarr=e.reverseArray(a,length);
		for(int d:resultarr)
		{
			System.out.println(d);
		}
		
	}
}
	


