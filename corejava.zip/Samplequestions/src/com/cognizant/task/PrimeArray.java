package com.cognizant.task;
import java.util.*;
class ArrayPrime
{
  int  add(int arr[]){
      int sum=0;
  
    for(int i=2;i<12;i++)
    {   int count=0;
        for(int j=2;j<i;j++)
        {
            if(i%j==0)
            {
                count=1;
                break;
            }
            
        }
        if(count==0)
        {
            sum=sum+arr[i];
        }
    
}
    return sum;
  }
}
public class PrimeArray {
	 public static void main(String args[])
	    {
	        Scanner s=new Scanner(System.in);
	        System.out.println("Enter array elements");
	        int arr[]=new int[12];
	        for(int i=0;i<arr.length;i++)
	        {
	            arr[i]=s.nextInt();
	        }
	        ArrayPrime ap=new ArrayPrime();
	        int sum=ap.add(arr);
	        System.out.println(sum);
	        
	    }
	    
	}


