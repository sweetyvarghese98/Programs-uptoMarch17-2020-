package com.cognizant.task;

import java.util.Scanner;
class Usermaincode36{
	static String nameFormatter(String s1)
	{	String arr[]=s1.split(" ");
		String s2=arr[0].substring(0,1);
		String s3=arr[1].concat(",");
		String s4=s3.concat(s2);
		return s4;
		
	}
}
public class Main36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the name");
String s1=s.nextLine();
String res=Usermaincode36.nameFormatter(s1);
System.out.println(res);

	}

}
