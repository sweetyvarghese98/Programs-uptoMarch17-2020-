package com.cognizant.task;
import java.util.*;
class ArrayPrime1{
    int[] showArrayPrime(int l){
        int arr[]=new int[l];
        int i=2,k=0;
        while(l>0){
            int c=0;
            for(int j=2;j<i;j++){
                if(i%j==0){
                    c=1;
                    break;
                }
                    
            }
            if(c==0){
                arr[k]=i;
                l--;
                k++;
            }
            i++;
            
        }
        return arr;
    }
}
public class PrimeInput {

	 public static void main(String args[]){
	        Scanner s=new Scanner(System.in);
	        System.out.println("Enter size");
	        int l=s.nextInt();
	        int arr[]=new int[l];
	        ArrayPrime1 ap1=new ArrayPrime1();
	        arr=ap1.showArrayPrime(l);
	        System.out.println("Prime numbers:");
	        for(int i=0;i<l;i++){
	            System.out.println(arr[i]);
	        }
	        
	                
	    }
	}
