package com.cognizant.task;

import java.util.Scanner;

public class ArrayCopy {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter length of array");
		int n=s.nextInt();
		int a[]=new int[n];
		int b[]=new int[n];
		System.out.print("Enter elements in array");
		int i,j;
		for( i=0;i<n;i++)
		{
			a[i]=s.nextInt();
			
		}
		for( i=0;i<n;i++){
		System.out.println(a[i]);
		}
		for(i=0;i<n;i++)
		{
			b[i]=a[i];
			System.out.println(b[i]);
		}
		
		

	}

}
