package com.cognizant.task;
import java.util.*;
class CurrencyConverter{
		double[] calculateCurrency(double []array)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the country(1.USA/2.Australia/3.Singapore)");
		int country=s.nextInt();
		if(country==1){
		for(int i=0;i<array.length;i++)
		{
			array[i]=array[i]*0.014;
		}
					}
		
		else if(country==2){
		for(int i=0;i<array.length;i++)
		{
			array[i]=array[i]*0.021;
		}
							}
		else if(country==3){
			for(int i=0;i<array.length;i++)
			{
				array[i]=array[i]*0.019;
			}
							}
		
		return array;
	}
}
public class CurrencyConerterDemo {
	public static void main(String args[])
	{	CurrencyConverter cc=new CurrencyConverter();
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the length of array");
		int length=s.nextInt();
		
		double arr[]=new double[length];
		double[]result=new double[length];
		
			System.out.println("Enter the Indian rupee");
			for(int i=0;i<arr.length;i++)
			{
			arr[i]=s.nextDouble();
			}
			
			 result=cc.calculateCurrency(arr);
			 for(double d:result){
			 System.out.println(d);}
		}
		
		}

