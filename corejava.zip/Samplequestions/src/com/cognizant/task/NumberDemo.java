package com.cognizant.task;
import java.util.*;
class ArraySum{
		Scanner s=new Scanner(System.in);
		
		
		int  arraySumCalculator(int []numarr){
			System.out.println("Enter a number");
			int n=s.nextInt();
			int sum=0;
			for(int i=0;i<numarr.length;i++)
			{
				if(numarr[i]>n)
					sum=sum+numarr[i];
			}
			System.out.println(sum);
			int rev=0;
			while(sum>0)
			{
				int d;
				d=sum%10;
				rev=(rev*10)+d;
				sum=sum/10;
			}
			
	return rev;
		
	}

}
public class NumberDemo {
	public static void main(String args[])
	{	int result;
		Scanner s=new Scanner(System.in);
		int numarr[]=new int[5];
		System.out.println("Enter the array elements");
		for(int i=0;i<numarr.length;i++)
		{
			numarr[i]=s.nextInt();
		}
		ArraySum as=new ArraySum();
		int r=as.arraySumCalculator(numarr);
		System.out.println(r);
	}

}
