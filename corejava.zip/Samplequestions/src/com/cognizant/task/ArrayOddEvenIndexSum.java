package com.cognizant.task;

import java.util.Scanner;

public class ArrayOddEvenIndexSum {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter length of array");
	int n=s.nextInt();
	int a[]=new int[n];
	System.out.println("Enter array elements");
	int i;
	int sum1=0,sum2=0;
		for(i=0;i<n;i++)
		{
			a[i]=s.nextInt();
		}
	for(i=0;i<n;i++)
	{
		if(i%2!=0)
		{
			sum1=sum1+a[i];
		}
		
		else
		{
			sum2=sum2+a[i];
			}
		
	}
	System.out.println(" sum of elements in odd indices"+sum1);
	System.out.println(" sum of elements in even indices"+sum2);
}
}
