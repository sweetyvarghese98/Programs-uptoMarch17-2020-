package com.cognizant.task;
class TemperatureConverter{
	double[]calculateTemperature(double arr[])
	{
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=(arr[i]*1.8)+32;
		}
		return arr;
	}
}
public class DemoConverter {
	public static void main(String args[]){
	double[]resultarr;
	TemperatureConverter tc=new TemperatureConverter();
	resultarr=tc.calculateTemperature(new double[]{10,20,30,40});
	for(double d:resultarr)
	{
		System.out.println(d);
	}
	
	

}
}