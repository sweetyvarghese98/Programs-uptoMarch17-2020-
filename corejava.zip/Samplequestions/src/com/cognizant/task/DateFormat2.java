package com.cognizant.task;

import java.text.DateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class DateFormat2 {
public static void main(String args[])
{	Date d2=new Date();
	DateFormat df=DateFormat.getDateInstance(DateFormat.FULL,Locale.UK);
	
	String res=df.format(d2);
	System.out.println(res);
	Date today=new Date();
	System.out.println(today);
	GregorianCalendar newdate=new GregorianCalendar(2020,2,11);
	Date d=newdate.getTime();
	System.out.println(d);
	System.out.println(today.compareTo(d));
	System.out.println();
	System.out.println(today.equals(d));
	System.out.println(today.after(d));
	System.out.println(today.before(d));
}
}
