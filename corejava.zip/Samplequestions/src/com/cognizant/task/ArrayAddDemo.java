package com.cognizant.task;
import java.util.*;
class ArraySum1{
    int []calculateArraySum(int[]a,int[]b)
    {   int[]c=new int[a.length];
        for(int i=0;i<a.length;i++)
        {
            c[i]=a[i]+b[i];
        }
        return c;
    }
}
public class ArrayAddDemo {

	 public static void main(String args[])
	    {
	        Scanner s=new Scanner(System.in);
	        System.out.println("Enter array length");
	        int n1=s.nextInt();
	        int a[]=new int[n1];
	        int b[]=new int[n1];
	        System.out.println("Enter first array elements");
	        for(int i=0;i<n1;i++)
	        {
	            a[i]=s.nextInt();
	        }
	        System.out.println("Enter Second array elements");
	        for(int i=0;i<n1;i++)
	        {
	            b[i]=s.nextInt();
	        }
	        int c[]=new int[a.length];
	        ArraySum1 as=new ArraySum1();
	        c=as.calculateArraySum(a, b);
	        System.out.println("Sum of two arrays");
	        for(int i=0;i<n1;i++)
	        {
	            System.out.println(c[i]);
	        }
	            
	        
	        
	        
	    }
	    
	}

