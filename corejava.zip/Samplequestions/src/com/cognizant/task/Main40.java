package com.cognizant.task;

import java.util.HashMap;
import java.util.Scanner;

public class Main40 {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	HashMap<Integer,Float> hm=new HashMap<>();
	System.out.println("Enter the key");
	System.out.println("Enter the value");
}
}
