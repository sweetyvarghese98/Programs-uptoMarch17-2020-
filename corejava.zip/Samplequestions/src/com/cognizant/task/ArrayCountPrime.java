package com.cognizant.task;

import java.util.Scanner;

public class ArrayCountPrime {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter length of array");
		int n=s.nextInt();
		int a[]=new int[n];
		System.out.println("Enter elements in array");
		int i,j,c=0;
		for( i=0;i<n;i++)
		{
			a[i]=s.nextInt();
		}
			for( i=0;i<n;i++)
			{	int count=0;
				for(j=a[i];j>=1;j--)
				{
					if(a[i]%j==0)
					{
						count=count+1;
					}
				}
				if(count==2)
				{	
					c++;
				}
			}
			System.out.println("no of prime numbers "+c);	
			
		}
			
	}


