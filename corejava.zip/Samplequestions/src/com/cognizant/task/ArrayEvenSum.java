package com.cognizant.task;

import java.util.Scanner;

public class ArrayEvenSum {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter length of array");
		int n=s.nextInt();
		int a[]=new int[n];
		System.out.print("Enter elements in array");
		int sum=0;
		for(int i=0;i<n;i++)
		{
			a[i]=s.nextInt();
			if(a[i]%2==0)
			{
				sum=sum+a[i];
			}
			
		}
		System.out.println("Sum is: "+sum);
		

	}

}
