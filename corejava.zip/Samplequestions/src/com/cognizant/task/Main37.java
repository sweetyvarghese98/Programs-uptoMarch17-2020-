package com.cognizant.task;

import java.util.Scanner;
class Usermaincode37{
	static String removeChar(String s1,String s2)
	{	
		String s3=s1.replace(s2,"");
		return s3;
		
	}
}
public class Main37 {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the String");
	String s1=s.nextLine();
	System.out.println("Enter a character in string");
	String s2=s.nextLine();
	String res=Usermaincode37.removeChar(s1, s2);
	System.out.println(res);
	
}
}
