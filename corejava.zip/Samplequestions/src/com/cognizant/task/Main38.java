package com.cognizant.task;

import java.util.Scanner;
class Usermaincode38{
	static int getVowels(String s1)
	{	
		for(int i=0;i<s1.length();i++)
	{

	if(s1.contains("a")&s1.contains("e")&s1.contains("i")&s1.contains("o")&s1.contains("u"))
		{
			return 1;
		}
	}
		
			return -1;
		
	
		
			
	}
}
public class Main38 {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter a string");
	String s1=s.nextLine();
	int res=Usermaincode38.getVowels(s1);
	if(res==1)
	{
		System.out.println("yes");
	}
	else
	{
		System.out.println("No");
	}
	
	
}
}
