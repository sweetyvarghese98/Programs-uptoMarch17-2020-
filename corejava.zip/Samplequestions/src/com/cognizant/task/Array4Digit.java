package com.cognizant.task;

import java.util.Scanner;

public class Array4Digit {
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter four digit number");
		int n=s.nextInt();
		int a[]=new int[4];
		while(n!=0)
		{
			
			for( int i=0;i<4;i++)
			{	int d=n%10;
				a[i]=d;
				n=n/10;
				System.out.print(a[i]+" ");		
			}
			
			
			
			
		}
	}

}
