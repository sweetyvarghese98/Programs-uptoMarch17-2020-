package com.cognizant.collectionDemo.set;

import java.util.HashMap;

public class PutAllDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String,String> statelist1=new HashMap<String,String>();
		statelist1.put("Kerala", "Thiruvananthapuram");
		statelist1.put("TamilNadu", "Chennai");
		statelist1.put("Karnataka", "Bangalore");
		
		HashMap<String,String> statelist2=new HashMap<String,String>();
		statelist2.put("AP1", "Amaravathi");
		statelist2.put("AP2", "Kurnool");
		statelist2.put("AP3", "Vizag");
		
		statelist1.putAll(statelist2);//contents of statelist 2 given to statelist1
		System.out.println("statelist1  :"+statelist1);
		System.out.println("statelist2  :"+statelist2);
		
		
		
	}

}
