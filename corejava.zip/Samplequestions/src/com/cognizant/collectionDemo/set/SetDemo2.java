package com.cognizant.collectionDemo.set;

import java.util.HashSet;

public class SetDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashSet<String>hs=new HashSet();
hs.add("India");
hs.add("Mango");
hs.add("apple");
hs.add("melon");
hs.add("orange");
hs.add("Apple");
hs.add("Mango");
System.out.println(hs);
boolean o=hs.contains("mango");
System.out.println(o);
boolean res=hs.isEmpty();
System.out.println("hs is empty?"+res);
hs.remove("melon");
System.out.println(hs);
System.out.println(hs.size());


	}

}
