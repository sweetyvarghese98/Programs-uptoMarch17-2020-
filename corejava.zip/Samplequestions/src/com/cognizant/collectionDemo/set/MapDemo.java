package com.cognizant.collectionDemo.set;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {
	public static void main(String args[])
	{
		//<object,object>
		//HashMap map=new HashMap();
		//HashMap<String,Double> map=new HashMap<String,Double>();
		//LinkedHashMap<String,Double> map=new LinkedHashMap<String,Double>();
		TreeMap<String,Double> map=new TreeMap<String,Double>();
		map.put("kumar", 3500.0);
		map.put("Ramesh", 4000.0);
		map.put("Ram", 5000.0);
		map.put("kumar", 4500.0);//it replaces first one
		map.put("John", 6000.0);
		System.out.println(map);
		System.out.println("Using iterator");
		
		
		//map.clear();
		System.out.println(map);//no elements in map after clear method
		System.out.println(map.get("Ram"));
		//System.out.println(map.get(5000.0));not possible
		boolean res=map.containsKey("kumar");
		System.out.println(res);
		boolean res1=map.containsKey("Ramesh");
		System.out.println("Is key Ramesh available? "+res1);
		boolean res2=map.containsValue(5000);
		System.out.println("Is value 5000 is available? "+res2);
		boolean res3=map.containsValue(5000.0);
		System.out.println("Is value 5000 is available? "+res3);
		//entryset=> set of all key value pairs.
		//java.util.Map.Entry
		Set<Entry<String,Double>> entries=map.entrySet();//can use only set as return typ,no subtyp is posible
		for(Entry<String,Double> e:entries)
		{
			String key=e.getKey();
			Double value=e.getValue();
			System.out.println(key  +" "+value);
		}
		Set keys=map.keySet();
		//System.out.println(keys);
		Iterator<String> iter=keys.iterator();
		while(iter.hasNext())
		{
			String key=iter.next();
			System.out.println(key);
		}
		//collection of values
		Collection<Double> collection=map.values();
		//System.out.println(collection);
		for(double d:collection)
		{
			System.out.println(d);
		}
		System.out.println("Using iterator");
		Iterator<Double> iter1=collection.iterator();//possible
		while(iter1.hasNext()){
			Double values=iter1.next();
			System.out.println(values);
		}
		
		
		
		
		}
	}


