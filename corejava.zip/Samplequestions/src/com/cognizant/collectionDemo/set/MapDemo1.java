package com.cognizant.collectionDemo.set;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

class MapDemoCountry
{
	HashMap<String,String> display()
	{
		HashMap<String,String> hm=new HashMap();
		hm.put("India", "Delhi");
		hm.put("China","Beijing");
		hm.put("Australia","Canberra");
		hm.put("Us", "WashingtonD.C");
		return hm;
	}
}
public class MapDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MapDemoCountry mp=new MapDemoCountry();
		HashMap<String,String>result=mp.display();
		ArrayList<String> ar=new ArrayList<String>();
		System.out.println(result);
		System.out.println("Using entry:..........");
		Set<Entry<String,String>> entries=result.entrySet();
		for(Entry<String,String> e:entries)
		{
			String key=e.getKey();
			String value=e.getValue();
			
			System.out.println(key +"               "+value);
			String sum=key+value;
			ar.add(sum);
			
			
			
		}System.out.println(ar);
		/*
		String s[]=new String[4];
		int i=0;
		for(Entry<String,String> e:entries)
		{
		String key=e.getKey();
		String value=e.getValue();
			s[i]=key+value;
			System.out.println(s[i]);
			i++;
			
		}*/
		
		
		
		
	}

}
