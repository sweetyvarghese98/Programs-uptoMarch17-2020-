package com.cognizant.collectionDemo.set;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;
public class SetDemo {
	public static void main(String args[])
	{
		//HashSet<String> hs=new HashSet<String>();
		//LinkedHashSet<String>hs=new LinkedHashSet();
		TreeSet<String> hs=new TreeSet<String>();
		hs.add("apple");
		hs.add("Apple");
		hs.add("Zebra");
		hs.add("orange");
		hs.add("banana");
		hs.add("mango");
		hs.add("apple");//duplicate
		hs.add("Orange");
		hs.add("Banana");
		hs.add("melon");
		System.out.println(hs);
		
	}

}
