package com.cognizant.collectionDemo.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

class SetDemo1{
	//HashSet<String> display()
	//Set<String> display()
	Set<String> display(){
		TreeSet<String> hs=new TreeSet<String>();
		hs.add("India");
		hs.add("China");
		hs.add("Australia");
		hs.add("Canada");
		hs.add("Us");
		return hs;
		
	}
	
}
public class SetDemoTask {
	public static void main(String args[])
	{
		
		SetDemo1 sd=new SetDemo1();
		Set<String>result= sd.display();//supertype=subtype
		//LinkedHashSet<String>result=sd.display();
		Iterator<String> iter=result.iterator();
		while(iter.hasNext()){
			String country=iter.next();
			System.out.println(country);
		}
	}

}
