package com.cognizant.Stream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class IoDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File f=new File("C://file//info.txt");
File dest=new File("C://file//info1.txt");

FileInputStream fis=null;
FileOutputStream fos=null;
int b;
System.out.println("Started");
try {
	fis=new FileInputStream(f);
	fos=new FileOutputStream(dest);
	
	//to copy
	while( (b=fis.read() ) !=-1){
		fos.write(b);
	}
	//fos.flush();
	System.out.println("end");
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


	}

}
