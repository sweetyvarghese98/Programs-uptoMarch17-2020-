package com.cognizant.Stream;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
//speed of counting is increased using buffered inputstream
public class LargeIoSpeed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File f=new File("C://file//largeinfo.txt");
int b=0;
int count=0;
FileInputStream fis=null;
BufferedInputStream bis=null;
try {
	fis = new FileInputStream(f);
	bis=new BufferedInputStream(fis);//frm file to fileinput stream then buffered inpstream
	try {
		while( (b=bis.read())!=-1)//bis .read beacause of buffered input
		{
			if(b== '\n')
				count++;
		}
		System.out.println("Number of lines= "+count);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
finally{
	
		try {
			bis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	}

	}


