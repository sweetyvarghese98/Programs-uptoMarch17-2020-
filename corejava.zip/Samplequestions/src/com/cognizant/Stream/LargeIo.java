package com.cognizant.Stream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LargeIo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 File f=new File("C://file//largeinfo.txt");
 FileInputStream fis=null;
 int b=0;
 int count=0;
 System.out.println("started to count....");
 try {
	 fis=new FileInputStream(f);
	 try {
		while((b=fis.read())!=-1){
			 if(b== '\n')
				 count++;
		 }
		System.out.println("Number of lines= "+count);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

}
