function validateForm()
{
var x=document.forms["myForm"]["fname"].value;
var y=document.forms["myForm"]["lname"].value;
var z=document.forms["myForm"]["email"].value;

	if(x =="")
	{
		alert("FirstName must be filled out");
		return false;
	}
	if(y =="")
	{
		alert("LastName must be filled out");
		return false;
	}
	if(z =="")
	{
		alert("Email Address must be filled out");
		return false;
	}
}

