class DemoStatic1{
int a=10;//nonstatic or instance variable
static int b=3;//static
//instance method
void dispaly(){
System.out.println("instance method");
}
//static method
static void showData(){
System.out.println("static method")
}
public static void main(String args[])
{
DemoStatic1 ds=new DemoStatic1();
System.out.println(ds.a);
System.out.println(b);
System.out.println(ds.b);
ds.display();
showData();
}
}