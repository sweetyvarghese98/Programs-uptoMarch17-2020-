//constructor overloading
class Vehicle{
int noOfSeats;
String color;
boolean isPowerSteared;
Vehicle()
{//we can call any argument constructor using this keyword
this(4);
System.out.println("Zero argument constructor");
}
Vehicle(int noOfSeats)
{
this(3,"red");//we can give this(noOfSeats,color) also
System.out.println("One argument constructor");
}
Vehicle(int noOfSeats,String color)
{
this(4,"red",true);
System.out.println("Two argument constructor");
}
Vehicle(int noOfSeats,String color,boolean isPowerSteared)
{
this.noOfSeats=noOfSeats;
this.color=color;
this.isPowerSteared=isPowerSteared;
System.out.println("Three argument Constructor");
}
}

class VehicleDemo{
public static void main(String args[])
{
Vehicle v=new Vehicle();
System.out.println(v.noOfSeats);
System.out.println(v.color);
System.out.println(v.isPowerSteared);
}
}