public class Test1 {
public static void main() {
System.out.println("hello";
}
}