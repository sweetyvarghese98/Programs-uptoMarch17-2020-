class DemoLocalVariable{
int i=10;
void methodA(){
int i=5;
this.i=this.i+i;
}
void methodB(){
int i=2;
this.i=this.i+i;
}
public static void main(String args[])
{
DemoLocalVariable d=new DemoLocalVariable();
System.out.println(d.i);
d.methodA();
System.out.println(d.i);
d.methodB();
System.out.println(d.i);
}
}
