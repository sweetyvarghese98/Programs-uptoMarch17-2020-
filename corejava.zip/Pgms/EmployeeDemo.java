//this
class Employee
{int employeeId;
String employeeName;
Employee(int employeeId,String employeeName){
this.employeeId=employeeId;
this.employeeName=employeeName;
}}
class EmployeeDemo{
public static void main(String args[])
{
Employee e1=new Employee(100,"Sweety");
Employee e2=new Employee(101,"Simi");
System.out.println(e1.employeeId);
System.out.println(e1.employeeName);
System.out.println(e2.employeeId);
System.out.println(e2.employeeName);
}
}