//constructor overloading
class Student{
int id;
String name;
}
//Default constructor
Student()
{
}
//parametrized constructor
Student(int id,String name)
{
this.id=id;
this.name=name;
}
}
class StudentDemo1{
public static void main(String args[])
{
Student s1=new Student(100,"sweety");
Student s2=new Student(101,"simi");
System.out.println(s1.id);
System.out.println(s1.name);
System.out.println(s2.id);
System.out.println(s2.name);
}
}