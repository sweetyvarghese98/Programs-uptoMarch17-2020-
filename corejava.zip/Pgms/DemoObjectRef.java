class Student{
int studentId;
double mark1,mark2,mark3,mark4,mark5;
Student(int studentId,double mark1,double mark2,double mark3,double mark4,double mark5)
{
this.mark1=mark1;
this.mark2=mark2;
this.mark3=mark3;
this.mark4=mark4;
this.mark5=mark5;
this.studentId=studentId;
}}
class DemoObjectRef{
public void displayStudentScore(Student s)
{
double result=(s.mark1+s.mark2+s.mark3+s.mark4+s.mark5)/5;
System.out.println("Average of "+s.studentId+"is "+result);

}
public static void main(String args[])
{
Student s1=new Student(11,10,10,10,10,10);
DemoObjectRef ref=new DemoObjectRef();
ref.displayStudentScore(s1);

}}