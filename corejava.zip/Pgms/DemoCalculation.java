class DemoCalculation{ double result;
double calculateDiscount(double price,double discount)
{
result=price-((5*price)/100);
return result;
}


public static void main(String args[])
{double result1;
DemoCalculation dc=new DemoCalculation();
double price=100.0;
double discount=5.0;
result1=dc.calculateDiscount(price,discount);
System.out.println(result1);
System.out.println(price);

}
}