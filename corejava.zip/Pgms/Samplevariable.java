class Samplevariable{
//instance variable
byte a;
short b;
char c;
int d;
float e;
double f;
long g;
boolean h;
public static void main(String args[])
{
	Samplevariable s=new Samplevariable();

System.out.println(s.a);
System.out.println(s.b);
System.out.println(s.c);
System.out.println(s.d);
System.out.println(s.e);
System.out.println(s.f);
System.out.println(s.g);
System.out.println(s.h);

}
}	