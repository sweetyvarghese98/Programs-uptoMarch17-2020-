import java.util.*;
class Employee{
int employeeId;
String employeeName;
}
class EmployeeDemo{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
System.out.println("Enter EmployeeId");
employeeId=s.nextInt();
System.out.println("Enter EmployeeName");
employeeName=s.nextLine();
Employee e=new Employee();
e.Employee(int employeeId,String employeeName);
}
}