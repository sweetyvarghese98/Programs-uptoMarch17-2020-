class MessagePrinter{
void PrintMessage(String name)
{
System.out.println("hello"+name);
}

public static void main(String args[])
{
MessagePrinter m=new MessagePrinter();
m.PrintMessage("sweety");
}
}