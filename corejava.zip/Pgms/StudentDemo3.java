//constructor overloading
class Student{
int id;
String name;

//Default constructor
Student()
{this(100,"sweety");
System.out.println("Zero argument constructor");
}
//parametrized constructor
Student(int id,String name)
{
this.id=id;
this.name=name;
System.out.println("Parametrized constructor");
}
}
class StudentDemo3{
public static void main(String args[])
{
Student s3=new Student();

System.out.println(s3.id);
System.out.println(s3.name);

}
}