public class profile
{
private profile(int w)
{
System.out.println(w);
}
public static profile()
{
System.out.println(10);
}
public static void main(String args[])
{
profile obj=new profile(50);

}
}