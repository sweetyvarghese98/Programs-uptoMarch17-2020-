class Product{
int productId;
String name;
static int counter;

Product(int productId,String name)
{this.productId=productId;
this.name=name;
counter++;
}
}
class ProductDemo{
public static void main(String args[])
{
Product p1=new Product(102,"a");
System.out.println(p1.counter);
Product p2=new Product(100,"b");
System.out.println(p2.counter);
Product p3=new Product(101,"abc");
System.out.println(Product.counter);
System.out.println(Product.counter);
}
}