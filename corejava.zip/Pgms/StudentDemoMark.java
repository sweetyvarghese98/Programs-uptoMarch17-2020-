class Student{
int StudentId;
int mark1,mark2,mark3,mark4,mark5;
}
class StudentDemoMark{
void calculateMark(Student s)
{int total, average;
total=s.mark1+s.mark2+s.mark3+s.mark4+s.mark5;
average=(s.mark1+s.mark2+s.mark3+s.mark4+s.mark5)/5;

}
public static void main(String args[])
{int total,average;
Student s=new Student(100,10,10,10,10,10);
System.out.println(s.total);
System.out.println(s.average);

}}