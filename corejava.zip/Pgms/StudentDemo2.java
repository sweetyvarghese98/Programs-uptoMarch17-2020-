//constructor overloading
class Student{
int id;
String name;
int age;
//Default constructor
Student(){this(100,"sweety");
System.out.println("Zero argument constructor");
}
//parametrized constructor
Student(int id,String name)
{this(100,"sweety",21);
System.out.println("Two argument constructor");
}
Student(int id,String name,int age)
{this.id=id;
this.name=name;
this.age=age;
System.out.println("Three argument constructor");}}
class StudentDemo2{
public static void main(String args[])
{
Student s=new Student();
System.out.println(s.id);
System.out.println(s.name);
System.out.println(s.age);
}
}