package samplenulltxt;

import java.util.Scanner;
class UserMainCode20{
		static String concatString(String str1,String str2)
	{		
			
			String strres1 = null;
			String strres2=null;
		if(str1.length()==str2.length())
			{	
			strres1=str1.concat(str2);
			return strres1;
			}
			else
			{	String strnew2 = null;
				String strnew1 = null;
				
				if(str1.length()>str2.length())
				{
					int n1=str1.length()-str2.length();
					strnew1=str1.substring(n1,str1.length())+str2;
					return strnew1;
				}
		
				else
				{
					int n2=str2.length()-str1.length();
					strnew2=str2.substring(n2,str2.length())+str1;
					return strnew2;
				}
				
			}
		
		
		}
}
public class Main20 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the first string");
		String str1=s.next();
		System.out.println("Enter the second string");
		String str2=s.next();
		String res=UserMainCode20.concatString(str1, str2);
		System.out.println(res);
		
	}

}
