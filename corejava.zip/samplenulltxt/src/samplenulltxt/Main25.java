package samplenulltxt;

import java.util.Scanner;
class Usermaincode25
{
	static int calculateNcr(int n,int r)
	{	int f=1;
		for(int i=1;i<=n;i++)
		{
			f=f*i;
		}
		int f1=1;
		for(int i=1;i<=r;i++)
		{
			f1=f1*i;
		}
		int f2=1;
		for(int i=1;i<=n-r;i++)
		{
			f2=f2*i;
		}
		int result=f/(f1*f2);
		return result;
		
	}
}
public class Main25 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter n");
		int n=s.nextInt();
		System.out.println("Enter r");
		int r=s.nextInt();
		int res=Usermaincode25.calculateNcr(n, r);
		System.out.println(res);
		
	}

}
