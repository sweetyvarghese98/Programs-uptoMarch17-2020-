package samplenulltxt;

import java.util.Scanner;
class UserMaincode22{
	static int validateString(String str)
	{	int flag=0;
	for(int i=4;i<str.length();i++)
		{
		if(str.charAt(0)=='C'&&str.charAt(1)=='T'&&str.charAt(2)=='S'&&str.charAt(3)=='-')
				{
					if(str.charAt(i)=='1'||str.charAt(i)=='2'||str.charAt(i)=='3'||str.charAt(i)=='4'||
							str.charAt(i)=='5'||str.charAt(i)=='6'||str.charAt(i)=='7'||
							str.charAt(i)=='8'||str.charAt(i)=='9')
					{
						flag=1;
					}
					else
					{
						flag=-1;
					}
				}
		}
	return flag;
	
	
				
			
				
	}
	
}
public class Main22 {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter a string");
	String str=s.next();
	int res=UserMaincode22.validateString(str);
	if(res==1)
	{
		System.out.println("valid");
	}
	if(res==-1)
	{
		System.out.println("invalid");
	}
	
	
}
}
