package samplenulltxt;

import java.util.Scanner;

class Usermaincode24 {
	static int checkLargestAmongcorner(int[] arr) {
		int l = arr.length;
		if (l == 1) 
		{
			return arr[0];
		}
		else 
		{
			if (arr[0] > arr[l - 1])
			{
				if (arr[0] > arr[(l - 1 )/ 2]) 
				{
					return arr[0];
				} else 
				{
					return arr[(l - 1 )/ 2];
				}
			}

			else if (arr[l - 1] > arr[(l - 1 )/ 2]) 
			{
				return arr[l - 1];
			} else 
			{
				return arr[(l - 1 )/ 2];
			}
		}

	}

}

public class Main24 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the array size of maximum 20");
		int n = s.nextInt();
		System.out.println("Enter an array elements");
		int arr[] = new int[n];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = s.nextInt();
		}
		int res = Usermaincode24.checkLargestAmongcorner(arr);
		System.out.println(res);
	}

}
