package samplenulltxt;

import java.util.Scanner;
class userMaincode19{
	static int sumOfDigits(String str){
		int sum=0;
		int flag=-1;
		for(int i=0;i<str.length();i++)
		{	
			if(Character.isDigit(str.charAt(i)))
			{
			String temp=str.substring(i,i+1);
			sum=sum+Integer.parseInt(temp);
			flag=1;
			}
		}
			if(flag==1)
			{
				return sum;
			}
			else
			{
				return flag;
			}
		
		
		
	}
}

public class Main19 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=s.next();
		int res=userMaincode19.sumOfDigits(str);
		System.out.println(res);
	}

}
