package samplenulltxt;

import java.util.Scanner;
class UserMainCode21
{
	static int validateColourcode(String str){
		int flag=0;
		for(int i=1;i<str.length();i++)
		{	int n=str.length();
			if(str.charAt(0)=='#'&&n==7)
			{	
				if(str.charAt(i)=='A'||str.charAt(i)=='B'||str.charAt(i)=='C'||str.charAt(i)=='D'||
						str.charAt(i)=='E'||str.charAt(i)=='F'||str.charAt(i)=='0'||str.charAt(i)=='1'||
						str.charAt(i)=='2'||str.charAt(i)=='3'||str.charAt(i)=='4'||str.charAt(i)=='5'||
						str.charAt(i)=='6'||str.charAt(i)=='7'||str.charAt(i)=='8'||str.charAt(i)=='9')
				{
					flag=1;
					
					
				}
				else
				{
					flag=-1;
					break;
					
				}
			}
		}
		return flag;
		
		
	}
}
public class Main21 {

	public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter a string");
	String str=s.next();
	int res=UserMainCode21.validateColourcode(str);
	if(res==1)
	{
		System.out.println("valid");
	}
	if(res==-1)
	{
		System.out.println("Invalid");
	}
	
	

	}

}
