package samplenulltxt;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
class Usermaincode23{
	static int sizeOfResultantHashMap(ConcurrentHashMap<Integer,String>hm){
		ConcurrentHashMap<Integer,String>hmresult=new ConcurrentHashMap<Integer,String>();
		Set<Entry<Integer,String>>entries=hm.entrySet();
		for(Entry<Integer,String>e:entries)
		{	
			if(e.getKey()%4==0)
			{
				hm.remove(e.getKey(), e.getValue());
			}
			else
			{
				hmresult.put(e.getKey(),e.getValue());
			}
		}
		
		return hmresult.size();
		
	}
}
public class Main23 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of hashmap");
		int n=s.nextInt();
		ConcurrentHashMap<Integer,String>hm=new ConcurrentHashMap<Integer,String>();
		System.out.println("Enter the values and keys");
			for(int i=0;i<n;i++)
		{
				int k=s.nextInt();
				String v=s.next();
				hm.put(k,v);
		}
			System.out.println(hm);
			
		int res=Usermaincode23.sizeOfResultantHashMap(hm);	
		System.out.println(res);
			
		
	}

}
