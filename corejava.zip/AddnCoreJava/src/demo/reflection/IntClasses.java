package demo.reflection;
class Emp123{
	
		int id;
		String name;
	}
public class IntClasses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Class<Integer> a=int.class;//a and b will have same hashcode
Class<Integer> b=Integer.TYPE;// the class instance representing the primitive type int
Class<Integer>  c=Integer.class;//class class type object

System.out.println(System.identityHashCode(a));
System.out.println(System.identityHashCode(b));
System.out.println(System.identityHashCode(c));


System.out.println(a.hashCode());
System.out.println(b.hashCode());
System.out.println(c.hashCode());

System.out.println(Emp123.class);//getclass() give class of the object during runtime
System.out.println(new Emp123().getClass());
//System.out.println(Emp123.getClass());//not possible,because getclass is not static method
	}

}
