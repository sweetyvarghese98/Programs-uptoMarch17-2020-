package demo.reflection;

import java.lang.reflect.Method;
import java.util.ArrayList;

public class DumpMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class c=Class.forName("java.util.ArrayList");
			Method m[]=c.getDeclaredMethods();
			for(int i=0;i<m.length;i++)
			{
				System.out.println(m[i].toString());
			}
			
			@SuppressWarnings("unchecked")//in built annotation
			ArrayList<String> a1=(ArrayList<String>)c.newInstance();//creating an arrayList,c is Class type object,here without new keyword.
			a1.add("apple");
			a1.add("mango");
			System.out.println(a1);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
