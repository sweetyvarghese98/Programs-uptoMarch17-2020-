package p3.AnnotationDemo;

import java.lang.annotation.*;


@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)

public @interface FoodItem {	
	/*String flavour();//now annotation can have parameters also
	String color();*/


	
	String flavour() default "vannilla";
	String color() default "white";
}
