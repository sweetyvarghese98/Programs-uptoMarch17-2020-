package p3.AnnotationDemo;
//user defined annotation
//@FoodItem(flavour="vanilla" ,color="white")
//default fooditem will be vannilla flavoured and white colour

@FoodItem
class Cake{
	//variables
	//constructors
	//methods etc..
}

//@FoodItem
@FoodItem(flavour="chocolate",color="dark brown")
class IceCream{
	//var ,methods ,constructors etc
}
public class Main1 {

	@SuppressWarnings("unchecked")
	public static  void main(String[] args) {
		// TODO Auto-generated method stub
		
	Cake c=new Cake();
	Class<Cake> cake=(Class<Cake>)c.getClass();
	FoodItem fooditemannotation=cake.getAnnotation(FoodItem.class);
	String info=fooditemannotation.color()+" "+fooditemannotation.flavour();
	System.out.println(info);
	

	}

}

	
	
	
	//it give nullpointer exception so metaannotation should be used.
	//meta annotation means userdefined annotation should be annotated to class or method or variable,
	//in this case annotated to class ,so .TYPE is used,TYPE indicates class.
	//retention policy to retain the attributes.Upto runtime,source time etc.
	