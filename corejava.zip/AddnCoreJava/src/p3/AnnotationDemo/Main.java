package p3.AnnotationDemo;
//inbuilt annotations is used in this program
import java.util.ArrayList;

class Base{
	public void displayDataFromMyDatabase(){
		System.out.println("display base");
	}
	@Deprecated
	void show(){
		System.out.println("show");
	}
}
	class sub extends Base{
		@Override
		public void displayDataFromMyDatabase(){
			System.out.println("display in sub");
		}
	}

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		@SuppressWarnings("rawtypes")
		ArrayList a1=new ArrayList();
		Base b=new Base();
		b.displayDataFromMyDatabase();
		b.show();
		
	}

}
