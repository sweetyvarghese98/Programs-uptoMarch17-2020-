package com.cognizant.sports;

public class CricketCoach implements Coach {

	@Override
	public String getDailyWorkOut() {
		// TODO Auto-generated method stub
		
			return "practice for 2 hours";
	}		
	}


