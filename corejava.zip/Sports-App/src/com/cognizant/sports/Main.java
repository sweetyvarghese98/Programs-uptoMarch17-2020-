package com.cognizant.sports;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coach c=new CricketCoach();
		Coach c1=new TennisCoach();
		Coach c2=new BaseBallCoach();
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Coach coach=context.getBean("myCricketCoach",Coach.class);
		System.out.println(coach.getDailyWorkOut());
		
		coach=context.getBean("myBaseBallCoach",Coach.class);
		System.out.println(coach.getDailyWorkOut());
		
		coach=context.getBean("myTennisCoach",Coach.class);
		System.out.println(coach.getDailyWorkOut());

	}

}
