package com.cognizant.sports;

public interface Coach {
String getDailyWorkOut();
}
