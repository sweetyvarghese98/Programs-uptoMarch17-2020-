package com.cognizant.sports;

public class BaseBallCoach implements Coach {

	@Override
	public String getDailyWorkOut() {
		// TODO Auto-generated method stub
		return "Batting practice for 2 hours";
	}

}
