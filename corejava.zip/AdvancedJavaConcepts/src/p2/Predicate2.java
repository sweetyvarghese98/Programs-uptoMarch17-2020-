package p2;

import java.util.ArrayList;
import java.util.function.Predicate;

public class Predicate2 {
public static void displayCustomers(ArrayList<Customer>a1,Predicate<Customer>pred)
{	//here a1 corresponds to customerlist,and pred is passed predicate
	a1.forEach((c)->{
		if(pred.test(c))
			System.out.println(c);
	});
}
public static void main(String args[])
{
	ArrayList<Customer> customerList=new ArrayList<>();
	customerList.add(new Customer(23,"AAA"));
	customerList.add(new Customer(33,"BBB"));
	customerList.add(new Customer(43,"CCC"));
	customerList.add(new Customer(53,"DDD"));
	customerList.add(new Customer(63,"EEE"));
	
	Predicate<Customer> pred1=(c)->c.getAge()<40;
	System.out.println("Below 40");
	displayCustomers(customerList,pred1);
	
	Predicate<Customer> pred2=(c)->c.getAge()>40;
	System.out.println("Above 40");
	displayCustomers(customerList,pred2);
	//we can pass any number of predicate for testing.
}
}
