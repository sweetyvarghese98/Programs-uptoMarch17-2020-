package p2;

import java.util.ArrayList;
import java.util.function.Predicate;

public class PredicateLambda {
public static void main(String args[])
{
	ArrayList<Customer> customerList=new ArrayList<>();
	customerList.add(new Customer(23,"AAA"));
	customerList.add(new Customer(33,"BBB"));
	customerList.add(new Customer(43,"CCC"));
	customerList.add(new Customer(53,"DDD"));
	
	Predicate<Customer> pred=(c)->c.getAge()<40;
	Predicate<Customer> pred1=(c)->c.getAge()>40;//can write any number of predicate method.
	//customerList.forEach((a)->System.out.println(a));
	
	System.out.println("Below 40");
	for(Customer c:customerList){
		//for every customer,test method is invoked.
		if(pred.test(c))
			System.out.println(c);
	}
	
	System.out.println("Above 40");
	for(Customer c:customerList){
		//for every customer,test method is invoked.
		if(pred1.test(c))
			System.out.println(c);
	}
	
	System.out.println("Above 40 using for each");
	//customerList.forEach((c)->System.out.println(c)); //it is without testing,so every customer will printed.
	customerList.forEach((c)->{
		if(pred1.test(c))//after testing ie whether age>40
			System.out.println(c);
	});
	
}
}
