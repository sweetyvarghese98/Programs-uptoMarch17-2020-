package p2;

import java.util.function.Predicate;

 class MyPredicate implements Predicate<Customer>{
	 //predicate is an interface.
	@Override
	//can be converted to lambda expression
	//test is an abstract method which accepts parameter and returns boolean ie,true or false.
	public boolean test(Customer t) {
		
		return t.getAge()>30;
	}


	
	
}
public class Main {
public static void main(String args[])
{
	Customer c=new Customer(34,"AAA");//true
	//Customer c1=new Customer(24,"AAA");//output will be false
	MyPredicate p=new MyPredicate();
	boolean res=p.test(c);
	//boolean res1=p.test(c1);
	System.out.println(res);
	//System.out.println(res1);
			}
}
