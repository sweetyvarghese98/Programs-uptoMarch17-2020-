package p1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Employee{
	int age;
	String name;
	public Employee(int age,String name)
	{
		this.age=age;
		this.name=name;
	}
	public String toString()
	{
		return "Employee [age=" +age+ ",name=" +name+ "]";
	}
}
class EmployeeComparator implements Comparator<Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		
		return o1.age-o2.age;
	}
	
}
public class ComparatorEmployee {
	public static void main(String args[])
	{
		ArrayList<Employee> emplist=new ArrayList<>();
		emplist.add(new Employee(63,"AAA"));
		emplist.add(new Employee(33,"bbb"));
		emplist.add(new Employee(50,"CCC"));
		emplist.add(new Employee(30,"ddd"));
		emplist.add(new Employee(54,"mmm"));
		emplist.add(new Employee(49,"NNN"));
		
		Comparator<Employee> c=(e1,e2)->{
			return e1.age-e2.age;
		};
		Collections.sort(emplist,c);
		System.out.println("Using enhanced forloop");
		for(Employee e:emplist)
		{
			System.out.println(e);
		}
		//System.out.println("Using forEach loop);
		//or for printing we can use forEach loop
		//emplist.forEach((s)->System.out.println(s));
		
		//to get normally
		System.out.println("Using normal way of comparator");
		Collections.sort(emplist,new EmployeeComparator());
		emplist.forEach((s)->System.out.println(s));
		
		
		
	}

	

}
