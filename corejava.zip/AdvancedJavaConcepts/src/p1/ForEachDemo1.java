package p1;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.function.Consumer;

public class ForEachDemo1 {
public static void main(String args[])
{
	//List<String> fruitList=Arrays.asList("apple","orange","mango");
	HashSet<String>fruitList=new HashSet<>();
	fruitList.add("apple");
	fruitList.add("orange");
	
	Consumer<String> c=(str)->System.out.println(str);
	fruitList.forEach(c);
	
	//or simply u can do this:-
	System.out.println("**** single step****");
	fruitList.forEach((str)->System.out.println(str));
}
}
