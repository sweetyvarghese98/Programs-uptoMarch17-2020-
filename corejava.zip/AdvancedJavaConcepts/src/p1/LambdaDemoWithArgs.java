package p1;
interface SimpleInterface{
	int doCalculate(int a,int b);
}
public class LambdaDemoWithArgs {

	public static void main(String[] args) {
	
		SimpleInterface s=(v1,v2)->{
			//if there is multiple expression put it curly braces.
			int res=v1+v2;
			System.out.println(res);
			return res;};
			//return v1+v2;};
		//lambda expression can accept parameters,it can also return values.
		//a=v1,b=v2
		int res=s.doCalculate(5, 6);
		System.out.println(res);
		
	}

}
