package p1;
interface Shape1{
	void draw();
	//show is instance method
	default void show(){
		System.out.println("Show method in shape interface");
	}
	//display is static method
	static void display(){
		System.out.println("display method in shape interface");
	}
}
public class IntefaceDemo {
public static void main(String args[])
{
	/*Shape1.display();//static
	Shape1 s=()->{System.out.println("drawing a shape");};
	s.draw();//overridden method
	s.show();*/
	
	//ANONYMOUS CLASS
	
	Shape1 s=new Shape1(){

		@Override
		public void draw() {
			// TODO Auto-generated method stub
		System.out.println("Iam drawing a shape");	
		}
		
	};
	s.draw();
	//Shape1.display();
	
	
}
}
