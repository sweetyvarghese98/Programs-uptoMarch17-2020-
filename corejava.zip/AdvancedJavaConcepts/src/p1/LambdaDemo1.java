package p1;
class MyRunnable implements Runnable{
	public void run(){
		System.out.println("Thread a");
	}
}
public class LambdaDemo1 {

	public static void main(String[] args) {
		//Lambda expression
		//using runnable interface,runnable inteface have public void function only ie run.No need of interface implementation
		Runnable r=() ->System.out.println("Thread a");
		new Thread(r).start(); 
		Runnable r1=() ->System.out.println("Thread b");
		new Thread(r1).start();
		
	}

}
