package p1;

public class LambdaDemo3 {
	class MyRunnable implements Runnable{
		public void run(){
			System.out.println("Thread a");
		}
	}
	public static void main(String[] args) {
		Runnable r1=()->{
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Thread A");
		};
		Runnable r2=()->System.out.println("Thread B");
		new Thread(r1).start();
		new Thread(r2).start();

	}

}
