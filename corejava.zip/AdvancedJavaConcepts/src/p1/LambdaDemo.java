package p1;

interface Shape{
	void calculate(int a);
}
/*class MyClass implements Shape{
	public void calculate(int a){
		System.out.println(a*a);
	}
}*/
public class LambdaDemo {

	public static void main(String[] args) {
	
Shape s=(a) ->System.out.println(a*a);//instead of implementation of interface shape,this is enough.(Lambda expression)
s.calculate(5);
	}

}
