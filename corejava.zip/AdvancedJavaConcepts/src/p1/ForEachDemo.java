package p1;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;



//forEach and Consumer
public class ForEachDemo {
	public static void main(String args[])
	{
		List<Integer> numbers= Arrays.asList(new Integer(4),new Integer(5),new Integer(6));
		
		System.out.println("******** two step******");
		//accept(T t)//accept method of consumer interface accept one argument t,it is i.
		Consumer<Integer>c=(i)->System.out.println(i);//accept the integer and print it
		numbers.forEach(c);//for each like forloop,now c has integers in it.
		
		System.out.println("****** one step *********");
		numbers.forEach((i)->System.out.println(i));//on collection obj,forEach method is invoked//directly integers are given to forloop.
	}

}
