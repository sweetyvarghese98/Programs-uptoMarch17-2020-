package p1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
class MyComparator implements Comparator<String>{

	@Override
	public int compare(String s1, String s2) {
		return s1.compareTo(s2);
		
	}

	

	
}
public class UseComparator {

	public static void main(String[] args) {
	ArrayList<String> strings=new ArrayList<>();
	strings.add("AAA");
	strings.add("bbb");
	strings.add("CCC");
	strings.add("DDD");
	strings.add("eee");
	strings.add("fff");
	
	Collections.sort(strings,new MyComparator());
	strings.forEach((s)->System.out.println(s));
	
	//comparator interface also have one abstract methode compare
	//so lambda can be applied
	System.out.println("Using lambda");
	//Comparator<String> c=(s1,s2)->{return s1.compareTo(s2);};
	Comparator<String> c=(s1,s2)->{return s1.compareToIgnoreCase(s2);};
	Collections.sort(strings,c);//here c is used ie code is treated as data
	//Collections.sort(strings,(s1,s2)->{return s1.compareTo(s2);});
	strings.forEach((s)-> System.out.println(s));
	}

}
