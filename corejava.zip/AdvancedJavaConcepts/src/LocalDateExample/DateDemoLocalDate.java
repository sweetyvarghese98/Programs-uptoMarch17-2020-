package LocalDateExample;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class DateDemoLocalDate {
public static void main(String args[])
{	
	//current date
	LocalDate currentdate=LocalDate.now();//now is used to get todays date
	System.out.println(currentdate);
	
	//one based->1 means january
	LocalDate specificdate=LocalDate.of(2000,12,6);//of for anyother date,yyy,mm,dd...jan=1
	//LocalDate specificdate=LocalDate.of(2000,Month.FEBRUARY,6);//ENUMERATION,to be more specific
	System.out.println(specificdate);
	
		//exception
	//LocalDate specificdate1=LocalDate.of(2020,2,30);
	//System.out.println(specificdate1);
	
	//current time
	LocalTime currenttime=LocalTime.now();
	System.out.println(currenttime);
	
	//anytime
	LocalTime specifictime=LocalTime.of(14,0,45);
	System.out.println(specifictime);
	
	//current date and time
	LocalDateTime currentDT=LocalDateTime.now();
	System.out.println(currentDT);
	
	//any date and time
	LocalDateTime specificDT=LocalDateTime.of(specificdate,specifictime);
	//LocalDateTime specificDT=LocalDateTime.of(2020,3,12,10,2,45);
	//LocalDateTime specificDT=LocalDateTime.of(2020,3,12,23,10,2,45);//including hour also in time
	System.out.println(specificDT);
}
}
