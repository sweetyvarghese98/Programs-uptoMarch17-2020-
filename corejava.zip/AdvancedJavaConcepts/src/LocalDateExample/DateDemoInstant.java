package LocalDateExample;

import java.time.Duration;
import java.time.Instant;

public class DateDemoInstant {
public static void main(String args[]) throws InterruptedException
{
	Instant instant1=Instant.now();
	System.out.println(instant1);
	Thread.sleep(1000);
	
	Instant instant2=Instant.now();
	System.out.println(instant2);
	
	Duration duration=Duration.between(instant1,instant2);
	System.out.println(duration);//ISO REPRESENTATION
	
	System.out.println("Elapsed "+duration.toMillis());//Converted to milliseconds
}
}
