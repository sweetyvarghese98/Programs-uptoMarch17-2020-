package LocalDateExample;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class DateDemoFormat1 {
public static void main(String args[])
{	
	//ofLocalizeddate gives zone according to country.
	
	LocalDate currentdate=LocalDate.now();
	DateTimeFormatter df1=
			DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
	String shortdate=df1.format(currentdate);
	System.out.println(shortdate);
	
	
	DateTimeFormatter df2=
			DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
	String mediumdate=df2.format(currentdate);
	System.out.println(mediumdate);
	
	
	
	DateTimeFormatter df3=
			DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
	String longdate=df3.format(currentdate);
	System.out.println(longdate);
	
	
	DateTimeFormatter df4=
			DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
	String fulldate=df4.format(currentdate);
	System.out.println(fulldate);
}
}
