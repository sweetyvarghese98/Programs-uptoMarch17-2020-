package LocalDateExample;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class DateDemoLocale {
public static void main(String args[])
{
	LocalDate currentdate=LocalDate.now();
	DateTimeFormatter df1=DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
	String fulldate=df1.format(currentdate);
	System.out.println(fulldate);
	
	String frenchdate=df1.withLocale(Locale.FRENCH).format(currentdate);
	System.out.println(frenchdate);
	
	String italiandate=df1.withLocale(Locale.ITALIAN).format(currentdate);
	System.out.println(italiandate);
	
}
}
