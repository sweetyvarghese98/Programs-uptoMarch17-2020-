package LocalDateExample;

import java.time.ZoneId;
import java.util.Set;
import java.util.function.Predicate;

public class DateDemoZones {
public static void main(String args[])
{
	Set<String> zones=ZoneId.getAvailableZoneIds();//ZoneId is a class
	System.out.println("List all the time zones");
	zones.forEach((s)->System.out.println(s));
	
	System.out.println("List all the timezones which contains the string calcutta");
	Predicate<String>pred=(str)->str.contains("Calcutta");
	zones.forEach(s->{
		if(pred.test(s))
			System.out.println(s);
	});
	
	/*System.out.println("List all the timezones which contains the string London");
	Predicate<String>pred1=(str)->str.contains("London");
	zones.forEach(s->{
		if(pred1.test(s))
			System.out.println(s);
	});*/
}
}
