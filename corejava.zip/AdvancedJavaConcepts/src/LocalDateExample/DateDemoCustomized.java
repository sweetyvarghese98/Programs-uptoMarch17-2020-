package LocalDateExample;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

public class DateDemoCustomized {
public static void main(String args[])
		{
		LocalDateTime ldt=LocalDateTime.now();
		//you create your own display format
		DateTimeFormatterBuilder b=new DateTimeFormatterBuilder()
		.appendValue(ChronoField.MONTH_OF_YEAR).appendLiteral("||")
		.appendValue(ChronoField.DAY_OF_MONTH).appendLiteral("||")
		.appendValue(ChronoField.YEAR);
		
		
		/*DateTimeFormatterBuilder b=new DateTimeFormatterBuilder()
		.appendValue(ChronoField.MONTH_OF_YEAR).appendLiteral("|*|")
		.appendValue(ChronoField.DAY_OF_MONTH).appendLiteral("|*|")
		.appendValue(ChronoField.YEAR);*/   //output==2|*|18|*|2020
		
		DateTimeFormatter f=b.toFormatter();
		String newformat=f.format(ldt);
		System.out.println(newformat);
		}
}
