package LocalDateExample;

import java.time.LocalDate;
import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
		Date d=new Date();
		System.out.println(d);//gives date,time,timezone
		
		

	}

}
