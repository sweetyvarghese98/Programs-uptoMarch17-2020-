package LocalDateExample;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateDemoFormat {
public static void main(String args[])
{
	LocalDate currentdate=LocalDate.now();
	//System.out.println(currentdate);
	
	DateTimeFormatter df=DateTimeFormatter.ISO_DATE;//like simpledateformat,we can format
	String fd=df.format(currentdate);
	System.out.println(fd);
	
	df=DateTimeFormatter.ISO_LOCAL_DATE;// here local date means ist
	fd=df.format(currentdate);
	System.out.println(fd);
	
	df=DateTimeFormatter.BASIC_ISO_DATE;
	fd=df.format(currentdate);
	System.out.println(fd);
	
	LocalDateTime ldt=LocalDateTime.now();
	df=DateTimeFormatter.ISO_LOCAL_DATE_TIME;
	fd=df.format(ldt);
	System.out.println(fd);
	
	
}
}
