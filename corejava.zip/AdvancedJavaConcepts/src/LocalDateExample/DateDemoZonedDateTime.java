package LocalDateExample;

import java.time.LocalDateTime;

public class DateDemoZonedDateTime {
public static void main(String args[])
{
	LocalDateTime ldt=LocalDateTime.now();
	
}
}
