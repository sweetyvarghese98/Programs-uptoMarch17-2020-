package Set1txt;

import java.util.Scanner;
class Set6{
	public static int getFibonacci(int n)
	{	int a=-1,b=1,c=0,d=0;
		for(int i=0;i<=n;i++)
		
	{
		c=a+b;
		a=b; b=c;
		d=d+c;
		//System.out.println(c);
		
	}
	return d;	
	}
}
public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the limit");
int n=s.nextInt();
System.out.println(Set6.getFibonacci(n));
	}

}
