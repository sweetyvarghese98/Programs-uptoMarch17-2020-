package Set1txt;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Main9 {
public static void main(String args[]) throws ParseException
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter first date");
	String s1=s.nextLine();
	System.out.println("Enter next date");
	String s2=s.nextLine();
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
	//sdf.setLenient(false);
	Date d1=null;
	d1=(Date) sdf.parse(s1);
	Date d2=null;
	d2=(Date) sdf.parse(s2);
	Calendar c=Calendar.getInstance();
	c.setTime(d1);//to get date after 1970 jan
	int m1=c.get(Calendar.MONTH);
	int y1=c.get(Calendar.YEAR);
	c.setTime(d2);
	int m2=c.get(Calendar.MONTH);
	int y2=c.get(Calendar.YEAR);
	int n=(y1-y2)*12+(m1-m2);
	System.out.println(n);
	
	
}
}
