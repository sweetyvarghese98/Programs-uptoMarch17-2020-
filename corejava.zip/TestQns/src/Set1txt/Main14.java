package Set1txt;

import java.util.StringTokenizer;

public class Main14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="hi howw are youu";
int max=0;
String s4=null;
StringTokenizer st=new StringTokenizer(s1," ");
while(st.hasMoreTokens())
{
String str=st.nextToken();
int n=str.length();
if(n>max)
{
	max=n;
	s4=str;
}


}
System.out.println(s4);

	}

}
