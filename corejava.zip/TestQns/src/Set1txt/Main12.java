package Set1txt;

import java.util.StringTokenizer;

public class Main12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String t="21:36 am";
StringTokenizer st=new StringTokenizer(t," ");
String s1=st.nextToken();
String s2=st.nextToken();
StringTokenizer st1=new StringTokenizer(s1,":");
int n1=Integer.parseInt(st1.nextToken());
int n2=Integer.parseInt(st1.nextToken());
if(s2.equalsIgnoreCase("am")||s2.equalsIgnoreCase("pm"))
if((n1<=12)&&(n2<=59))
{
	System.out.println("12 hour format");
}
else
{
	System.out.println("24 hour format");
}
	}

}
