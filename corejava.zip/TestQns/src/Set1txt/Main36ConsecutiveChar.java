package Set1txt;

import java.util.Scanner;
 class Main36ConsecutiveChar {
	
	
		public static int repeat(String str)
		{
			int c=0;
			for(int i=0;i<str.length()-1;i++)
			{
				
					if(str.charAt(i)==str.charAt(i+1))
					{
						c++;
					}
				}
				if(c>2)
				{
					return 1;
			}
				else
				{
					return -1;
				}
		}	
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a string");
String str=s.nextLine();
System.out.println(repeat(str));

	
	
}
}
