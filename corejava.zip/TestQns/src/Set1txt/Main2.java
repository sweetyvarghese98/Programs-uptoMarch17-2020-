package Set1txt;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
class Set2{
	static String getDay(Date d2)
	{	SimpleDateFormat sdf=new SimpleDateFormat("EEEEE");
		String d=sdf.format(d2);
		return d;
		
	}
}
public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
//System.out.println("Enter a date in yyyy-mm-dd format");
//String s1=s.nextLine();
/*SimpleDateFormat sdf1=new SimpleDateFormat();
Date d1=null;
try {
	d1=sdf1.parse(s1);
} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}*/
Date d=new Date(2012/12/27);

//String res=Set2.getDay(s1);
System.out.println(Set2.getDay(d));
	}

}
