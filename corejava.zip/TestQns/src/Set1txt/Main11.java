package Set1txt;

import java.util.ArrayList;
import java.util.Collections;

public class Main11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> a1=new ArrayList<>();
String []s1={"ga","ya","awe"};
for(int i=0;i<s1.length;i++)
{
	a1.add(s1[i]);
}
String s2="awe";
Collections.sort(a1,Collections.reverseOrder());
System.out.println(a1);
System.out.println(a1.indexOf("awe"));
	}

}
