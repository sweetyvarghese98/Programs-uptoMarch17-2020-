package Set1txt;

import java.util.Scanner;
class Set1{
	public static int sumOfOdd(int n)
	{	int sum=0;
		while(n!=0)
		{	
			int d=n%10;
			if(d%2!=0)
			{
				sum=sum+d;
			}
			n=n/10;
		}
		if(sum%2==0)
		{
			return -1;
		}
		else
			
		return 1;
		
	}
}
public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a number");
int n=s.nextInt();
int res=Set1.sumOfOdd(n);
System.out.println(res);
	}

}
