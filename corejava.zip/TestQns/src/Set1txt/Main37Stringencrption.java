package Set1txt;

public class Main37Stringencrption {
public static void main(String args[])
{
	String s1="preethi";
	System.out.println(encrypt(s1));
}
	
	public static String encrypt(String s) {
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<s.length();i++){
			char c=s.charAt(i);
			if(c%2!=0){
				c=(char)(c+1);
				sb.append(c);  }
			else
				sb.append(c);   }
		return sb.toString();
	}
}
