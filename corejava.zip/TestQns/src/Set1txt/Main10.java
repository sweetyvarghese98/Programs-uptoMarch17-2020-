package Set1txt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;

public class Main10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String[] s1={"arun#17#12#12","deepak#16#12#12","puppy#15#11#12"} ;



ArrayList<String> a1=new ArrayList<String>();
for(int i=0;i<(s1.length);i++)
{
	System.out.println(s1[i]);
	a1.add(s1[i]);
}
System.out.println(a1);
Map<String,Integer>m=new HashMap<>();
for(int j=0;j<a1.size();j++)
{
	StringTokenizer st=new StringTokenizer(a1.get(j),"#");
	String sname=st.nextToken();
	int n1=Integer.parseInt(st.nextToken());
	int n2=Integer.parseInt(st.nextToken());
	int n3=Integer.parseInt(st.nextToken());
	int n=n1+n2+n3;
	m.put(sname, n);
	
}
int max=0;String res=null;
Set<Entry<String,Integer>>entries=m.entrySet();
for(Entry<String,Integer>e:entries)
{	
	String name=e.getKey();
	int mark=e.getValue();
	if(mark>max)
	{
		max=mark;
		res=name;
		
	}
	
	
	
}
System.out.println(res);




	}

}
