package Set1txt;

import java.util.ArrayList;

public class Main38MaxOddIndex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]={1,9,3,4,5,6,7,8};
System.out.println(retrieve(a));
	}
	
	public static int retrieve(int a[])
	{	int max=0;
		ArrayList<Integer> a1=new ArrayList<>();
		for(int i=0;i<a.length;i++)
		{
			if(i%2!=0)
			{
				a1.add(a[i]);
			}
			
			for(int j=0;j<a1.size();j++)
			{
				if(a1.get(j)>max)
				{
					max=a1.get(j);
				}
			}
		}
		System.out.println(a1);
		return max;
		
		
	}

}
