package Set1txt;

import java.util.ArrayList;
import java.util.Scanner;
class Set4{
	public static int mergeArray(ArrayList<Integer>a1,ArrayList<Integer>a2)
	{
		a1.retainAll(a2);
		int sum=0;
		for(int i=0;i<a1.size();i++)
		{
		   sum=sum+a1.get(i);	
		}
		return sum;
		
	}
}
public class Main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
ArrayList<Integer> a1=new ArrayList<Integer>();
ArrayList<Integer> a2=new ArrayList<Integer>();
System.out.println("Enter first arraylist elements");
for(int i=0;i<4;i++)
{
	int a=s.nextInt();
	a1.add(a);
}
System.out.println("Enter second arraylist elements");
for(int i=0;i<4;i++)
{
	int a=s.nextInt();
	a2.add(a);
}
System.out.println(Set4.mergeArray(a1, a2));
	}

}
