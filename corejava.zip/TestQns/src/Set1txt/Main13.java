package Set1txt;

import java.util.ArrayList;
import java.util.Scanner;

public class Main13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Integer> a1=new ArrayList<Integer>();
Scanner s=new Scanner(System.in);
System.out.println("Enter the first number");
int n1=s.nextInt();
System.out.println("Enter the second number");
int n2=s.nextInt();

int sum=0;
for(int i=n1;i<=n2;i++)
{
int temp=i;
int rev=0;
	while(temp!=0)
	{	
		rev=(rev*10)+(temp%10);
		temp=temp/10;
	}	
	
	if(rev==i)
	{
		a1.add(i);
		
	}
	
	

}
System.out.println(a1);
for(int i1=0;i1<a1.size();i1++)
{
	sum=sum+a1.get(i1);


}
	System.out.println(sum);
}
}


	