package Set1txt;

import java.util.ArrayList;
import java.util.Scanner;
class Set7{
	public static int consecutiveSum(ArrayList<Integer> a1)
	{	
		int n1=a1.get(0);
		for(int i=1;i<a1.size();i++)
		{	
			if(i%2!=0)
			{
				n1=n1+a1.get(i);
			}
			else
			{
				n1=n1-a1.get(i);
			}
		}
		return n1;
		
	}
}
public class Main7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
ArrayList<Integer>a1=new ArrayList<Integer>();
System.out.println("Enter the number");
int n=s.nextInt();
//int a[]=new int[n];
//System.out.println("Enter the elements");
for(int i=1;i<=n;i++)
	if(i%2!=0)
{
	
	a1.add(i);
}
System.out.println(a1);
	

System.out.println(Set7.consecutiveSum(a1));

	}

}
