package Set1txt;

import java.util.Scanner;
class Set3{
	static int getDiff(int a[])
	{	int max=0; int r=0;
		for(int i=0;i<a.length-1;i++)
		{
			int s=a[i]-a[i+1];
			if(s>max)
			{
				max=s;
				r=i;
			}
			
		}
		
		
		return r ;
		
	}
}
public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the array size");
int n=s.nextInt();
int a[]=new int[n];
System.out.println("Enter array Elements");
for(int i=0;i<n;i++)
{
	a[i]=s.nextInt();
}
System.out.println(Set3.getDiff(a));
	}

}
