package Set1txt;

import java.util.StringTokenizer;

class Main38ArrangeCharactres {
public static void main(String args[]){

	String s="555-666-1234";
	System.out.println(arrangeChar(s));
}
public static String arrangeChar(String s)
{
	StringTokenizer st=new StringTokenizer(s,"-");
	String s1=st.nextToken();
	String s2=st.nextToken();
	String s3=st.nextToken();
	
	StringBuffer sb=new StringBuffer();
	//sb.append(s1.substring(0,s1.length()-1)).append("-");
	sb.append(s1.charAt(0)).append(s1.charAt(1)).append("-");
	sb.append(s1.charAt(2)).append(s2.charAt(0)).append("-");
	sb.append(s2.substring(1,s2.length())).append(s3.charAt(0)).append("-");
	sb.append(s3.substring(1, s3.length()));
	
	
	return sb.toString();
}
}

