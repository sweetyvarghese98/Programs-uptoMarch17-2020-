package Set1txt;

import java.util.ArrayList;
import java.util.Scanner;
class Set5{
	public static ArrayList<Integer> newArray(ArrayList<Integer>a1,ArrayList<Integer>a2)
	{	ArrayList<Integer> res=new ArrayList<Integer>();
		for(int i=0;i<a1.size();i++)
		{
			if(i%2==0)
			{
				res.add(a2.get(i));
			}
			else
			{
				res.add(a1.get(i));
			}
			
		}
		return res;
		
		
	}
}
public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
ArrayList<Integer> a1=new ArrayList<Integer>();
ArrayList<Integer> a2=new ArrayList<Integer>();
System.out.println("Enter the first arrayList");
for(int i=0;i<4;i++)
{
	int a=s.nextInt();
	a1.add(a);
	
}
System.out.println("Enter the second arrayList");
for(int i=0;i<4;i++)
{
	int a=s.nextInt();
	a2.add(a);
	
}
System.out.println(Set5.newArray(a1,a2));

	}

}
