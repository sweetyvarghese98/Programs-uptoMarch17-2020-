package Set1txt;

public class Main40GetSpecificChar {
public static void main(String args[])
{
	String s="Rajasthan";
	System.out.println(getWord(s));
	
}
public static String getWord(String s)
{
	StringBuffer sb=new StringBuffer(s);
	sb.reverse();
	String s1=sb.substring(2,5);
	
	return s1;
	
}
}
