package Set1txt;

import java.util.Scanner;

public class Main15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter a string");
String str=s.nextLine();
StringBuffer sb=new StringBuffer(str);
sb.reverse();
for(int i=1;i<sb.length();i++)
{
	if(i%2!=0)
	sb.insert(i, "-");
}
System.out.println(sb.toString());
	}

}
