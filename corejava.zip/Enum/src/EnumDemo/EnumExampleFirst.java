package EnumDemo;
enum Level{LOW,HIGH,MEDIUM}

public class EnumExampleFirst {

	public static void main(String[] args) {
		//String arr[]={"low","medium","high"};
		// TODO Auto-generated method stub
		System.out.println(Level.HIGH);
		System.out.println(Level.valueOf("LOW"));
		Level l1=Level.LOW;
		Level l2=Level.HIGH;
		//COMPARING use compareTo() ==.equals
		System.out.println(l1.compareTo(l2));
		System.out.println(l2.compareTo(l1));
		System.out.println(l1==Level.HIGH);
		System.out.println(l1==Level.LOW);
		
	}

}
