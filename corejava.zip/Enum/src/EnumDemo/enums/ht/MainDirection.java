package EnumDemo.enums.ht;

public class MainDirection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Direction north=Direction.NORTH;
		System.out.println(north);//prints north
		/* The ordinal()method returns the order of an enum instance.
		 * It represents the sequence in the enum declaration,
		 * where the initial constant is assigned an ordinal of '0'
		 * It is very much like array indexes
		 */
		
		System.out.println(Direction.EAST.ordinal());//0
		System.out.println(Direction.NORTH.ordinal());//2
		System.out.println(Direction.SOUTH.name());//SOUTH
		//The enum values() method returns all the enum values in an enum array.
		Direction[] directions=Direction.values();
		
		for(Direction d:directions)
		{
			System.out.println(d);//ALL enum values
		}
		//The enum valueOf() method helps to convert string to enum interface.
		Direction east=Direction.valueOf("EAST");
		System.out.println(east);//EAST
		
		//exception,because centre is not there in enum
		//Direction centre=Direction.valueOf("CENTRE");
		//System.out.println(centre);
		
	}

}
