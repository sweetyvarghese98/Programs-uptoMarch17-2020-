package p1;

public class Dog {
	String name;
	
	public Dog() {
		
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name=name;
	}
}
