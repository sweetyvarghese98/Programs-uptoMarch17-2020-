package p1;

public class Customer {
 int id;
 String customerName;
 Dog dog;//obj
 public Customer() {
	 
 }
 public Dog getDog() {
	 return this.dog;
 }
 public void setDog(Dog dog)
 {
	 this.dog=dog;
 }
 public int getId() {
	 return id;
 }
 public void setId(int id)
 {
	 this.id=id;
 }
 public String getCustomerName()
 {
	 return this.customerName;
 }
 public void setCustomerName(String customerName) {
	 this.customerName=customerName;
 }
}
