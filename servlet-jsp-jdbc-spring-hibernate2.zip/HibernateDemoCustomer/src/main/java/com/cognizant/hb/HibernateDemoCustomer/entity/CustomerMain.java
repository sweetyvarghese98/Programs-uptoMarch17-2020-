package com.cognizant.hb.HibernateDemoCustomer.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CustomerMain {

	public static void main(String[] args) {
		SessionFactory factory=new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Customer.class)
				.buildSessionFactory();
		Session session=factory.getCurrentSession();
		
	
		
		Customer c1=new Customer("arun","kumar","ak@gmail.com");
		session.beginTransaction();
		session.save(c1);
		session.getTransaction().commit();
		factory.close();
		

	}

}
