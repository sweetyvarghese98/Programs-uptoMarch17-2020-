package p1;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ValidateServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName=request.getParameter("username");
		String password=request.getParameter("password");
		RequestDispatcher rd=null;
		HttpSession session=null;
   if(userName.equalsIgnoreCase("kumar")&&
					password.contentEquals("abc123"))
		{
			session=request.getSession(true);
			session.setMaxInactiveInterval(20*60);//to make session timeout programatically=>20 minutes
			session.setAttribute("user", userName);
			rd=request.getRequestDispatcher("home");//this 'home' should be given as url pattern in xml page.
			rd.forward(request, response);
		}
    else {
			rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
	}
}
