package p1;

public class Dog {
	String dogName;
	String team;
	public Dog() {
		
	}
	public String getDogName() {
		return this.dogName;
	}
	public void setDogName(String dogName)
	{
		this.dogName=dogName;
	}
	public String getTeam() {
		return this.team;
	}
	public void setTeam(String team)
	{
		this.team=team;
	}
}
