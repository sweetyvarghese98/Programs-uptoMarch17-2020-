package com.cognizant.CustomerJdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.Customer.entity.Customer;
import com.cognizant.dao.CustomerDAOImpl;

/**
 * Servlet implementation class ValidateFindId
 */
public class ValidateFindId extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateFindId() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=new Integer(request.getParameter("id"));
		PrintWriter out=response.getWriter();
		CustomerDAOImpl dao=new CustomerDAOImpl();
		List<Customer> c=dao.findById( id);
		Iterator<Customer> iter=c.iterator();
		while(iter.hasNext())
		{	
			Customer c1=iter.next();
			out.println(c1);//here we are given obj ref variable.so toString method is invoked
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
