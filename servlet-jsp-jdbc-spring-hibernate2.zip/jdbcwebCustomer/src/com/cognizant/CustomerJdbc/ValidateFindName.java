package com.cognizant.CustomerJdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.Customer.entity.Customer;
import com.cognizant.dao.CustomerDAOImpl;

/**
 * Servlet implementation class ValidateFindName
 */
public class ValidateFindName extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateFindName() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("customername");
		PrintWriter out =response.getWriter();
		CustomerDAOImpl dao=new CustomerDAOImpl();
		List<Customer> c= dao.findByName(name);
		Iterator<Customer>iter=c.iterator();
		while(iter.hasNext())
		{
			Customer c1=iter.next();
			out.println(c1);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
