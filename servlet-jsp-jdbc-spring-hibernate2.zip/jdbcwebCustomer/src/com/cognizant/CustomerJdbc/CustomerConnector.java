package com.cognizant.CustomerJdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class CustomerConnector {

	public static Connection getConnection() {

		FileInputStream fis = null;
		Properties prop = new Properties();
		Connection connection = null;

		try {
			fis = new FileInputStream("C:\\servlets\\jdbcwebCustomer\\WebContent\\configure.properties");
			prop.load(fis);// to load properties file into javaclass.

			String db_driver = prop.getProperty("db.driver");
			String db_url = prop.getProperty("db.url");
			String db_user = prop.getProperty("db.user");
			String db_password = prop.getProperty("db.password");

			Class.forName(db_driver);
			connection = DriverManager.getConnection(db_url, db_user, db_password);
			if (connection != null) {
				System.out.println("connection available");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
}
	public static void main(String[] args) {
		getConnection();

	}
}