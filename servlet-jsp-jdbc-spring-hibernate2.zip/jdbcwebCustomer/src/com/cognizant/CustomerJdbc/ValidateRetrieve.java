package com.cognizant.CustomerJdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.Customer.entity.Customer;
import com.cognizant.dao.CustomerDAOImpl;




/**
 * Servlet implementation class ValidateRetrieve
 */
public class ValidateRetrieve extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateRetrieve() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		CustomerDAOImpl dao = new CustomerDAOImpl();
		PrintWriter out=response.getWriter();
		 List<Customer> c=dao.ListAllCustomer();
			Iterator<Customer> iter=c.iterator();
			while(iter.hasNext())
			{	
				Customer c1=iter.next();
				out.println(c1);//here we are given obj ref variable.so toString method is invoked
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
