package com.cognizant.dao;

import java.util.List;

import com.cognizant.Customer.entity.Customer;


public interface CustomerDAO {

	 void insertCustomer(Customer c);
	   void  upDateCustomer(int id,Customer c);
	    void deleteCustomer(int id);
	    List<Customer> ListAllCustomer();
	    
		List<Customer> findById(int id);
		List<Customer> findByName(String name);
	    
	
}

