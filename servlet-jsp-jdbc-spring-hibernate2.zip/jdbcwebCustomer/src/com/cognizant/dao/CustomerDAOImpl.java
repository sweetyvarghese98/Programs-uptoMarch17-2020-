package com.cognizant.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.Customer.entity.Customer;
import com.cognizant.CustomerJdbc.CustomerConnector;

import com.mysql.jdbc.PreparedStatement;

public class CustomerDAOImpl implements CustomerDAO{

	@Override
	public void insertCustomer(Customer c) {
PreparedStatement ps=null;
		
		Connection con =CustomerConnector.getConnection();
		try {
			ps=(PreparedStatement) con.prepareStatement("insert into customer values(?,?,?,?)");
		    ps.setInt(1, c.getId());
		    ps.setString(2, c.getName());
		    ps.setString(3, c.getPhone());
		    ps.setString(4, c.getEmail());
			
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public void upDateCustomer(int id,Customer c) {
		Connection con=CustomerConnector.getConnection();
		PreparedStatement ps=null;
		String sql="update customer set customer_name=?,customer_phone=?, customer_email=? where customer_id=?";
		
		try {
			ps= (PreparedStatement) con.prepareStatement(sql);
			ps.setString(1, c.getName());
			ps.setString(2, c.getPhone());
			ps.setString(3, c.getEmail());
			ps.setInt(4, id);
			
			ps.executeUpdate();
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public void deleteCustomer(int id) {
		
			Connection con=CustomerConnector.getConnection();
			java.sql.PreparedStatement ps=null;
			
			String sql="delete from customer where customer_id=?";
			try {
				ps=con.prepareStatement(sql);
				ps.setInt(1,id);
				int res=ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	
	@Override
	public List<Customer> ListAllCustomer() {
		Connection con=CustomerConnector.getConnection();
		ArrayList<Customer>customerList=new ArrayList<Customer>();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from customer";
		
		
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next())
			{
				int id=rs.getInt("customer_id");
				String name=rs.getString("customer_name");
				String phone=rs.getString("customer_phone");
				String email=rs.getString("customer_email");
				
				
				Customer c=new Customer(id,name,phone,email);
				customerList.add(c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customerList;
		
	}
	
	
	@Override
	public List<Customer> findById(int id) {
		Connection con=CustomerConnector.getConnection();
		ArrayList<Customer>customerList1=new ArrayList<Customer>();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from customer where customer_id='"+id+ "'";
		
		
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next())
			{
				int id1=rs.getInt("customer_id");
				String name=rs.getString("customer_name");
				String phone=rs.getString("customer_phone");
				String email=rs.getString("customer_email");
				
				
				Customer c=new Customer(id1,name,phone,email);
				customerList1.add(c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customerList1;
		
	}
	@Override
	public List<Customer> findByName(String name) {
		Connection con=CustomerConnector.getConnection();
		ArrayList<Customer>customerList2=new ArrayList<Customer>();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from customer where customer_name='"+name+"'";
		
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
		 
		while(rs.next())
		{	
			int id=rs.getInt("customer_id");
			String name1=rs.getString("customer_name");
			String phone=rs.getString("customer_phone");
			String email=rs.getString("customer_email");

			Customer c2=new Customer(id,name,phone,email);
			customerList2.add(c2);
			
		}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return customerList2;
		
	}

	
}
