package com.cognizant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;

import com.cognizant.Customer.entity.User;
import com.cognizant.CustomerJdbc.CustomerConnector;
import com.mysql.jdbc.Connection;

public class UserDAOImpl implements UserDAO {

	@Override
	public boolean getCredentials(User u1) {
		Connection con=(Connection) CustomerConnector.getConnection();
		//ArrayList<User> ulist=new ArrayList<User>();
		boolean result=false;
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from user";
		
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next())
			{
			String uname=rs.getString("user_name");
			String upassword=rs.getString("user_password");
			
			if(u1.getUserName().equals(uname))
			{
				result=true;
			}
			
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
		
		
		
	}

	
		
	}


