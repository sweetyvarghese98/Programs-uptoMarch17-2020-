package com.cognizant.dao;

import java.util.List;

import com.cognizant.Customer.entity.User;

public interface UserDAO {
boolean getCredentials(User u1);
}
