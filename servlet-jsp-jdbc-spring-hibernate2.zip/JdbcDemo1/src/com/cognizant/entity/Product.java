package com.cognizant.entity;

import java.util.Date;

public class Product {
	public int productId;
	String productName;
	Double price;
	Date dateOfManufacture;
	
	
	
	public Product(int productId,String productName,Double price,
			Date dateOfManufacture)
	{
		this.productId=productId;
		this.productName=productName;
		this.price=price;
		this.dateOfManufacture=dateOfManufacture;
		
		
		
	}
	
	public void setproductId()
	{
		this.productId=productId;
		
	}
	public int getproductId(int productId)
	{
		return this.productId;
	}
	
	public void setproductName()
	{
		this.productName=productName;
		
	}
	public String getproductName(String productName)
	{
		return this.productName;
	}
	
	
	public void setprice()
	{
		this.price=price;
		
	}
	public Double getprice(Double price)
	{
		return this.price;
	}
	
	public void setdateOfManufacture()
	{
		this.dateOfManufacture=dateOfManufacture;
		
	}
	public Date getdateOfManufacture(Date dateOfManufacture)
	{
		return this.dateOfManufacture;
	}
	public String toString() {
		return "Product[Id= "+productId + "," +productName +" , "+price +" ," 
				+dateOfManufacture+"]";
	}
	

}
