package com.cognizant.dao;

import java.util.List;


import com.cognizant.entity.Product;



public interface ProductDao {
	List<Product> ListAllProduct();
	boolean upDateproduct(int ProductId,Product p);
	boolean insertProduct(Product p);
	boolean deleteProduct(int productId);
	
	List<Product> findByName(String productName);
	List<Product> findById(int productId);
}
