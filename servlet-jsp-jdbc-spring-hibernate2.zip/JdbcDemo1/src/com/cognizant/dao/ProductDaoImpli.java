package com.cognizant.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.entity.Product;

import p2.DBConnector1;




public class ProductDaoImpli implements ProductDao {

	@Override
	public List<Product> ListAllProduct() {
		ArrayList<Product>plist=new ArrayList();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from product";
		Connection con=DBConnector1.getConnection();
		java.util.Date d=null;
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
		while(rs.next())
		{
			int id=rs.getInt("product_id");
			String name=rs.getString("product_name");
			Double price=rs.getDouble("price");
			d=rs.getDate("dateOfManufacture");
		
			
			Product p1=new Product(id,name,price,d);
			plist.add(p1);
		}
		
		} 
		catch (SQLException e) {
			e.printStackTrace();
			}
		
		
		
		return plist;
		
	}

	@Override
	public boolean upDateproduct(int ProductId, Product p) {
		Connection con=DBConnector1.getConnection();
		java.sql.PreparedStatement ps=null;
		boolean result=false;
		String sql="update product set product_name=?, price=?  where product_id=?";
		
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, p.getproductName(null));
			ps.setDouble(2, p.getprice(0.0));
			ps.setInt(3, ProductId);
			int res=ps.executeUpdate();
			if(res==1)
				result=true;
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public boolean insertProduct(Product p) {
		Connection con=DBConnector1.getConnection();
		java.sql.PreparedStatement ps=null;
		
		boolean result=false;
		String sql="insert into product values(?,?,?,?)";
		java.util.Date d=p.getdateOfManufacture(null);
		java.sql.Date sqlDate=new java.sql.Date(d.getTime());
		
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1, p.getproductId(0));
			ps.setString(2, p.getproductName(null));
			ps.setDouble(3, p.getprice(0.0));
			ps.setDate(4, sqlDate);
			int res=ps.executeUpdate();
			if(res==1)
			result=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean deleteProduct(int productId) {
		Connection con=DBConnector1.getConnection();
		java.sql.PreparedStatement ps=null;
		boolean result=false;
		String sql="delete from product where product_id=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setInt(1,productId);
			int res=ps.executeUpdate();
			if(res==1)
				result=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public List<Product> findByName(String productName) {
		ArrayList<Product>pList1=new ArrayList<Product>();
		Statement statement=null;
		ResultSet rs=null;
		String sql="select * from product where product_name='"+productName+"'";
		Connection con=DBConnector1.getConnection();
		java.util.Date d=null;
		java.sql.PreparedStatement ps=null;
		
		try {
			statement=con.createStatement();
			rs=statement.executeQuery(sql);
			while(rs.next())
			{
				int id=rs.getInt("product_id");
				String name=rs.getString("product_name");
				Double price=rs.getDouble("price");
				Date dom=rs.getDate("dateOfManufacture");
				d=new java.util.Date(dom.getTime());//converting sql date to util date(java.util.Date.)
				
				
				Product p1=new Product(id,name,price,dom);
				pList1.add(p1);
			}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return pList1;
		}
		

	@Override
	public List<Product> findById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
