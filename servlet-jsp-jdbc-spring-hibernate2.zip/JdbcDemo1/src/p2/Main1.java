package p2;

import java.sql.Connection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.cognizant.dao.ProductDaoImpli;
import com.cognizant.entity.Product;





public class Main1 {
	public static void main(String[] args) {
		Connection con=	DBConnector1.getConnection();
		ProductDaoImpli dao=new ProductDaoImpli();
		List<Product> a1=dao.ListAllProduct();
		Iterator<Product> iter=a1.iterator();
		while(iter.hasNext())
		{
			Product p=iter.next();
			System.out.println(p);
		}
		
		/*Product p2=new Product(101,"Fridge",22000.0, null);
		boolean res2=dao.upDateproduct(101,p2);
		System.out.println("Whether product 101 is updated: "+res2);*/
		
		
		java.util.Date d=new java.util.Date();
		Product p3=new Product(104,"MIXIE",42020.0,d);
		boolean res3=dao.insertProduct(p3);
		System.out.println("Whether product is inserted: "+res3);
		
		/*boolean res4=dao.deleteProduct(101);
		System.out.println("Whether product record of 101 is deleted: "+res4);
		
		List<Product>a2=dao.findByName("AC");
		Iterator<Product> iter1=a2.iterator();
		while(iter1.hasNext())
		{
			Product pname=iter1.next();
			
			System.out.println(pname);//here we are given obj ref variable.so toString method is invoked
		}*/

}
}